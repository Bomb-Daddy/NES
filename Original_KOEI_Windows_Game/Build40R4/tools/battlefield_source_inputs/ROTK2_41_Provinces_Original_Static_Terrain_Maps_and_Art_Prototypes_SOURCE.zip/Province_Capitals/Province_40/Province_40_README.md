# Province_40

Source map verified statically; art is PROTOTYPE, not approved final. Castle 11,6; offset 0x27BD9.
