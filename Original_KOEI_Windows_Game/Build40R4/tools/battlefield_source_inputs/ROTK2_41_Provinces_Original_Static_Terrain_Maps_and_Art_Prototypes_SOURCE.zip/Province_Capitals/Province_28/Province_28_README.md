# Province_28

Source map verified statically; art is PROTOTYPE, not approved final. Castle 3,6; offset 0x27831.
