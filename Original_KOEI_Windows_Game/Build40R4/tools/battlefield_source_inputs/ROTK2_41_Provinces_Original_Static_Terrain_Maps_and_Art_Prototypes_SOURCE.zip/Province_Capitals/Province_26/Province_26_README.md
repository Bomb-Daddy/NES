# Province_26

Source map verified statically; art is PROTOTYPE, not approved final. Castle 7,5; offset 0x27795.
