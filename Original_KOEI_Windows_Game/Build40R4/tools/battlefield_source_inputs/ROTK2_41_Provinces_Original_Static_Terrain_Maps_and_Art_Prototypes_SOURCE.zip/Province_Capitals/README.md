# ROTK2 Province Capitals

41/41 province data extractions from SHA-256 verified original NES ROM. Each contains a static terrain map, 7x7/9x9 neighborhoods, geography notes and five **procedural prototype** castle-town illustrations (neutral + four seasons). **NOT approved final artwork.** NES renderer orientation remains unverified. No original ROM bytes are distributed.
