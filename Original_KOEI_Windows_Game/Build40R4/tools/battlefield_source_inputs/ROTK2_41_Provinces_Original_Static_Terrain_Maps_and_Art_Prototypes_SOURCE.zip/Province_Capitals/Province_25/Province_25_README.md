# Province_25

Source map verified statically; art is PROTOTYPE, not approved final. Castle 12,6; offset 0x27747.
