# Province_24 geography

Source: original NES ROM SHA-256 `11e312691b516e5e29dade3c8ce5434df3561cc69e1aecad9c948acdfddc517a`; file record `0x276F9`.

**Static decoded evidence (orientation not runtime verified):** Castle at (12,5), fort positions [(11, 3), (10, 6), (12, 7)]; terrain cell counts {0: 59, 1: 36, 2: 2, 3: 8, 4: 47, 5: 3, 6: 1}. Grid 13x12; x/y indicate decoded map coordinates, not confirmed compass directions.

**Illustration interpretation:** East Asian castle-town architecture, bridge/street patterns and specific structures are artist-designed, not present as such in ROM. Water scenery appears only where code 4 exists. Distant ridgelines and vegetation intensity reflect map prevalence. Camera and built geometry are frozen across seasons.

**Remaining gate:** original NES renderer table-read and orientation verification; final UI canvas, approved style match and manual art QA. The included seasonal assets are algorithmic composition prototypes, not final hand-art-directed outputs.
