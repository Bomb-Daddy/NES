# Province_24

Source map verified statically; art is PROTOTYPE, not approved final. Castle 12,5; offset 0x276F9.
