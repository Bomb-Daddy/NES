# Province_17

Source map verified statically; art is PROTOTYPE, not approved final. Castle 4,5; offset 0x274D7.
