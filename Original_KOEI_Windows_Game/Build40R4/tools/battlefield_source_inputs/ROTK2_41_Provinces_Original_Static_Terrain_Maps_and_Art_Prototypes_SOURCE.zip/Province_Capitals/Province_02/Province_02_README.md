# Province_02

Source map verified statically; art is PROTOTYPE, not approved final. Castle 5,2; offset 0x27045.
