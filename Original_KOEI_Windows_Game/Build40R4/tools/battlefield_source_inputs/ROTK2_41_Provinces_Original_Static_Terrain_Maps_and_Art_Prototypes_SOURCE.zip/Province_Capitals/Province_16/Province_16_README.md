# Province_16

Source map verified statically; art is PROTOTYPE, not approved final. Castle 5,5; offset 0x27489.
