# Province_23

Source map verified statically; art is PROTOTYPE, not approved final. Castle 10,7; offset 0x276AB.
