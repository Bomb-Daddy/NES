# Province_08 geography

Source: original NES ROM SHA-256 `11e312691b516e5e29dade3c8ce5434df3561cc69e1aecad9c948acdfddc517a`; file record `0x27219`.

**Static decoded evidence (orientation not runtime verified):** Castle at (8,5), fort positions [(6, 8), (10, 8)]; terrain cell counts {0: 52, 1: 20, 2: 18, 3: 15, 4: 48, 5: 2, 6: 1}. Grid 13x12; x/y indicate decoded map coordinates, not confirmed compass directions.

**Illustration interpretation:** East Asian castle-town architecture, bridge/street patterns and specific structures are artist-designed, not present as such in ROM. Water scenery appears only where code 4 exists. Distant ridgelines and vegetation intensity reflect map prevalence. Camera and built geometry are frozen across seasons.

**Remaining gate:** original NES renderer table-read and orientation verification; final UI canvas, approved style match and manual art QA. The included seasonal assets are algorithmic composition prototypes, not final hand-art-directed outputs.
