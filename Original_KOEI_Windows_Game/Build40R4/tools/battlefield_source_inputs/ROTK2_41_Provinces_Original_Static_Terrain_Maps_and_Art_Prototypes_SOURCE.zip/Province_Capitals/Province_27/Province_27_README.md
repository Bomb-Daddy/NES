# Province_27

Source map verified statically; art is PROTOTYPE, not approved final. Castle 4,6; offset 0x277E3.
