# Province_05

Source map verified statically; art is PROTOTYPE, not approved final. Castle 6,4; offset 0x2712F.
