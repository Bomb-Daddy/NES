# Province_15

Source map verified statically; art is PROTOTYPE, not approved final. Castle 3,2; offset 0x2743B.
