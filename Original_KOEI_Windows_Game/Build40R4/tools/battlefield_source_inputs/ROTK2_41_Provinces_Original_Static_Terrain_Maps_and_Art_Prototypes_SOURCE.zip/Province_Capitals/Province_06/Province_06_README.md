# Province_06

Source map verified statically; art is PROTOTYPE, not approved final. Castle 7,6; offset 0x2717D.
