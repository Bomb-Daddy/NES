# Province_30

Source map verified statically; art is PROTOTYPE, not approved final. Castle 10,6; offset 0x278CD.
