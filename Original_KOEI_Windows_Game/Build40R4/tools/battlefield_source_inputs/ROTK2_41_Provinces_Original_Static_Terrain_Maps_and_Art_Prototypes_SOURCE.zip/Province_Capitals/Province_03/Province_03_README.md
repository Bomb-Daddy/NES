# Province_03

Source map verified statically; art is PROTOTYPE, not approved final. Castle 7,4; offset 0x27093.
