# Province_22

Source map verified statically; art is PROTOTYPE, not approved final. Castle 9,5; offset 0x2765D.
