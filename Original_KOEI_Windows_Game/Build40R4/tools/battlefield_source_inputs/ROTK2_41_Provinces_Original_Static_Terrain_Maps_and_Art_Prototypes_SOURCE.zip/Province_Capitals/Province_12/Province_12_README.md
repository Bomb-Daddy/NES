# Province_12

Source map verified statically; art is PROTOTYPE, not approved final. Castle 8,6; offset 0x27351.
