# Province_04

Source map verified statically; art is PROTOTYPE, not approved final. Castle 7,3; offset 0x270E1.
