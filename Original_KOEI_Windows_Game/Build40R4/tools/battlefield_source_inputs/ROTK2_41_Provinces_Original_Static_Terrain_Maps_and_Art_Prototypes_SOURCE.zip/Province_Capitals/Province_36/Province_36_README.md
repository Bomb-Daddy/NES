# Province_36

Source map verified statically; art is PROTOTYPE, not approved final. Castle 11,8; offset 0x27AA1.
