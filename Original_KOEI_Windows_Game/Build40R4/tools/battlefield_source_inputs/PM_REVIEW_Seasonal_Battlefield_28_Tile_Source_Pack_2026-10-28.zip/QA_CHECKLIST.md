# QA — Seasonal battlefield tiles

## Asset extraction completed
- [x] 7 terrain codes × 4 seasons = 28 source-derived crops.
- [x] Every seasonal variant has unique deterministic asset ID and hash.
- [x] Submitted reference sheet preserved unmodified.
- [x] CSV and JSON manifests agree.
- [x] All 28 PNGs decode and are nonempty.

## Native Windows game acceptance still pending
- [ ] Renderer maps terrain code 0..6 exactly to each seasonal variant.
- [ ] 41 province maps remain byte-identical in terrain type / 13×12 shape.
- [ ] Spring, summer, autumn, winter show correctly in a real battle.
- [ ] Changing season updates visuals only; no unapproved gameplay effect.
- [ ] Sprite/unit overlays, castle/fort placement and cursor remain visible.
- [ ] No seams / unacceptable interpolation when tile placed adjacent to itself.
- [ ] Scale at 1280×720 and Xbox controller UX tested.
- [ ] Save/load retains exact same battle terrain and correct current-season texture.
- [ ] 41 province × 4 season screenshot/regression sweep (or justified sample + shape assertions).

Original NES tile mining belongs to `Original_NES_Tiles` and remains separately sourced; DO NOT overwrite it with enhanced artwork.
