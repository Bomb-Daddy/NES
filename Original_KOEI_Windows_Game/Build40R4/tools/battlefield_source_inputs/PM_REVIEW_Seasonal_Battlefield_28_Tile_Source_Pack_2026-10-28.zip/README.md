# ROTK2 — Seasonal Battlefield Terrain Art Replacement

**Date:** 2026-10-28  
**Status:** Director-supplied art assigned for use; integration into the game runtime is not yet verified.  
**Destination:** Google Drive / Retro Gaming / ROTK2_NES_Windows / assets / Battlefield_Maps_41_Provinces / Seasonal_Terrain_Tiles

## Director decision
Use the uploaded **28 terrain illustrations** as four seasonal variants of seven existing battlefield terrain codes. **Season variants are intended to appear in the actual battlefield renderer.** This is not simply a reference collage or a proposed asset category.

| Battlefield CSV code | Terrain | Spring | Summer | Autumn | Winter |
|---:|---|:---:|:---:|:---:|:---:|
| 0 | Grassland (grass) | Yes | Yes | Yes | Yes |
| 1 | Forest | Yes | Yes | Yes | Yes |
| 2 | Hills | Yes | Yes | Yes | Yes |
| 3 | Mountains | Yes | Yes | Yes | Yes |
| 4 | Water | Yes | Yes | Yes | Yes |
| 5 | Fort | Yes | Yes | Yes | Yes |
| 6 | Castle | Yes | Yes | Yes | Yes |

## How to use

For every battlefield cell `(province_id, row, column)` read the **unchanged province terrain code** from the extracted battlefield CSV/JSON and select the PNG by the **current game season** using `seasonal_battlefield_tile_registry.json`. The lookup is `tiles[season][str(terrain_code)]`. The 41 existing province maps, ROM offsets, movement/collision logic and geometry are preserved. Terrain semantics and unit movement should continue to be governed by game data, not image colors.

**The original 41 provinces use 13 columns × 12 rows of codes 0..6.** Their field and archive index have previously been documented under `Battlefield_Maps_41_Provinces`, with an original reference archive `Province_Capitals/Province_PP/Province_PP_Terrain_Cells.csv` for each province. Never replace those CSVs with image pixels. Avoid changing all province maps when the calendar advances; only change the presentation texture keyed to the season.

**Season definition:** spring, summer, autumn, winter. Derive season boundaries from the authoritative campaign calendar. No arbitrary hard-coded month mapping is imposed by this asset pack. The package defines the artwork lookup, not weather or movement modifiers. Do not claim gameplay winter penalties or water freeze effects without separately approved rules.

**Geometry note:** The NES extraction uses a 16×16-pixel composite cell constructed from 2×2 NES CHR tiles; these user-supplied pictures are larger presentation illustrations, cropped from a 1536×1024 reference sheet. They are not replacement CHR bytes. Render using the game's existing logical cell geometry, with pixel-perfect nearest-neighbor sampling and explicit sizing rules. They must not inadvertently change placement of units, fortifications or hex staggering. These crops aren't proven seamless as repeating textures, so check edges and visibility with real battle screens.

**Preservation:** Keep `Original_NES_Tiles/` read-only and separate. It records actual ROM-derived graphics and confidence labels. The new tiles replace artwork for the enhanced visual mode but do not retroactively prove anything about the original game, or alter its verified terrain encoding.

## Contents

- `source/seasonal_battlefield_terrain_reference_7x4.png` — unchanged submitted sheet.
- `tiles/<season>/terrain_<code>_<name>_<season>.png` — 28 lossless separated illustrations.
- `seasonal_battlefield_tile_manifest.csv` — exact crop pixel coordinates, file dimensions, SHA-256 and status.
- `seasonal_battlefield_tile_registry.json` — 4×7 season/terrain code lookup for the renderer.
- `QA_CHECKLIST.md` — integration tests and acceptance status.

## Source provenance

- Submitted 2026-10-28 in project chat as a single rendered collage. Source SHA-256: `9eb213cfa0932c03d75495cf25c9a2a05f648314c8cf43b3787c6b04c50a9dd4`.
- Column order: Grassland, Forest, Hills, Mountains, Water, Fort, Castle.
- Row order: Spring, Summer, Autumn, Winter.
- Original ROM terrain code 0..6 mapping corroborated by `Original_NES_Tiles/KAUKAU_BATTLE_TERRAIN_INSTRUCTIONS.md`, but **the appearance of these submitted seasonal variants is independent user art, not an NES extraction.**

## Implementation acceptance

Not yet marked `TESTED_PORT`. To accept, render a fixed province in every season and verify exactly one correct variant per terrain code without altering the 13×12 grid, unit movement rules, height/width layout, or existing saves. All 28 images must load through the game asset manifest and pass hashes.
