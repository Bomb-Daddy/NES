#!/usr/bin/env python3
import hashlib,json,os,sys,zipfile
from pathlib import Path
zf=zipfile.ZipFile(Path(__file__).resolve().parent/'KOEI_OG_ZL_REPAIR_ROUND4_20261031.zip')
m=json.loads(zf.read('PATCH_MANIFEST.json'))
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
actions=[]
for name,desc in m['changed'].items():
 p=root/name
 if not p.is_file():raise SystemExit('MISSING '+name)
 current=sha(p.read_bytes())
 if current==desc['after_sha256']:continue
 if current!=desc['before_sha256']:raise SystemExit('SOURCE MISMATCH '+name+'; no writes')
 actions.append((p,zf.read('new_files/'+name)))
for name,desc in m['added'].items():
 p=root/name
 if p.exists():
  if sha(p.read_bytes())!=desc['after_sha256']:raise SystemExit('EXISTING FILE MODIFIED '+name+'; no writes')
 else:actions.append((p,zf.read('new_files/'+name)))
for p,data in actions:
 p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_name(p.name+'.r4tmp')
 with tmp.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
print('R4 PATCH PASS',len(actions),'writes')
