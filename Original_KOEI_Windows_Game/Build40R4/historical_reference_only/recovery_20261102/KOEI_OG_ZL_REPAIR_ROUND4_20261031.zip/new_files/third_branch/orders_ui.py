"""Live native Tk orders, not stubs: each supported order previews and commits
through the original-game Campaign command bus and persistent state.

A player can inspect all provinces, but only issue orders from player-controlled
provinces. All order parameters are typed; invalid values fail before commit.
"""
from __future__ import annotations
from .integrated import COMMANDS, DIPLO, PRICE_CENTS, BP_COST
from .player_text import officer_name, faction_name, province_name, order_summary, explain_error

WORKERS=('farmers','town','artisans','metalworkers','resources','unassigned','land','flood')
TRAITS=('politics','war','leadership','intelligence','charisma')

# name -> (engine command, ordered fields). Values for fields are UI defaults.
SPECS={
 'Cultivate':('cultivate',()),
 'Allocate Workers':('allocate_workers',(('source',WORKERS,'unassigned'),('target',WORKERS,'farmers'),('count',None,'10'))),
 'Distribute Food':('distribute_food',(('units',None,'10'),)),
 'Distribute Goods':('distribute_goods',(('units',None,'3'),)),
 'Recruit':('recruit',(('count',None,'10'),)),
 'Recruit Officer':('recruit_officer',(('officer_id',None,'nes:000'),)),
 'Assign Troops':('assign_troops',(('target_officer',None,'O02'),('count',None,'10'))),
 'Disband Soldiers':('disband_troops',(('count',None,'10'),)),
 'Move Army':('relocate_army',(('target',None,'p1'),)),
 'Occupy Vacant Province':('occupy_vacant',(('target',None,'p1'),)),
 'Market':('market',(('commodity',tuple(PRICE_CENTS),'food'),('side',('buy','sell'),'buy'),('units',None,'5'))),
 'Train Officer':('train',(('trait',TRAITS,'war'),('effort',None,'1'))),
 'Transport':('transport',(('target',None,'p1'),('commodity',('gold','food','specialty','troops','metal','arms','furs'),'food'),('units',None,'10'))),
 'Appoint Governor':('appoint_governor',(('officer',None,'O01'),('focus',('farms','industry','defense'),'farms'))),
 'Plan Attack':('plan_attack',(('target',None,'p1'),)),
 'Attack':('attack',(('target',None,'p1'),('troops',None,'80'))),
 'Ally':('Ally',(('target',None,'B'),)),
 'Joint':('Joint',(('target',None,'B'),('objective',None,'p1'),('promised_troops',None,'20'))),
 'Marry':('Marry',(('target',None,'B'),)),
 'Give':('Give',(('target',None,'B'),('gold_cents',None,'500'))),
 'Cancel Alliance':('Cancel',(('target',None,'B'),)),
 'Threat':('Threat',(('target',None,'B'),)),
}
assert {c for c,_ in SPECS.values()} == COMMANDS - {'battle_move','battle_attack','battle_end_turn','battle_auto'}, 'Unexposed main-game command'
NUMERIC_FIELDS={'count','units','effort','troops','promised_troops','gold_cents'}
PROVINCE_FIELD_CMDS={'cultivate','allocate_workers','distribute_food','distribute_goods','recruit'}


def params_for_order(name, field_values, current_province):
    """Convert form values into the actual command's validated parameter shape."""
    if name not in SPECS:
        raise ValueError('Unknown order')
    cmd,fields=SPECS[name]
    required={key for key,_,_ in fields}
    if set(field_values)!=required:
        raise ValueError('Missing or unknown order parameter')
    params={}
    for key,choices,_ in fields:
        raw=str(field_values[key]).strip()
        if key in NUMERIC_FIELDS:
            if not raw or not raw.isascii() or not raw.isdecimal() or int(raw)<1:
                raise ValueError(f'{key} must be a positive integer')
            params[key]=int(raw)
        else:
            if not raw:raise ValueError(f'{key} is required')
            if choices and raw not in choices:raise ValueError(f'{key} is not in the allowed list')
            params[key]=raw
    if cmd in PROVINCE_FIELD_CMDS:
        params['province_id']=current_province
    return cmd,params


class OrdersWindow:
    def __init__(self, parent):
        import tkinter as tk
        from tkinter import ttk
        self.tk,self.ttk=tk,ttk
        self.parent=parent
        self.root=tk.Toplevel(parent.root)
        self.root.title('Province Orders — Review and Confirm')
        self.root.geometry('760x600')
        self.root.configure(bg='#122237')
        self.root.resizable(False,False)
        self.pid=f'p{parent.selected}'
        self.fields={};self.field_display={};self.controller_index=0;self.pending=None
        owner=parent.c.state['owners'][self.pid]
        tk.Label(self.root,text=f'Province {parent.selected:02d} | {faction_name(parent.c.state,owner)}',font=('Arial',15,'bold'),bg='#122237',fg='#f5d58c').pack(pady=5)
        officers=[oid for oid,o in sorted(parent.c.state['core']['officers'].items())
                  if o['province_id']==self.pid and parent.c.state['officer_faction'][oid]==parent.player]
        if owner!=parent.player or not officers:
            tk.Label(self.root,text='INSPECT ONLY: not a player-controlled province.').pack()
            self.root.after(10,lambda:self.root.focus_force())
            return
        self.actor=tk.StringVar(value='');self.order=tk.StringVar(value='Cultivate')
        self.available_officers=officers
        self.actor_labels={oid:f'{officer_name(parent.c.state,oid)} — BP {parent.c.state["core"]["officers"][oid]["bp"]}' for oid in officers}
        self.actor_display=tk.StringVar(value='Choose officer before issuing orders')
        top=tk.Frame(self.root,bg='#122237');top.pack(pady=8)
        tk.Label(top,text='Officer',bg='#122237',fg='#f0dfbc').grid(row=0,column=0)
        actor_box=ttk.Combobox(top,textvariable=self.actor_display,
            values=[self.actor_labels[oid] for oid in officers],state='readonly',width=30)
        actor_box.grid(row=0,column=1,padx=8)
        def choose_actor(event=None):
            chosen=next((oid for oid,label in self.actor_labels.items() if label==self.actor_display.get()),None)
            if chosen:self.actor.set(chosen)
        actor_box.bind('<<ComboboxSelected>>',choose_actor)
        self.actor.trace_add('write',lambda *_:self.actor_display.set(self.actor_labels.get(self.actor.get(),'Choose officer before issuing orders')))
        tk.Label(top,text='Order',bg='#122237',fg='#f0dfbc').grid(row=1,column=0,pady=8)
        selector=ttk.Combobox(top,textvariable=self.order,values=list(SPECS),state='readonly',width=30)
        selector.grid(row=1,column=1,padx=8)
        selector.bind('<<ComboboxSelected>>',lambda e:self._fields())
        self.fieldframe=tk.Frame(self.root,bg='#122237');self.fieldframe.pack(fill='both',padx=20,pady=10)
        self.fields={}
        self.info=tk.StringVar(value='Select an officer and order. Preview is read-only; confirm makes one saved change.')
        tk.Label(self.root,textvariable=self.info,wraplength=690,justify='left',fg='#f0dfbc',bg='#122237',font=('Arial',12)).pack(pady=12)
        actions=tk.Frame(self.root,bg='#122237');actions.pack(pady=8)
        tk.Button(actions,text='1. Preview order',command=self.submit,font=('Arial',12),width=18).pack(side='left',padx=8)
        tk.Button(actions,text='2. Confirm order',command=self.confirm_order,font=('Arial',12),width=18).pack(side='left',padx=8)
        tk.Button(self.root,text='Cancel / Close',command=self.close,font=('Arial',11)).pack()
        self._fields()
        self.root.protocol('WM_DELETE_WINDOW',self.close)
    def close(self):
        self.pending=None
        self.root.destroy()
    def _controller_items(self):
        if not hasattr(self,'actor'):return [('close',None)]
        return [('actor',self.actor),('order',self.order)]+[(name,var) for name,var in self.fields.items()]+[('confirm',None),('close',None)]
    def on_nes_button(self,button):
        """NES D-pad moves form focus/changes value, A selects/confirms, B cancels."""
        if button=='b':
            if self.pending is not None:
                self.pending=None;self.info.set('Order preview cancelled; no state changed')
            else:self.close()
            return
        if button=='start':return self.parent.pause()  # NES Start opens the canonical Save/Load menu; A confirms an order
        if button=='select':
            self.controller_index=1 if self.fields else 0
            return
        choices=self._controller_items()
        self.controller_index=min(self.controller_index,len(choices)-1)
        if button in ('up','down'):
            self.controller_index=(self.controller_index + (-1 if button=='up' else 1))%len(choices)
            if hasattr(self,'info'):self.info.set('Controller field: '+choices[self.controller_index][0])
            return
        name,var=choices[self.controller_index]
        if button=='a':
            if name=='confirm':return self.controller_submit()
            if name=='close':return self.close()
        if name in ('confirm','close'):return
        if button not in ('a','left','right'):return
        values=()
        if name=='actor':
            values=tuple(oid for oid,o in sorted(self.parent.c.state['core']['officers'].items())
                  if o['province_id']==self.pid and self.parent.c.state['officer_faction'][oid]==self.parent.player)
        elif name=='order':values=tuple(SPECS)
        else:
            specs={key:(c,d) for key,c,d in SPECS[self.order.get()][1]}
            if name in specs:values=tuple(specs[name][0] or ())
        if not values and name in ('target','objective') and var.get().startswith('p'):
            values=tuple('p'+str(n) for n in range(1,42))
        if not values and name=='target' and SPECS[self.order.get()][0] in DIPLO:
            values=tuple(f for f in sorted(self.parent.c.state['factions'])
                         if f!=self.parent.player and self.parent.c.state['factions'][f]['alive'])
        if not values and name=='officer_id':
            from .historical_s1 import list_recruitable
            values=tuple(list_recruitable(self.parent.c.state,self.pid))
        if not values and name=='target_officer':
            values=tuple(oid for oid,off in sorted(self.parent.c.state['core']['officers'].items())
                         if off['province_id']==self.pid and self.parent.c.state['officer_faction'][oid]==self.parent.player)
        if not values and name=='officer':
            values=tuple(oid for oid in sorted(self.parent.c.state['core']['officers'])
                  if self.parent.c.state['officer_faction'][oid]==self.parent.player)
        if values:
            if var.get() not in values:
                chosen=values[-1] if button=='left' else values[0]
            else:
                index=values.index(var.get())
                chosen=values[(index+(-1 if button=='left' else 1))%len(values)]
            var.set(chosen)
            if name=='order':
                self._fields()
                self.controller_index=1
        else:
            raw=var.get()
            if raw.isascii() and raw.isdecimal():var.set(str(max(1,int(raw)+(-1 if button=='left' else 1))))
            elif name in ('target','objective') and raw.startswith('p') and raw[1:].isdecimal():
                var.set('p'+str(1+(int(raw[1:])-1+(-1 if button=='left' else 1))%41))
        self.pending=None
    def controller_submit(self):
        """Two-step PREVIEW then COMMIT with no keyboard/mouse/modal dialog required."""
        if not hasattr(self,'actor'):return
        try:
            kind,params=params_for_order(self.order.get(),{k:v.get() for k,v in self.fields.items()},self.pid)
            actor=self.actor.get()
            if not actor or actor not in self.available_officers:
                raise ValueError('Choose an eligible officer first')
            fingerprint=self.parent.c.fingerprint
            candidate=(kind,params,actor,fingerprint)
            if self.pending!=candidate:
                quote=self.parent.c.preview(kind,actor,params,'gamepad-preview:'+fingerprint[:12])
                self.pending=candidate
                before=self.parent.c.state['core']['officers'][actor]['bp']
                cost=BP_COST.get(kind,0)
                self.info.set('PREVIEW — '+order_summary(self.parent.c.state,kind,params,quote['result'],actor)
                    +f'  Body Points: {before} - {cost} = {before-cost}. '
                     'Confirm again to commit ONCE; Back cancels without changing the game.')
                return
            self.pending=None
            if self.parent.issue(kind,params,actor=actor,confirm=False):
                self.info.set('Committed '+kind+' once and autosaved. '+
                    f'{officer_name(self.parent.c.state,actor)} now has '+
                    str(self.parent.c.state['core']['officers'][actor]['bp'])+' BP.')
            else:self.info.set('Order rejected without committing. Inspect main status.')
        except Exception as exc:  # No state mutation: preview was rejected.
            self.pending=None
            self.info.set('Order unavailable: '+explain_error(exc))
            # Retain the exact engine error for developer diagnostics while
            # keeping raw codes and paths out of normal player-facing windows.
            import logging
            logging.getLogger(__name__).debug('Order preview rejected: %r',exc)
    def _fields(self):
        for widget in self.fieldframe.winfo_children():widget.destroy()
        self.fields={};self.field_display={};self.pending=None
        _,spec=SPECS[self.order.get()]
        pid=self.pid
        for idx,(name,choices,default) in enumerate(spec):
            choices=tuple(choices or ())
            cmd=SPECS[self.order.get()][0]
            if name=='target' and cmd in DIPLO:
                choices=tuple(x for x in sorted(self.parent.c.state['factions'])
                     if x!=self.parent.player and self.parent.c.state['factions'][x]['alive'])
            elif name in ('target','objective') and not choices:
                choices=tuple('p'+str(i) for i in range(1,42))
            elif name in ('target_officer','officer') and not choices:
                choices=tuple(oid for oid in sorted(self.parent.c.state['core']['officers'])
                      if self.parent.c.state['officer_faction'][oid]==self.parent.player)
            elif name=='officer_id' and not choices:
                from .historical_s1 import list_recruitable
                choices=tuple(list_recruitable(self.parent.c.state,pid))
            value=default
            if name=='officer':value=self.actor.get()
            elif name=='target' and name not in ('faction',):
                command=SPECS[self.order.get()][0]
                if command in DIPLO:
                    owner=self.parent.player
                    value=next((f for f in sorted(self.parent.c.state['factions']) if f!=owner and self.parent.c.state['factions'][f]['alive']),'B')
                else:
                    ns=self.parent.c.state['neighbors'][pid]
                    friends=(n for n in ns if self.parent.c.state['owners'][n]==self.parent.player)
                    enemies=(n for n in ns if self.parent.c.state['owners'][n] not in (self.parent.player,None))
                    value=next(friends if command in ('transport','relocate_army') else enemies, ns[0] if ns else 'p1')
            if name=='target_officer':
                available=[oid for oid,off in sorted(self.parent.c.state['core']['officers'].items())
                           if off['province_id']==pid and self.parent.c.state['officer_faction'][oid]==self.parent.player and oid!=self.actor.get()]
                value=available[0] if available else self.actor.get()
            if name=='objective':value=next((p for p in self.parent.c.state['owners'] if self.parent.c.state['owners'][p]!=self.parent.player),'p1')
            if choices and value not in choices:value=choices[0]
            var=self.tk.StringVar(value=value)
            self.fields[name]=var
            self.tk.Label(self.fieldframe,text=name.replace('_',' ').title(),width=18,anchor='e',bg='#122237',fg='#f0dfbc').grid(row=idx,column=0,pady=5)
            if choices:
                labels={str(x):self._choice_label(name,str(x)) for x in choices}
                display=self.tk.StringVar(value=labels.get(str(value),str(value)))
                self.field_display[name]=display
                combo=self.ttk.Combobox(self.fieldframe,textvariable=display,
                    values=list(labels.values()),state='readonly',width=36)
                combo.grid(row=idx,column=1,pady=5)
                def set_value(event=None, v=var, d=display, choices=labels):
                    chosen=next((k for k,text in choices.items() if text==d.get()),None)
                    if chosen is not None:v.set(chosen)
                combo.bind('<<ComboboxSelected>>',set_value)
                var.trace_add('write',lambda *_,v=var,d=display,choices=labels:
                    d.set(choices.get(v.get(),v.get())))
            else:self.tk.Entry(self.fieldframe,textvariable=var,width=38,font=('Arial',12)).grid(row=idx,column=1,pady=5)
    def _choice_label(self,field,value):
        if field in ('target','objective') and value.startswith('p'):
            return province_name(self.parent.c.state,value)
        if field in ('target','objective') and value in self.parent.c.state['factions']:
            return faction_name(self.parent.c.state,value)
        if field in ('officer','target_officer','officer_id'):
            return officer_name(self.parent.c.state,value)
        return value.replace('_',' ').title()

    def submit(self):
        # Repeated clicks on Preview alone can NEVER issue an action.
        if self.pending is not None:
            self.info.set('Already previewed. Select Confirm order to commit, or Back to cancel.')
            return
        self.controller_submit()

    def confirm_order(self):
        # A different deliberate button is required on mouse/keyboard.
        if self.pending is None:
            self.info.set('Preview the order first. No state has changed.')
            return
        self.controller_submit()
