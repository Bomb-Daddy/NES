"""Playable 41-province STRATEGIC VIEW in the original-game integrated engine.

Run: PYTHONPATH=. python -m third_branch.strategic_game
Requires Pillow and Tkinter (both supported on Linux/Windows PCs).
This is an INTEGRATION SLICE, not final game, final emblems, or NES geography.
"""
from __future__ import annotations
import argparse, json, os
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from og.core.fixed import CoreError
from .integrated import new_campaign_41, save_file, load_file
from .historical_s1 import new_campaign_historical_s1
from .ai import take_turn
from .xbox_controller import NesInputRouter, MAPPING_LABEL
from .input_bindings import InputBindings, BindingError
from .context_help import help_for
from .audio_system import GameAudio
from .player_text import province_name, faction_name, officer_name, describe_effects, order_summary, monthly_summary, journal_entry, advisor_text, explain_error

ASSETS = Path(__file__).resolve().parent / 'assets' / 'strategic'
SLOTS = json.loads((ASSETS / 'province_slots_41.json').read_text())['province_slots']
COLORS = {'A':(209,76,71,255),'B':(76,123,212,255),'C':(74,179,112,255)}
SEASONS = ('spring','summer','autumn','winter')
W,H=1280,720
MAP_W=960

def province_at_pixel(x,y):
    """Select the nearest visible province within a bounded area, never the sidebar.

    The artwork has no verified province polygons. A nearest-center region is a
    transparent accessibility fallback, not a claim to recovered NES borders.
    """
    if not (0 <= x < MAP_W and 0 <= y < H):return None
    centers=[]
    for code,slot in SLOTS.items():
        px,py,pw,ph=slot['rect_px']
        sx=(px+pw/2)*(MAP_W/1448);sy=(py+ph/2)*(H/1086)
        centers.append(((x-sx)**2+(y-sy)**2,int(code)))
    centers.sort()
    if centers[0][0]>75**2:return None
    # Adjacent emblems can be close together; the exact emblem center always wins.
    return centers[0][1]

def _ui_font(size=16, bold=False):
    """Use a known proportional font rather than PIL's tiny 10px fallback."""
    for name in (('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf'),
                 ('LiberationSans-Bold.ttf' if bold else 'LiberationSans-Regular.ttf')):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def _fit_ui_text(draw, text, font, max_width):
    """Elide only when absolutely necessary: never draw beyond the sidebar."""
    text=str(text)
    if draw.textbbox((0, 0), text, font=font)[2] <= max_width:
        return text
    while text and draw.textbbox((0, 0), text+'…', font=font)[2] > max_width:
        text=text[:-1]
    return text+'…'


def render(campaign, selected=1, season_override=None):
    """Draw actual 41-province terrain and a nonoverlapping readable sidebar.

    The entire 1280x720 layout has dedicated vertical regions for map metadata,
    the status text, and the fifteen live-action buttons.  No default PIL bitmap
    fonts or unconstrained text are used on this player-facing screen.
    """
    if sorted(int(k) for k in SLOTS)!=list(range(1,42)):
        raise ValueError('Strategic art missing some province slots')
    if selected not in range(1,42):raise ValueError('Province must be 1..41')
    season=SEASONS[((campaign.state['month']-1)//3)%4] if season_override is None else season_override
    if season not in SEASONS:raise ValueError('Invalid season')
    bg=Image.open(ASSETS / f'{season}_clean_41.png').convert('RGBA')
    overlay=Image.new('RGBA', bg.size, (0,0,0,0))
    draw=ImageDraw.Draw(overlay)
    for i in range(1,42):
        owner=campaign.state['owners'][f'p{i}']
        if owner is None:continue
        x,y,w,h=SLOTS[str(i)]['rect_px']
        col=COLORS.get(owner,((64+37*int(owner[1:]))%190+30,(75+53*int(owner[1:]))%170+40,(68+71*int(owner[1:]))%150+65,255) if owner.startswith('R') else (170,143,102,255))
        draw.rectangle((x,y,x+w-1,y+h-1),fill=col,outline=(15,15,15,255),width=2)
        draw.polygon(((x+6,y+6),(x+w-7,y+6),(x+w//2,y+h-7)),fill=(245,233,197,255))
        if i==selected:draw.rectangle((x-3,y-3,x+w+2,y+h+2),outline=(246,237,105,255),width=3)
    bg=Image.alpha_composite(bg,overlay)
    left=bg.resize((MAP_W,H),Image.Resampling.NEAREST)
    frame=Image.new('RGB',(W,H),(14,23,35));frame.paste(left.convert('RGB'),(0,0))
    d=ImageDraw.Draw(frame)
    line=(114,107,76)
    for y in (0,56,246,328,438):d.line((960,y,1279,y),fill=line,width=2)
    heading=_ui_font(17,True);body=_ui_font(15);small=_ui_font(14)
    gold=(235,216,162);white=(224,230,237)
    def t(x,y,txt,font=body,color=white,width=275):
        d.text((x,y),_fit_ui_text(d,txt,font,width),font=font,fill=color)
    p=campaign.state['core']['provinces'][f'p{selected}']
    owner=campaign.state['owners'][f'p{selected}']
    extra=campaign.state['extras'][f'p{selected}']
    owner_label=campaign.state['factions'][owner]['name'] if owner else 'VACANT'
    t(974,15,f'ORIGINAL KOEI  |  {season.upper()}',heading,gold,295)
    t(974,70,f'PROVINCE {selected:02d}',heading,gold)
    t(974,102,'Ruler: '+owner_label,body,white)
    t(974,130,f'Month {campaign.state["month"]:03d}',small,white)
    t(974,162,f'Food {p["food_units"]}    Gold {p["treasury_gold_cents"]//100}',body,white)
    t(974,187,f'Troops {p["troops"]}    Support {p["support_ticks"]//50000}',body,white)
    t(974,212,f'Metal {extra["metal"]}    Arms {extra["arms"]}    Land {p["cultivation"]}',small,white)
    t(974,259,'ADJACENT PROVINCES',small,gold)
    neighbors=', '.join(x[1:] for x in campaign.state['neighbors'][f'p{selected}']) or 'None'
    # Fixed two-line neighboring region; the full list is available in Province.
    split=neighbors[:30].rfind(', ')
    if split>0 and len(neighbors)>30:
        first,second=neighbors[:split],neighbors[split+2:]
    else:first,second=neighbors,''
    t(974,285,first,body,white)
    if second:t(974,305,second,small,white)
    t(974,445,'ACTIONS  •  Select an order below',small,gold,296)
    # y 338..427 intentionally left blank. A multiline Tk status label owns it.
    # y 480..720 belongs to action buttons, which are real interactive controls.
    return frame

class StrategicWindow:
    def __init__(self, save_path):
        import tkinter as tk
        from PIL import ImageTk
        self.tk=tk
        self.ImageTk=ImageTk
        from .platform_paths import prepare_save_path
        self.path=prepare_save_path(save_path)
        self.c=load_file(self.path) if self.path.exists() else new_campaign_historical_s1(balance_policy='OG_1000_DIRECTOR_V2')
        self.audio=GameAudio()
        initial='R0' if self.c.state.get('source_label')=='ORIGINAL_GAME_HISTORICAL_S1_PROPOSED' else 'A'
        self.player=self.c.state.get('human_faction',initial)
        self.bindings=InputBindings.load()
        if self.player not in self.c.state['factions']:
            self.player=next(iter(self.c.state['factions']))
        self.selected=next((int(p[1:]) for p,f in self.c.state['owners'].items() if f==self.player),1)
        self.counter=0
        self.root=tk.Tk();self.root.title('Original KOEI — Strategy Campaign')
        self.root.geometry('1280x720')
        self.root.resizable(False,False)
        self.canvas=tk.Canvas(self.root,width=1280,height=720,highlightthickness=0)
        self.canvas.pack()
        self.canvas.bind('<Button-1>',self.on_click)
        self.root.bind_all('<KeyPress>',self._keyboard_action,add='+')
        bar=tk.Frame(self.root,background='#101e2c');bar.place(x=963,y=476,width=314,height=241)
        self.action_items=[('Cultivate',self.cultivate),('Feed',self.feed),('Recruit',self.recruit),
                             ('Trade',self.trade),('Attack',self.attack),('Resolve Battle',self.battle),
                             ('End Month',self.month),('Save',self.save),('Load',self.load),
                             ('All Orders',self.orders),('Province',self.open_province),('Advisor',self.advisor),('Journal',self.journal),('Ruler',self.choose_ruler),('Family',self.family_info)]
        self.action_buttons=[];self.command_index=9;self.controller_focus='map';self.pause_dialog=None;self.province_stage=None;self.event_dialog=None;self.info_dialog=None;self.info_text=None;self.help_dialog=None
        for i,(title,method) in enumerate(self.action_items):
            button=tk.Button(bar,text=title,command=method,font=('Arial',11),padx=2,pady=3,bd=1)
            button.grid(row=i//3,column=i%3,padx=1,pady=1,sticky='ew')
            self.action_buttons.append(button)
            button.bind('<Enter>',lambda event,n=i:self._hover_action(n))
        for col in range(3):bar.grid_columnconfigure(col,weight=1)
        self.msg=tk.StringVar(value='Select a province and choose an action. Use Help for controls.')
        tk.Label(self.root,textvariable=self.msg,anchor='nw',justify='left',wraplength=285,
                 fg='#f4d5a5',bg='#101e2c',font=('Arial',11)).place(x=974,y=337,width=296,height=89)
        self.redraw()
        self.audio.play('map',self.selected)
        self.gamepad=NesInputRouter(self.on_nes_button,bindings=self.bindings,raw_receiver=self._raw_pad_button)
        self.root.after(75,self._poll_gamepad)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
    def _adopt_loaded(self,loaded):
        """Adopt one validated campaign and invalidate ALL stale dependent UI views.

        Closing an Orders dialog is essential: its old officer/province/form may
        otherwise remain visible after a load and let a player act in the wrong
        province. The pause/menu owner, if present, survives the transition.
        """
        initial='R0' if loaded.state.get('source_label')=='ORIGINAL_GAME_HISTORICAL_S1_PROPOSED' else 'A'
        player=loaded.state.get('human_faction',initial)
        if player not in loaded.state['factions']:
            raise ValueError('Saved human faction is not in the historical roster')
        # Validation has finished; from here onward all visible dependent panels
        # must describe the new campaign, never an older actor or modal.
        for attr, nested in (('orders_dialog','root'),('province_stage','root'),
                             ('tactical','root'),('ruler_dialog',None),
                             ('info_dialog',None),('help_dialog',None)):
            obj=getattr(self,attr,None)
            if obj is None:continue
            widget=getattr(obj,nested,None) if nested else obj
            try:
                if widget is not None and widget.winfo_exists():widget.destroy()
            except Exception:pass
            setattr(self,attr,None)
        self.info_text=None
        self.c=loaded;self.player=player
        if 'human_faction' not in loaded.state and hasattr(self,'msg'):
            self.msg.set('Legacy save has no ruler selection. Default '+player+'; choose ruler and save to confirm identity.')
        self.selected=next((int(pid[1:]) for pid,owner in loaded.state['owners'].items() if owner==player),1)
        self.redraw()

    def _raw_pad_button(self,physical):
        pause=getattr(self,'pause_dialog',None)
        if pause is None or pause.mode!='pad_capture':return False
        if physical=='b':
            pause.status.set('Controller capture cancelled; B always remains available.')
        else:
            try:
                displaced=self.bindings.remap('pad',pause.binding_action,physical)
                self.bindings.save()
                pause.status.set('Saved controller '+pause.binding_action+' = '+physical+(f' (swapped {displaced})' if displaced else ''))
            except (BindingError,OSError) as exc:pause.status.set('Binding rejected: '+str(exc))
        pause.mode='pad_bindings';pause.refresh()
        return True

    def _keyboard_action(self,event):
        pause=getattr(self,'pause_dialog',None)
        key=event.keysym
        if pause is not None and pause.mode=='key_capture':
            if key=='Escape':pause.status.set('Keyboard capture cancelled; Escape always remains Back.')
            else:
                try:
                    displaced=self.bindings.remap('keyboard',pause.binding_action,key)
                    self.bindings.save()
                    pause.status.set('Saved keyboard '+pause.binding_action+' = '+key+(f' (swapped {displaced})' if displaced else ''))
                except (BindingError,OSError) as exc:pause.status.set('Binding rejected: '+str(exc))
            pause.mode='key_bindings';pause.refresh()
            return 'break'
        action=self.bindings.translate('keyboard',key)
        if action=='help':self.on_nes_button('help');return 'break'
        if getattr(event.widget,'winfo_class',lambda:'' )() in ('Entry','TEntry','TCombobox','Text','Listbox') and action not in ('b','start'):
            return None  # Do not turn editing or native listbox navigation into orders; B/Menu still recover.
        if action:
            self.on_nes_button(action)
            return 'break'
        return None

    def show_context_help(self):
        import tkinter as tk
        if self.help_dialog is not None and self.help_dialog.winfo_exists():
            self.help_dialog.destroy();self.help_dialog=None;return
        topic='Map';surface='strategic';field=None
        if getattr(self,'orders_dialog',None) is not None and self.orders_dialog.root.winfo_exists():
            window=self.orders_dialog
            if hasattr(window,'order'):
                topic=window.order.get();surface='orders'
                items=window._controller_items()
                index=min(window.controller_index,len(items)-1)
                if items[index][0] not in ('order','confirm','close'):field=items[index][0]
        elif self.province_stage is not None and self.province_stage.active():
            from .province_stage import NAV
            topic=NAV[self.province_stage.index];surface='province'
        elif getattr(self,'tactical',None) is not None and self.tactical.root.winfo_exists():
            window=self.tactical
            topic=window.controller_actions[window.controller_index][0]
            surface='battle'
        elif self.pause_dialog is not None and self.pause_dialog.root.winfo_exists():
            entries=self.pause_dialog.entries();topic=entries[self.pause_dialog.index] if entries else 'Settings'
            surface='menu'
        elif self.controller_focus=='actions':topic=self.action_items[self.command_index][0]
        title,body=help_for(topic,surface,field)
        win=tk.Toplevel(self.root);win.title('HELP — '+title);win.geometry('610x310+335+205')
        win.transient(self.root);win.configure(bg='#111e32')
        tk.Label(win,text=title,font=('Arial',15,'bold'),bg='#111e32',fg='#f5db99').pack(pady=12)
        tk.Label(win,text=body,font=('Arial',11),bg='#111e32',fg='#e4eaf4',wraplength=570,justify='left').pack(fill='both',expand=True,padx=20)
        hint=f'Pad {self.bindings.pad["help"].upper()} / Key {self.bindings.keyboard["help"]}: Help   A: Continue   B: Back'
        tk.Label(win,text=hint,bg='#111e32',fg='#f5db99').pack(pady=10)
        win.bind('<Escape>',lambda e:(self.show_context_help(),'break')[-1])
        win.protocol('WM_DELETE_WINDOW',self.show_context_help)
        self.help_dialog=win;win.focus_force()

    def _poll_gamepad(self):
        if not self.root.winfo_exists():return
        self.gamepad.poll()
        self.root.after(75,self._poll_gamepad)
    def close(self):
        if getattr(self,'province_stage',None) is not None and self.province_stage.active():
            self.province_stage.root.destroy()
            self.province_stage=None
        if getattr(self,'event_dialog',None) is not None:
            try:self.event_dialog.destroy()
            except Exception:pass
        self.gamepad.close()
        self.audio.close()
        self.root.destroy()
    def _hover_action(self,index):
        self.command_index=index;self.controller_focus='actions';self._action_cursor()

    def _action_cursor(self):
        for i,button in enumerate(self.action_buttons):
            button.config(relief='sunken' if self.controller_focus=='actions' and i==self.command_index else 'raised',
                          highlightthickness=2 if self.controller_focus=='actions' and i==self.command_index else 0)
    def on_nes_button(self,button):
        if button=='help':return self.show_context_help()
        if getattr(self,'help_dialog',None) is not None and self.help_dialog.winfo_exists():
            if button in ('a','b','start'):
                return self.show_context_help()
            return
        if getattr(self,'ruler_dialog',None) is not None and self.ruler_dialog.winfo_exists():
            if button=='b':self.ruler_dialog.destroy();return
            if button=='a':self.ruler_confirm();return
            if button in ('up','down'):
                box=self.ruler_listbox;n=box.size()
                old=box.curselection();i=((old[0] if old else 0)+(-1 if button=='up' else 1))%n
                box.selection_clear(0,'end');box.selection_set(i);box.activate(i);box.see(i)
            return
        """NES A confirms, B cancels, Start pauses, Select switches focus."""
        if getattr(self,'info_dialog',None) is not None and self.info_dialog.winfo_exists():
            if button in ('a','b','start'):
                self.info_dialog.destroy();self.info_dialog=None;self.info_text=None
            elif button in ('up','down') and self.info_text is not None:
                self.info_text.yview_scroll(-3 if button=='up' else 3, 'units')
            return
        if getattr(self,'event_dialog',None) is not None and self.event_dialog.winfo_exists():
            if button in ('a','b','start'):self._close_event_dialog()
            return
        if self.pause_dialog is not None and self.pause_dialog.root.winfo_exists():
            return self.pause_dialog.on_nes_button(button)
        if getattr(self,'tactical',None) is not None and self.tactical.root.winfo_exists():
            return self.tactical.on_nes_button(button)
        if getattr(self,'orders_dialog',None) is not None and self.orders_dialog.root.winfo_exists():
            return self.orders_dialog.on_nes_button(button)
        if self.province_stage is not None and self.province_stage.active():
            return self.province_stage.on_nes_button(button)
        if button=='start':self.audio.effect('confirm');return self.pause()
        if button=='select':
            self.audio.effect('cursor')
            self.controller_focus='actions' if self.controller_focus=='map' else 'map'
            self._action_cursor()
            self.msg.set('Focus: '+self.controller_focus+'. Press Help for controls.')
            return
        if button=='b':
            self.audio.effect('cancel')
            self.controller_focus='map';self._action_cursor();return
        if self.controller_focus=='map':
            if button=='a':self.audio.effect('confirm');return self.open_province()
            if button in ('left','right','up','down'):
                self.select({'left':-1,'right':1,'up':-10,'down':10}[button])
        elif self.controller_focus=='actions':
            if button in ('left','right','up','down'):
                self.command_index=(self.command_index+{'left':-1,'right':1,'up':-3,'down':3}[button])%len(self.action_items)
                self._action_cursor()
                self.msg.set('Selected action: '+self.action_items[self.command_index][0])
            elif button=='a':
                self.action_items[self.command_index][1]()
    def pause(self):
        self.pause_dialog=NesPauseMenu(self)
    def on_click(self,e):
        v=province_at_pixel(e.x,e.y)
        if v is not None:
            self.selected=v;self.redraw();self.audio.play('map',self.selected);self.audio.effect('confirm');self.open_province()
    def select(self,delta):
        self.selected=1+(self.selected-1+delta)%41;self.redraw();self.audio.play('map',self.selected)
    def redraw(self):
        img=render(self.c,self.selected)
        self.photo=self.ImageTk.PhotoImage(img)
        self.canvas.delete('all');self.canvas.create_image(0,0,anchor='nw',image=self.photo)
        stage=getattr(self,'province_stage',None)
        if stage is not None and stage.active():stage.redraw()
    def open_province(self):
        from .province_stage import ProvinceStage
        if self.province_stage is not None and self.province_stage.active():
            self.province_stage.redraw()
            self.province_stage.root.lift()
            return
        self.province_stage=ProvinceStage(self)

    def actor(self):
        pid=f'p{self.selected}'
        officer=next((oid for oid,o in self.c.state['core']['officers'].items()
                      if o['province_id']==pid and self.c.state['officer_faction'][oid]==self.c.state['owners'][pid]),None)
        if officer is None:raise CoreError('NO_OFFICER','No eligible officer in this province')
        if self.c.state['owners'][pid]!=self.player:
            raise CoreError('ENEMY_CONTROLLED','You may inspect enemy provinces, but not command their officers')
        if self.c.state['officer_faction'][officer]!=self.player:
            raise CoreError('ENEMY_CONTROLLED','Officer does not belong to your faction')
        return officer
    def issue(self,kind,params,actor=None,confirm=False):
        self.counter+=1;rid=f'ui:{self.c.state["month"]}:{self.counter}:{os.getpid()}'
        try:
            if self.c.state['owners'][f'p{self.selected}']!=self.player:
                raise CoreError('ENEMY_CONTROLLED','Cannot command an opponent province')
            if actor is None:
                raise CoreError('ACTOR_REQUIRED','Choose an officer before issuing an order')
            chosen=actor
            o=self.c.state['core']['officers'].get(chosen)
            if not o or o['province_id']!=f'p{self.selected}' or self.c.state['officer_faction'][chosen]!=self.player:
                raise CoreError('BAD_ACTOR','Actor must be an officer of the player in the selected province')
            quote=self.c.preview(kind,chosen,params,rid)
            if confirm:
                from tkinter import messagebox
                if not messagebox.askyesno('Confirm live order',
                      f'{kind}: {params}\n\nPREVIEW: {quote["result"]}\n\nCommit this game-state change?',parent=self.root):
                    self.audio.effect('cancel')
                    self.msg.set('Order cancelled without changes')
                    return False
            staged=self.c.clone()
            result=staged.execute(kind,chosen,params,rid,quote['quote_id'],quote['revision'])
            save_file(staged,self.path)  # Disk commit BEFORE activating staged state
            old_event_count=len(self.c.state.get('event_history',[]))
            self.c=staged
            new_events=self.c.state.get('event_history',[])[old_event_count:]
            self.audio.effect('occupy' if kind=='occupy_vacant' else ('trade' if kind=='market' else 'order'))
            if kind in ('Ally','Joint','Marry','Give','Cancel','Threat'):
                self.audio.play('marriage' if kind=='Marry' else 'diplomacy',loop=False)
            self.msg.set(order_summary(self.c.state,kind,params,result,chosen))
            stage=getattr(self,'province_stage',None)
            if stage is not None and stage.active():stage.speaker=chosen
            if self.c.state.get('battle') and kind=='attack':
                self.battle()
            self.redraw()
            self._show_committed_events(new_events)
            return True
        except (CoreError,OSError,ValueError) as e:
            self.audio.effect('invalid')
            self.msg.set('Order unavailable: '+explain_error(e))
            self.redraw()
            return False
    def family_info(self):
        import tkinter as tk
        from .historical_s1 import officer_family
        p='p'+str(self.selected)
        eligible=[key for key,rec in sorted(self.c.state['core']['officers'].items())
                  if rec['province_id']==p]
        win=tk.Toplevel(self.root);win.title('Officer family relationships')
        win.geometry('760x560')
        widget=tk.Text(win,wrap='word',font=('Arial',12));widget.pack(fill='both',expand=True)
        for key in eligible:
            if key not in self.c.state.get('officer_catalog',{}):continue
            data=officer_family(self.c.state,key)
            widget.insert('end',data['name']+'\n')
            widget.insert('end','Officers in the same historical clan group: '+
                          (', '.join(z['name'] for z in data['shared_group']) or 'None established')+'\n')
            for e in data['curated_relations']:
                a=self.c.state['officer_catalog'][e['from_id']]['name']
                b=self.c.state['officer_catalog'][e['to_id']]['name']
                widget.insert('end',f'  {a} and {b}: {e["type"].replace("_"," ")} (provisional historical research)\n')
            widget.insert('end','\n')
        if not eligible:widget.insert('end','No active officers currently stationed here.')
        widget.configure(state='disabled')
        self.info_dialog=win;self.info_text=widget
        win.bind('<Escape>',lambda e:win.destroy())
    def choose_ruler(self):
        import tkinter as tk
        win=tk.Toplevel(self.root);win.title('Choose historical Scenario 1 ruler')
        win.geometry('640x600')
        choices=sorted(self.c.state['factions'],key=lambda k:(int(k[1:]) if k.startswith('R') and k[1:].isdigit() else k))
        names=[f'{self.c.state["factions"][f]["name"]} — {sum(v==f for v in self.c.state["owners"].values())} provinces' for f in choices]
        tk.Label(win,text='Scenario 1 — Choose your ruler',font=('Arial',16,'bold')).pack(pady=8)
        from .historical_art import ruler_portrait
        board=tk.Frame(win)
        board.pack(fill='both',expand=True,padx=12,pady=6)
        scrollbar=tk.Scrollbar(board)
        scrollbar.pack(side='left',fill='y')
        box=tk.Listbox(board,height=15,exportselection=False,font=('Arial',13),width=36,
                       yscrollcommand=scrollbar.set)
        box.pack(side='left',fill='both',expand=True)
        scrollbar.config(command=box.yview)
        preview=tk.Frame(board,width=170)
        preview.pack(side='right',fill='y',padx=10)
        tk.Label(preview,text='HISTORICAL RULER',font=('Arial',12,'bold')).pack(pady=8)
        photo_label=tk.Label(preview,width=152,height=180,relief='ridge')
        photo_label.pack()
        self.ruler_description=tk.StringVar(value='')
        tk.Label(preview,textvariable=self.ruler_description,wraplength=155,justify='center',font=('Arial',11)).pack(pady=8)
        for name in names:box.insert('end',name)
        index=choices.index(self.player);box.selection_set(index);box.activate(index)
        def show_selected(event=None):
            selected=box.curselection()
            if not selected:return
            faction=choices[selected[0]]
            officer_id=self.c.state.get('ruler_slots',{}).get(faction)
            portrait=None
            if isinstance(officer_id,str) and officer_id.startswith('nes:') and officer_id[4:].isdigit():
                portrait=ruler_portrait(int(officer_id[4:]))
            if portrait is not None:
                self.ruler_photo=self.ImageTk.PhotoImage(portrait.resize((144,176),Image.Resampling.NEAREST))
                photo_label.config(image=self.ruler_photo,text='')
            else:
                photo_label.config(image='',text='Portrait unavailable')
            self.ruler_description.set(names[selected[0]])
        box.bind('<<ListboxSelect>>',show_selected)
        show_selected()
        def confirm():
            row=box.curselection()
            if not row:return
            chosen=choices[row[0]]
            staged=self.c.clone()
            staged.state['human_faction']=chosen
            try:save_file(staged,self.path)
            except OSError as error:
                self.msg.set('Ruler choice could not be saved: '+str(error));return
            self.c=staged;self.player=chosen
            self.selected=next((int(p[1:]) for p,f in self.c.state['owners'].items() if f==self.player),1)
            self.msg.set('Playing as '+self.c.state['factions'][self.player]['name'])
            self.audio.play('map',self.selected);self.audio.effect('confirm')
            win.destroy();self.redraw()
        tk.Button(win,text='Play as selected ruler',command=confirm).pack(pady=4)
        box.bind('<Return>',lambda e:confirm())
        win.protocol('WM_DELETE_WINDOW',win.destroy)
        self.ruler_dialog=win;self.ruler_listbox=box;self.ruler_confirm=confirm
        box.focus_set()
    def open_order(self, name):
        self.orders()
        dialog=getattr(self,'orders_dialog',None)
        if dialog is not None and hasattr(dialog,'order'):
            dialog.order.set(name)
            dialog._fields()
    def cultivate(self):self.open_order('Cultivate')
    def feed(self):self.open_order('Distribute Food')
    def recruit(self):self.open_order('Recruit')
    def trade(self):self.open_order('Market')
    def attack(self):
        # Use the controller-operable Orders UI for both mouse and gamepad paths.
        # tkinter.simpledialog.askinteger required a keyboard on Windows.
        self.orders()
        if hasattr(self.orders_dialog, 'order'):
            self.orders_dialog.order.set('Attack')
            self.orders_dialog._fields()
    def battle(self):
        if not self.c.state['battle']:
            self.msg.set('No battle active');return
        from .tactical_view import TacticalWindow
        self.audio.play('battle');self.audio.effect('battle')
        self.tactical=TacticalWindow(self)
    def month(self):
        from .player_runtime import stage_month_with_opponents
        try:
            staged,result=stage_month_with_opponents(self.c,player=self.player)
            save_file(staged,self.path)  # Do not advance in memory if disk commit fails
            old_event_count=len(self.c.state.get('event_history',[]))
            self.c=staged
            new_events=self.c.state.get('event_history',[])[old_event_count:]
            self.msg.set(monthly_summary(result['opponents'],self.c.state['month']))
            self.audio.play('map',self.selected);self.audio.effect('month')
            self._show_committed_events(new_events)
        except (CoreError,OSError,ValueError) as e:
            self.audio.effect('invalid')
            self.msg.set('Month/Save error: '+str(e))
        self.redraw()
    def _show_committed_events(self, events):
        """Present actual saved events, using actual asset lookup, never random UI images."""
        from .historical_art import event_still_for_committed_record
        self._pending_events=getattr(self,'_pending_events',[])
        self._pending_events.extend(e for e in events if event_still_for_committed_record(e) is not None)
        if self.event_dialog is None or not self.event_dialog.winfo_exists():
            self._next_event_dialog()

    def _close_event_dialog(self):
        if self.event_dialog is not None:
            try:self.event_dialog.destroy()
            except Exception:pass
            self.event_dialog=None
        self.audio.play('map',self.selected)
        self._next_event_dialog()

    def _next_event_dialog(self):
        import tkinter as tk
        from .historical_art import event_still_for_committed_record
        self._pending_events=getattr(self,'_pending_events',[])
        if not self._pending_events:return
        event=self._pending_events.pop(0)
        art=event_still_for_committed_record(event)
        if art is None:return self._next_event_dialog()
        win=tk.Toplevel(self.root);self.event_dialog=win
        win.title('Campaign Event — '+event['kind'].replace('_',' ').title())
        win.geometry('510x430+320+105');win.transient(self.root);win.configure(background='#101a2c')
        self._event_photo=self.ImageTk.PhotoImage(art.resize((336,240),Image.Resampling.NEAREST))
        tk.Label(win,image=self._event_photo,background='#101a2c').pack(pady=8)
        event_text=(f"{province_name(self.c.state,event.get('province_id'))} | "
                    f"Month {event['month']}\n{event['result'].get('text','')}\n"
                    f"{describe_effects(self.c.state,event['result'].get('effects',{}))}")
        tk.Label(win,text=event_text,fg='#e8d3a0',bg='#101a2c',wraplength=490,justify='center').pack()
        tk.Button(win,text='Continue (A / B)',command=self._close_event_dialog).pack(pady=4)
        win.bind('<Return>',lambda e:self._close_event_dialog())
        win.bind('<Escape>',lambda e:self._close_event_dialog())
        win.protocol('WM_DELETE_WINDOW',self._close_event_dialog)
        self.audio.effect('dialog')
        if event['kind']=='ruler_died':self.audio.play('death',loop=False)
        elif event['kind'].startswith('messenger_') or event['kind']=='secret_letter_delivered':
            self.audio.play('diplomacy',loop=False)
        win.lift();win.update_idletasks();win.focus_force()

    def orders(self):
        from .orders_ui import OrdersWindow
        self.orders_dialog=OrdersWindow(self)
    def advisor(self):
        import tkinter as tk
        info=self.c.advice(self.player)
        win=tk.Toplevel(self.root);win.title('Advisor — actual saved game metrics')
        win.geometry('840x620')
        frame=tk.Frame(win);frame.pack(fill='both',expand=True)
        scrollbar=tk.Scrollbar(frame);scrollbar.pack(side='right',fill='y')
        widget=tk.Text(frame,wrap='word',font=('Arial',12),yscrollcommand=scrollbar.set)
        widget.pack(side='left',fill='both',expand=True)
        scrollbar.config(command=widget.yview)
        widget.insert('end',advisor_text(self.c.state,info))
        widget.configure(state='disabled')
        self.info_dialog=win;self.info_text=widget
    def journal(self):
        import tkinter as tk
        win=tk.Toplevel(self.root);win.title('Campaign Journal — actual committed actions')
        win.geometry('900x610')
        frame=tk.Frame(win);frame.pack(fill='both',expand=True)
        scrollbar=tk.Scrollbar(frame);scrollbar.pack(side='right',fill='y')
        widget=tk.Text(frame,wrap='word',font=('Arial',12),yscrollcommand=scrollbar.set)
        widget.pack(side='left',fill='both',expand=True);scrollbar.config(command=widget.yview)
        for entry in reversed(self.c.state['log']):
            widget.insert('end',journal_entry(self.c.state,entry)+'\n\n')
        widget.configure(state='disabled')
        self.info_dialog=win;self.info_text=widget
    def manual_path(self,slot=1):
        return self.path.with_name(self.path.stem+f'_slot{slot}'+self.path.suffix)
    def can_load(self):
        event=getattr(self,'event_dialog',None)
        if event is not None and event.winfo_exists():
            self.msg.set('Dismiss the campaign event before loading a saved game.')
            return False
        return True
    def save(self):
        try:
            save_file(self.c,self.manual_path())
            self.audio.effect('save');self.msg.set('Game saved to Slot 1.')
        except (OSError,CoreError) as e:self.msg.set('Save failed: '+str(e))
    def load(self):
        if not self.can_load():return False
        try:
            self._adopt_loaded(load_file(self.manual_path()))
            self._pending_events=[]
            self.msg.set('Loaded Slot 1. '+faction_name(self.c.state,self.player))
        except (OSError,CoreError,ValueError) as e:
            self.msg.set('Load rejected: '+str(e));return False
        self.redraw();self.audio.play('map',self.selected);self.audio.effect('load')
        return True
    def run(self):self.root.mainloop()

class NesPauseMenu:
    """Controller-accessible save management, with multiple manual slots."""
    def __init__(self,parent):
        tk=parent.tk;self.parent=parent;self.index=0;self.slot=1;self.mode='main'
        self.root=tk.Toplevel(parent.root);self.root.title('NES START — GAME MENU');self.library_page=0
        self.root.geometry('520x650');self.root.transient(parent.root)
        self.heading=tk.Label(self.root,text='NES START MENU',font=('Arial',16,'bold'))
        self.heading.pack(pady=12)
        self.status=tk.StringVar(value='D-pad: select | A: confirm | B: back')
        tk.Label(self.root,textvariable=self.status,wraplength=440).pack(pady=8)
        self.buttons=[]
        for i in range(12):
            b=tk.Button(self.root,text='',command=lambda n=i:self.activate(n),width=42)
            b.pack(pady=2);self.buttons.append(b)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.refresh()
    def slot_path(self,n):
        return self.parent.manual_path(n)
    def entries(self):
        if self.mode=='main':return ['Resume','Save Game','Load Game','Continue Last Save','Return to Main Menu','Exit Game',
                                    'Music: '+('Arranged' if self.parent.audio.mode=='arranged' else 'Off'),
                                    'Sound Effects: '+('On' if self.parent.audio.sfx_enabled else 'Off'),
                                    'Audio Status','Soundtrack Library (15 tracks)', 'Controller Bindings', 'Keyboard Bindings']
        if self.mode in ('pad_bindings','key_bindings'):
            device='pad' if self.mode=='pad_bindings' else 'keyboard'
            return [f'{action.title()}: {self.parent.bindings.binding(device,action)}' for action in self.parent.bindings.pad]+['Restore Defaults','Back']
        if self.mode in ('pad_capture','key_capture'):
            return ['Press new physical button/key now (B or Escape cancels)']
        if self.mode=='library':
            from .audio_system import TRACKS
            nums=range(1,9) if self.library_page==0 else range(9,16)
            labels=[f'{n:02d} '+(TRACKS[n].stem[4:] if n in TRACKS else 'MISSING') for n in nums]
            return labels+(['Next Page'] if self.library_page==0 else ['Previous Page','Back'])
        if self.mode in ('save','load'):
            return [f'Slot {n}: '+('Occupied' if self.slot_path(n).exists() else 'Empty') for n in range(1,6)]+['Back']
        return ['Confirm','Cancel']
    def refresh(self):
        labels=self.entries();self.index%=len(labels)
        for i,b in enumerate(self.buttons):
            b.config(text=labels[i] if i<len(labels) else '',state='normal' if i<len(labels) else 'disabled',relief='sunken' if i==self.index else 'raised')
        self.heading.config(text='NES START — '+self.mode.upper())
    def activate(self,n):
        self.index=n;self.choose()
    def choose(self):
        if self.mode=='main':
            if self.index==0:return self.close()
            if self.index in (1,2):self.mode='save' if self.index==1 else 'load';self.index=0
            elif self.index==3:
                return self.load_path(self.parent.path)
            elif self.index==4:self.mode='return_confirm';self.index=1
            elif self.index==5:self.mode='exit_confirm';self.index=1
            elif self.index==6:
                mode='off' if self.parent.audio.mode=='arranged' else 'arranged'
                played=self.parent.audio.mode_set(mode,self.parent.selected)
                self.status.set(self.parent.audio.status() if played else self.parent.audio.error or self.parent.audio.status())
            elif self.index==7:
                enabled=self.parent.audio.effects_set(not self.parent.audio.sfx_enabled)
                self.status.set('Sound effects '+('enabled' if enabled else 'muted'))
                self.parent.audio.effect('confirm')
            elif self.index==8:self.status.set(self.parent.audio.status())
            elif self.index==9:self.mode='library';self.library_page=0;self.index=0
            elif self.index in (10,11):self.mode='pad_bindings' if self.index==10 else 'key_bindings';self.index=0
        elif self.mode in ('pad_bindings','key_bindings'):
            device='pad' if self.mode=='pad_bindings' else 'keyboard'
            if self.index<9:
                self.binding_action=list(self.parent.bindings.pad)[self.index]
                self.mode='pad_capture' if device=='pad' else 'key_capture'
                self.status.set('Press a NEW '+device+' control for '+self.binding_action+'; B/Escape cancels')
            elif self.index==9:
                self.parent.bindings.reset(device);self.parent.bindings.save()
                self.status.set(device+' restored to safe defaults')
            else:self.mode='main';self.index=10 if device=='pad' else 11
        elif self.mode in ('pad_capture','key_capture'):
            return  # physical input capture owns the next event
        elif self.mode=='library':
            size=8 if self.library_page==0 else 7
            if self.index<size:
                n=1+self.index+8*self.library_page
                self.parent.audio.mode_set('arranged')
                ok=self.parent.audio.play('track:'+str(n))
                self.status.set(f'Track {n:02d}: '+('playing' if ok else self.parent.audio.error or 'unavailable'))
            elif self.library_page==0:self.library_page=1;self.index=0
            elif self.index==7:self.library_page=0;self.index=0
            else:self.mode='main';self.index=9;self.parent.audio.play('map',self.parent.selected)
        elif self.mode in ('save','load'):
            if self.index==5:self.mode='main';self.index=0
            else:
                self.slot=self.index+1
                if self.mode=='save' and self.slot_path(self.slot).exists():self.mode='overwrite_confirm';self.index=1
                elif self.mode=='save':return self.save_path(self.slot_path(self.slot))
                else:return self.load_path(self.slot_path(self.slot))
        elif self.index==1:self.mode='save' if self.mode=='overwrite_confirm' else 'main';self.index=0
        elif self.mode=='overwrite_confirm':return self.save_path(self.slot_path(self.slot))
        elif self.mode in ('exit_confirm','return_confirm'):
            self.close();return self.parent.close()
        self.refresh()
    def save_path(self,path):
        try:
            save_file(self.parent.c,path)
            self.parent.audio.effect('save')
            self.status.set('Saved to Slot '+str(self.slot)+'.')
            self.mode='main';self.index=0
        except (OSError,CoreError) as e:self.status.set('Save failed: '+str(e))
        self.refresh()
    def load_path(self,path):
        if not self.parent.can_load():
            self.status.set('Dismiss the campaign event before loading.')
            self.refresh();return
        try:
            loaded=load_file(path)  # Validate before mutating live state
            if getattr(self.parent,'tactical',None) is not None and self.parent.tactical.root.winfo_exists():
                self.parent.tactical.root.destroy();self.parent.tactical=None
            self.parent._adopt_loaded(loaded);self.parent.audio.play('map',self.parent.selected);self.parent.audio.effect('load')
            self.parent._pending_events=[]
            self.status.set('Loaded '+('autosave' if path==self.parent.path else 'Slot '+str(self.slot))+'.')
            self.mode='main';self.index=0
        except (OSError,CoreError,ValueError) as e:self.status.set('Load failed: '+str(e))
        self.refresh()
    def on_nes_button(self,button):
        if self.mode in ('pad_capture','key_capture'):return
        if button=='b':
            if self.mode=='main':return self.close()
            self.mode='main';self.index=0;self.parent.audio.play('map',self.parent.selected);self.refresh();return
        if button=='start' and self.mode=='main':return self.close()
        if button in ('up','left'):self.index=(self.index-1)%len(self.entries());self.refresh()
        elif button in ('down','right'):self.index=(self.index+1)%len(self.entries());self.refresh()
        elif button=='a':self.choose()
    def close(self):
        self.parent.audio.effect('cancel')
        self.parent.audio.play('map',self.parent.selected)
        self.root.destroy()

def enable_windows_dpi_awareness(platform=None):
    # On high-DPI Windows displays, Tk's nominal 1280x720 pixels must match
    # our map's pointer hitboxes, not a 150%-scaled bitmap.
    import sys
    platform=sys.platform if platform is None else platform
    if platform!='win32':return False
    try:
        import ctypes
        # per-monitor DPI awareness for Tk can yield unstable geometry; use system aware.
        try:return ctypes.windll.shcore.SetProcessDpiAwareness(1) in (0, 0x80070005)
        except (AttributeError,OSError):return bool(ctypes.windll.user32.SetProcessDPIAware())
    except (AttributeError,OSError):return False

def main():
    enable_windows_dpi_awareness()
    from .platform_paths import default_save_path, prepare_save_path
    ap=argparse.ArgumentParser();ap.add_argument('--save',default=None)
    ap.add_argument('--smoke',action='store_true');ap.add_argument('--screenshot',default='41_province_spring.png')
    args=ap.parse_args()
    # Use per-user writable saves on Windows/Linux; older CWD saves are recognized.
    if args.save is None:args.save=str(default_save_path())
    prepare_save_path(args.save)
    if args.smoke:
        c=new_campaign_41();h=c.fingerprint
        c.do('cultivate','O01',{'province_id':'p1'},'smoke:grow')
        c.advance_month();save_file(c,args.save);c2=load_file(args.save)
        assert c.fingerprint==c2.fingerprint and c.fingerprint!=h
        render(c2,41).save(args.screenshot)
        print(json.dumps({'status':'PASS','provinces':len(c2.state['owners']),
                          'graph_edges':sum(map(len,c2.state['neighbors'].values()))//2,
                          'from':h,'after':c2.fingerprint,'season':'spring',
                          'image':args.screenshot,'save':args.save},sort_keys=True))
    else:StrategicWindow(args.save).run()

if __name__=='__main__':main()
