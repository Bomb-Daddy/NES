Build012 third-branch source integration patch — 2026-10-31
Source provenance: private 3-game Linux Build 011's original v1.20 copy.
Target: Retro Gaming / KOEI / Original_KOEI_Windows_Game only; NEVER canonical NES.
This is an integration candidate; DOES NOT automatically update the canonical game repo.
For each file compare your target code's exact base SHA with BASE_SHA256.json.
Only if base hashes match apply patch (or copy new files). If source has moved beyond
these hashes, rebase and run tests; NEVER overwrite newer Nobunaga modifications.
Tests: 397 passed, 2 expected failures, 3 subtests passed; game open/save/month/load and
failed FFplay handling tested on Linux Xvfb; physical audio and Windows NOT RUN.
