# EXEC0047 — Original NES Divide: controller quantity, survivor, and rollback evidence

**Owner/receivers:** Zhuge Liang -> Director, Nobunaga (Genghis Khan Windows implementation), Cao Cao (hostile QA).
**Date:** November 6, 2026. **Project:** standalone Genghis Khan I English NES-to-Windows, approved Shared BP/Rest modified-ROM profile only. **NOT** ROTK II NES or DOS.

## Current truth and limits

This batch actually executed the matching approved modified NES ROM in original Mesen and reached the previously unknown **Move > Divide > numeric quantity > Move where? > destination > result > B** sequence. Starting state had 40 soldiers at (7,7), type0, and deliberately modified Mobility20 to pass the known Divide gate. The original loaded ROM and checkpoint were SHA-pinned. All interactions after that modification used actual controller A, arrows and B through the Mesen bridge.

Native-controlled positive cases: requesting 1, 6, 7 and 8 soldiers, moving one tile right to raw terrain 3 (forest). Source unit remains at (7,7) with 39/34/33/32 respectively. A new slot3 is used at (8,7), with 0/0/1/2 survivors after movement attrition. Even zero-soldier slot3 retains destination coordinates/type/Mobility in immediate record. The source-derived forest casualty rule from EXEC0032, floor(requested*98/100) then additional loss5 at fixed original RNG, agrees with all four; the new contribution here is that the **requested quantity is subtracted from the source BEFORE the split-off group bears terrain losses**. This is a bounded four-case observation, not an assertion of all Divide quantities, ownership rules or battle AI.

For requests1 and6, the UI says that unit3 "bit the dust"; B dismisses the message, a second B finishes the command, refills source Mobility20->10 and increments completion word0->1. For7 and8, one B finishes with the same source refill and completion. All unrelated 18 other unit slots remain unchanged in the captured snapshots; the source and slot3 are the two changed records. Original RNG c7c3f28f2363 -> a31e4ecd8fd1 during the hazard, no extra draw on final B. A separate control selected7 then pressed B **before** target selection: the game said "Can't move there" and a second B returned to quantity prompt. Soldiers, unit slots, RNG and completion word stayed unchanged. Do not call that a completed cancelled order or invent any unobserved refund semantics.

## Implementation artifact

`gk1_divide_contract.c/.h` is a strict, immutable-transaction-style **source-bounded acceptance adapter** with phases QUANTITY, DESTINATION, DESTINATION_ERROR, DEATH_PROMPT, PENDING, DONE. Only the source-profile checkpoint and requested1/6/7/8 are supported; all other quantities/states fail closed. The code uses the already-known exact forest attrition to produce observed results and does not contain ROM bytes or copyrighted media. It is not yet integrated into the full native app shell, and it is not a general Divide algorithm or a playable Windows campaign.

## Commands and evidence

```
cmake -S . -B build-Debug -DCMAKE_BUILD_TYPE=Debug
cmake --build build-Debug -j4
ctest --test-dir build-Debug --output-on-failure
cmake -S . -B build-Release -DCMAKE_BUILD_TYPE=Release
cmake --build build-Release -j4
ctest --test-dir build-Release --output-on-failure
# optional clang/gcc sanitizer:
gcc -std=c11 -Wall -Wextra -Wpedantic -Werror -fsanitize=address,undefined -fno-omit-frame-pointer -O1 -g gk1_divide_contract.c test_gk1_divide_contract.c -o test_asan
ASAN_OPTIONS=detect_leaks=1 ./test_asan
# Private authorized NES capture folder in separate ZIP:
python audit_native.py /authorized/private_capture_dir --out native_manifest.json
```

Executed in this batch: **128 source-bounded C assertions in Debug, Release and ASan+UBSan, all PASS; 58 independent captured-state QA assertions including wrong-slot negative PASS.** Older 0045 source and all economics/audio/melee work not retested. The standalone model is not TESTED_PORT_WINDOWS.

## Final delivery requirements and open work

Nobunaga integrates the accepted Divide command into the same existing C11 Windows/Linux research shell source history (EXEC0046), with controller-only numeric input, visible split unit and exact B phases, then adds a general game engine only from decoded native source rules. Cao Cao mutation-checks source/split ledger, zero-record handling, B rollback and RNG/cost. Zhuge Liang next traces the Divide source caller and boundary quantities/slot exhaustion, then genuine battle victory/defeat and AI. Full 2-scenario campaign, authentic art/audio, durable player save, installer and physical Xbox/Windows release remain incomplete. Publish this handoff to Drive Collaboration with verified source link; raw ROM/checkpoint/screenshot/trace data belong only in private Genghis research Drive.
