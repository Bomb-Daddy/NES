#include "gk1_divide_contract.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned assertions=0;
#define CHECK(c) do{assertions++;if(!(c)){fprintf(stderr,"FAIL line %d %s\n",__LINE__,#c);exit(1);}}while(0)
static void case_one(uint16_t q,uint16_t survivor){
 Gk47Divide s,pre;
 CHECK(gk47_open(&s)==GK47_ACCEPTED);CHECK(s.source_soldiers==40 && s.source_mobility==20);
 pre=s;CHECK(gk47_press_b(&s)==GK47_UNKNOWN);CHECK(memcmp(&pre,&s,sizeof s)==0);
 CHECK(gk47_choose_quantity(&s,q)==GK47_ACCEPTED);
 CHECK(s.phase==GK47_DESTINATION && s.source_soldiers==40 && s.rng48==UINT64_C(0xc7c3f28f2363));
 /* Original controller B after quantity: “Can't move there”; next B
  * dismisses the message. No troop, RNG or completion-word debit. */
 pre=s;CHECK(gk47_press_b(&s)==GK47_REFUSED && s.phase==GK47_DESTINATION_ERROR);
 CHECK(s.source_soldiers==pre.source_soldiers && s.rng48==pre.rng48 && s.completion_word==0);
 CHECK(gk47_press_b(&s)==GK47_ACCEPTED && s.phase==GK47_DESTINATION);
 CHECK(s.source_soldiers==pre.source_soldiers && s.split_soldiers==0);
 pre=s;CHECK(gk47_move_to_observed_forest(&s,9,7)==GK47_UNKNOWN && memcmp(&pre,&s,sizeof s)==0);
 Gk47Result r=gk47_move_to_observed_forest(&s,8,7);
 CHECK(r==(survivor?GK47_ACCEPTED:GK47_DEAD_MESSAGE));
 CHECK(s.source_soldiers==40-q && s.split_soldiers==survivor && s.source_x==7 && s.source_y==7);
 CHECK(s.split_x==8&&s.split_y==7&&s.split_type==0&&s.split_mobility==10);
 CHECK(s.source_mobility==20&&s.completion_word==0 && s.rng48==UINT64_C(0xa31e4ecd8fd1));
 pre=s;CHECK(gk47_move_to_observed_forest(&s,8,7)==GK47_UNKNOWN && memcmp(&pre,&s,sizeof s)==0);
 if(!survivor){CHECK(gk47_press_b(&s)==GK47_ACCEPTED && s.phase==GK47_PENDING);
   CHECK(s.source_mobility==20 && s.completion_word==0);}
 CHECK(gk47_press_b(&s)==GK47_FINISHED);
 CHECK(s.source_mobility==10&&s.completion_word==1&&s.phase==GK47_DONE);
 pre=s;CHECK(gk47_press_b(&s)==GK47_UNKNOWN && memcmp(&pre,&s,sizeof s)==0);
}
static void negative(void){
 Gk47Divide s,prior;
 CHECK(gk47_open(NULL)==GK47_BAD);CHECK(gk47_choose_quantity(NULL,1)==GK47_BAD);
 CHECK(gk47_press_b(NULL)==GK47_BAD);CHECK(gk47_move_to_observed_forest(NULL,8,7)==GK47_BAD);
 CHECK(gk47_open(&s)==GK47_ACCEPTED);
 for(uint16_t q=0;q<=40;q++)if(q!=1&&q!=6&&q!=7&&q!=8){
   prior=s;CHECK(gk47_choose_quantity(&s,q)==GK47_UNKNOWN && memcmp(&s,&prior,sizeof s)==0);
 }
 CHECK(gk47_choose_quantity(&s,7)==GK47_ACCEPTED);
 prior=s;CHECK(gk47_choose_quantity(&s,7)==GK47_UNKNOWN && memcmp(&s,&prior,sizeof s)==0);
 s.source_mobility=19;prior=s;
 CHECK(gk47_move_to_observed_forest(&s,8,7)==GK47_UNKNOWN && memcmp(&s,&prior,sizeof s)==0);
 s.source_mobility=20;s.rng48^=1;prior=s;
 CHECK(gk47_move_to_observed_forest(&s,8,7)==GK47_UNKNOWN && memcmp(&s,&prior,sizeof s)==0);
 s.rng48=UINT64_C(0xc7c3f28f2363);CHECK(gk47_move_to_observed_forest(&s,8,7)==GK47_ACCEPTED);
 s.source_soldiers=100;prior=s;
 CHECK(gk47_press_b(&s)==GK47_UNKNOWN && memcmp(&s,&prior,sizeof s)==0);
}
int main(void){case_one(1,0);case_one(6,0);case_one(7,1);case_one(8,2);negative();
 printf("EXEC0047 captured NES Divide cases and negatives: %u assertions PASS\n",assertions);return 0;}
