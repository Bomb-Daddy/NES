#!/usr/bin/env python3
"""Read already-preserved native Mesen controller captures; no ROM bytes here."""
import argparse,hashlib,json,sys
from pathlib import Path
ROM='4764d46359581be1e7d12bcb85bd375c84cd4497d1084d9d306a6e884afbe7c5'
EMUL='e777af28bc6cc49d2e61ca0c1a82fbccf13811355332a53ea00749fc37a92761'
CORE='0668f6c09bc89a1c8199df6cbf15aeebba243169b30f8116df97127dbfd3d7af'
CHECKPOINT='e1b6266c963a48d736627812d024910b6d600c2ad8571813eb3b0999e0f2938b'
PREFIX={1:'D10_',6:'UP6_',7:'UP7_',8:'UP8_'}
COMMIT={1:'10_commit',6:'13_move_commit',7:'13_move_commit',8:'13_move_commit'}
FINISH={1:'12_b',6:'15_b',7:'14_b',8:'14_b'}
EXPECTED={1:(39,0),6:(34,0),7:(33,1),8:(32,2)}
checks=0

def check(cond,msg):
 global checks
 checks+=1
 if not cond:raise AssertionError(msg)

def load(root,name):
 p=root/(name+'.json')
 return json.loads(p.read_text())

def audit_case(root,q):
 p=PREFIX[q];before=load(root,p+'00_ready');commit=load(root,p+COMMIT[q]);done=load(root,p+FINISH[q]);a=before['unit_bytes'];b=commit['unit_bytes'];c=done['unit_bytes'];surv=EXPECTED[q][1]
 check(len(a)==len(b)==len(c)==220, 'full unit records '+str(q))
 check(a[:6]==[40,0,7,7,0,20], 'initial unit '+str(q))
 check(a[33:35]==[0,0], 'available slot3 '+str(q))
 check(b[0:6]==[EXPECTED[q][0],0,7,7,0,20], 'source commit '+str(q))
 check(b[33:39]==[surv,0,8,7,0,10], 'split dest/remaining '+str(q))
 check(before['rng']=='c7c3f28f2363' and commit['rng']=='a31e4ecd8fd1', 'rng '+str(q))
 check(before['completion_word']==[0,0] and commit['completion_word']==[0,0] and done['completion_word']==[1,0], 'word '+str(q))
 check(c[0:6]==[EXPECTED[q][0],0,7,7,0,10] and c[33:39]==b[33:39], 'finished '+str(q))
 check(all(a[11*i:11*i+11]==b[11*i:11*i+11]==c[11*i:11*i+11] for i in range(20) if i not in(0,3)), 'unrelated unit '+str(q))
 check(done['rng']==commit['rng'] and all(done['unit_bytes'][11*i:11*i+11]==a[11*i:11*i+11] for i in range(20) if i not in(0,3)), 'persist '+str(q))
 for label in ['00_ready',COMMIT[q],FINISH[q]]:
  check((root/(p+label+'.png')).is_file(), 'screenshot missing '+str(q)+' '+label)
 return {'qty':q,'source_before':40,'source_after':EXPECTED[q][0], 'split_after':surv,'dest':[8,7],'source_mobility_before':20,'source_mobility_after':10,'rng_initial':before['rng'],'rng_after':done['rng'],'completion_word_after':1,'commit_frame':commit['frame'],'finish_frame':done['frame'],'before_hash':hashlib.sha256((root/(p+'00_ready.json')).read_bytes()).hexdigest(),'commit_hash':hashlib.sha256((root/(p+COMMIT[q]+'.json')).read_bytes()).hexdigest()}

def audit_cancel(root):
 p='CANCEL_';before=load(root,p+'11_quantity_confirm');err=load(root,p+'12_cancel_before_target');ret=load(root,p+'13_cancel_again');
 check(before['unit_bytes']==err['unit_bytes']==ret['unit_bytes'], 'before-destination B unit fields changed')
 check(before['completion_word']==err['completion_word']==ret['completion_word']==[0,0], 'before-destination B completion charged')
 check(before['rng']==err['rng']==ret['rng']=='c7c3f28f2363', 'before-destination B RNG advanced')
 check((root/'CANCEL_12_cancel_before_target.png').is_file() and (root/'CANCEL_13_cancel_again.png').is_file(),'cancel screenshots')
 return {'B_first':'game showed Cant move there, no state debit','B_second':'returns to quantity prompt, no state debit'}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('root');ap.add_argument('--out');args=ap.parse_args()
 root=Path(args.root);check(hashlib.sha256((root/'checkpoint.mss').read_bytes()).hexdigest()==CHECKPOINT,'checkpoint identity')
 cases=[audit_case(root,q) for q in [1,6,7,8]];negative=audit_cancel(root)
 # Mutation control on copied decoded state, not original evidence or hashes.
 sample=load(root,'UP7_13_move_commit');sample['unit_bytes'][33]+=1
 check(sample['unit_bytes'][33]!=EXPECTED[7][1],'negative control failed to alter expected byte')
 try:
  assert sample['unit_bytes'][33]==EXPECTED[7][1]
 except AssertionError:pass
 else:raise AssertionError('tampered slot3 must be rejected')
 print('PASS',checks,'native capture assertions including negative control')
 receipt={'source_profile':'approved_combined_shared_bp_rest_modified_NES','rom_sha256':ROM,'mesen_sha256':EMUL,'core_sha256':CORE,'checkpoint_sha256':CHECKPOINT,'cases':cases,'before_destination_B':negative,'audit_assertions':checks,'classification':'OBSERVED_RUNTIME_MOD','port':'TESTED_LINUX_C11_ONLY'}
 if args.out:Path(args.out).write_text(json.dumps(receipt,indent=2)+'\n')
 return 0
if __name__=='__main__':sys.exit(main())
