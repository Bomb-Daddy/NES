# EXEC0126 IMPLEMENTER / HOSTILE QA HANDOFF — 2026-11-09

Authoritative inherited complete native game: EXEC0125 source ZIP, 343 current
files, source SHA256 08cd259fca2448695fcf3c453f4f95ffc523aed402c5c5d1583eefff149a89c8.
New EXEC0126 files: `gk126_io_barrier.c/h`, `test_gk126_io_barrier.c`, and
`README_EXEC0126.md`; edited same integrated `gk83_reset_trace.c/h`,
`CMakeLists.txt`, shell version and Linux/Win32 package names.

Correctness goal: original stock 2A03 source trace cannot pretend to have
completed a write with unsimulated OAMDMA stall, unmapped expansion hardware,
or PPUMASK rendering effect **when running with the PPU-timed source mode**.
The earlier deliberately synthetic NMI/controller research stays unchanged and
is NOT an actual PPU-timed claim. The source-visible first gate address, value,
reason and PC are recorded, no speculative CPU instruction/cycle counted.
Original stock ROM and original Mesen snapshots stay PRIVATE.

Optionally authenticate original ROM with the source verifier and run
`GK1_ORIGINAL_STOCK_ROM=/private/original.nes test_gk126_io_barrier`.
Expect conservative unknown `$00F5` after 70 and MesenCE allzeros exact
`$2002` after 142. Under *hypothetical* PPU origin10240/source mask path,
expect barrier `$C5E9 STA $2001`, value `$1E`, reason RENDER_UNMODELLED,
15,354 completed CPU instructions, repeatable. This is SOURCE_HYPOTHESIS,
not new Mesen observation, original first playable Spring or RNG proof.

NEXT: collect cycle-exact stock Mesen boot RAM and PPU events and implement
true classic setup/automatic abilities/season scheduler to unlock 14/27
player-ready Spring countries with three controller orders. Then real
merchant scheduling/Trade, AI, diplomacy, dynasty, battle victory/aftermath,
Windows NSIS/physical Xbox campaigns. Continue scheduled work until accepted
release/Director stop. Preserve genuine original captures distinct from
MOD ROM, source hypotheses, Linux port and untested Windows.
