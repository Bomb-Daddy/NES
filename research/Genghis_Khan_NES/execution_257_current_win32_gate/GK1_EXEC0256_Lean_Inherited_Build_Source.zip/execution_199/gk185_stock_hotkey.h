#ifndef GK185_STOCK_HOTKEY_H
#define GK185_STOCK_HOTKEY_H
#include "gk1_app_state.h"
/* Check the actual controller X/Y snapshot dispatch BEFORE opening any file.
 * Not a full campaign serializer: Enhanced stages must use their exclusive
 * stage-specific stores, NEVER the Classic-only GK80 fallthrough. */
typedef enum {
 GK185_NOT_STOCK_SCREEN=0,
 GK185_CLASSIC_PRIVATE=1,
 GK185_ENHANCED_STAGE=2,
 GK185_REFUSE=3
} Gk185HotkeyRoute;
Gk185HotkeyRoute gk185_stock_hotkey_route(const Gk1App *app);
#endif
