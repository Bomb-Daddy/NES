#ifndef GK164_MSS_ENTRY_H
#define GK164_MSS_ENTRY_H
#include "gk1_app_state.h"
#include "gk163_mesen_import.h"
/* In-memory, exact-source original archived Mesen .mss -> SAME native game.
 * No persistent intermediate raw 83-byte file; private licensed RAM is only
 * held in process memory. Only VIEW / PASS original commands are supported.
 * Fresh WorkRAM samples are NOT supported as archived SaveRAM Mesen .mss.
 */
typedef enum {GK164_OK=0,GK164_ARGUMENT=1,GK164_TEMPLATE=2,
              GK164_SOURCE=3,GK164_SOURCE_UNAVAILABLE=4} Gk164Result;
Gk164Result gk164_enter_original_mss(Gk1App *app,const char *canonical_csv,
 const char *private_mss,Gk77Profile profile,uint8_t player_index);
#endif
