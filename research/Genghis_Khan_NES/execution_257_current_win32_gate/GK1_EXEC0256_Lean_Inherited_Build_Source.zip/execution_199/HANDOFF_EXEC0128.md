# GK1 EXEC0128 — Actual C11 OAM register path and explicit-phase DMA, research gate

## Inheritance
Complete current EXEC0127 native Genghis C11 source from historical archive `GK1_EXEC0127_Complete_Historical_C11_Source_v1.00.zip`, exact SHA256 `487bef6419160a7ebe523d6e2946b76af8014a1967350cba1cd27e473fbd10df`. Retain complete game, 14/27 original PRE_SETUP countries, Classic/Enhanced, controller navigation, checkpoint pass/assign, saves, CPU source and all prior code. Never merge this with ROTK II.

## What actually changed
`gk128_oam.c/h` + `test_gk128_oam.c` are compiled and linked into the SAME native C11 `gk1_app_state`. The real `gk83_reset_trace.c` PPU-scheduled source-execution path now tracks `$2003` OAMADDR and `$2004` OAMDATA writes, including mirror decoding, unknown power-on address refusal, 256-byte OAM wrapping, and diagnostics. The independent DMA transaction function accepts complete *source-known* 256-byte CPU page, known OAMADDR and explicitly attested APU get/put alignment, else leaves OAM state and reported cycles unchanged. With this explicit context, 513 or 514 cycle stalls and 256 data bytes commit atomically. It does not assume CPU-cycle parity equals the APU get/put phase. NESdev documents random APU/CPU initial alignment. 

**Do not claim DMA is yet executed by the original source tracer:** its existing `$4014` hardware barrier remains because exact APU phase, DMC arbitration and read source have not been established for the stock boot. The graphics renderer and sprite evaluation are not implemented. This increment does not change unknown work RAM `$00F5` or establish original playable Spring.

## Reproduce
`cmake -S execution_128 -B build128 -DCMAKE_BUILD_TYPE=Release && cmake --build build128 -j8`
`GK1_ORIGINAL_STOCK_ROM=/private/exact_sha_ada7066d_original.nes ctest --test-dir build128 --output-on-failure -j8`
`(cd build128 && cpack -G DEB)`
`xvfb-run -a build128/gk1_native_shell --smoke-frames 120`
On Linux, Debug 86/86 and Release 86/86 PASS; separately built focused OAM ASan/UBSan 256 negative controls PASS. Full ASan suite was attempted but terminated during the build; NOT CERTIFIED. Installed-style extracted Debian executable graphical smoke 120 PASS. Both Linux `--version` and DEB identify 1.28.0-dev1. Stock optional verifier uses independently checked 262160-byte original ROM SHA256 `ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3`.

## Authenticity boundaries
VERIFIED_STATIC: 6502 research and PPU OAM register semantics, exact source hashes, DMA source/phase gate and rollback. OBSERVED_RUNTIME_STOCK: **only historical** fresh Mongol Spring1175 Gold430 Food208 Troops61 Rate121 orders3; archived Spring1175 Gold439 Food208 Troops61 Rate101 orders3; archived World1206 Gold193 Food332 Troops116 Rate114 orders3. These are different RNG/choice histories, never universal values. TESTED_PORT_LINUX: build, tests, 1280x720 graphics/Xvfb, Debian extracted executable. NOT RUN: new original Mesen replay, Win32/NSIS/physical Xbox. Original licensed ROM/private raw records stay ONLY in private Genghis folder; do not publish.

## Follow-up priority
Actual stock reset memory and PPU frame-phase capture (including CPU RAM `$00F5`, `$2002` and rendering write `$C5E9`), source-authentic player/difficulty/character RNG, original 14/27 country Spring with 3 real orders and controller, original merchant scheduler, all commands, AI, battle terminal/aftermath, dynasty ages6/7/8, save/quit/cold-load, 8-bit audio/video and Win32/Xbox campaigns. Do not use a presumed zero or screenshot number to unlock PRE_SETUP. Hourly task remains enabled until Director stop or accepted complete release.
