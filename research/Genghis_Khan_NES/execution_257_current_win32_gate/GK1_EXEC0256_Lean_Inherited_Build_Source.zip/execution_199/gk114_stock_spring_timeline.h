#ifndef GK114_STOCK_SPRING_TIMELINE_H
#define GK114_STOCK_SPRING_TIMELINE_H
#include "../execution_049/gk1_scenario_factory.h"
#include <stdint.h>
/* Source-bound single ORIGINAL, FRESH Mesen history. Public source contains
 * only its SHA-256; the private 96-byte derived proof is never distributed.
 * Results are comparisons, NEVER original game initialization or RNG rules. */
typedef enum {
 GK114_OK=0, GK114_ARGUMENT=1, GK114_SOURCE_REFUSED=2,
 GK114_TEMPLATE_DRIFT=3, GK114_PRIVATE_EVIDENCE_REFUSED=4,
 GK114_CHRONOLOGY_REFUSED=5, GK114_MODEL_REFUSED=6
} Gk114Status;
typedef struct {
 uint16_t first_year,playable_year;
 uint16_t initial_food,setup_food,post_feed_food;
 uint16_t draft_population,observed_food_consumed;
 uint8_t source_feed_food_matches;
 uint8_t observed_orders; /* original Mesen ONLY; NOT port order grants */
 int32_t modeled_vs_observed_gold;
 int32_t modeled_vs_observed_troops;
 uint8_t setup_resolved,first_spring_ready,port_orders_granted;
} Gk114Timeline;
/* Requires exact pristine canonical public CSV and all-country template,
 * plus exact private source-derived 6-stage receipt. On any failure *out is
 * untouched. No game state is changed on success or failure. */
Gk114Status gk114_verify_private_fresh_history(const char *source_csv,
 const Gk1LoadedScenario *pristine_mongol,const char *private_96bytes,
 Gk114Timeline *out);
#endif
