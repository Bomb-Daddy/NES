#ifndef GK178_SOURCE_RNG_H
#define GK178_SOURCE_RNG_H
#include <stddef.h>
#include <stdint.h>
/* Original stock fixed-bank $C289 subroutine: SOURCE-STATIC arithmetic,
 * NOT an independently observed original setup invocation or first Spring.
 * Six source coefficient bytes are supplied by a PRIVATE authenticated ROM,
 * never compiled into or published with the native port. */
typedef enum {
 GK178_OK=0, GK178_ARGUMENT=1, GK178_SOURCE=2, GK178_STAGE=3
} Gk178Status;
typedef struct {
 uint8_t before[6],after[6];
 uint8_t result_67,result_66;
 uint32_t conditional_adds;
} Gk178RngResult;
Gk178Status gk178_step(const uint8_t state[6],
 const uint8_t source_coefficients[6],Gk178RngResult *out);
Gk178Status gk178_step_from_authenticated_stock(const char *private_rom,
 const uint8_t state[6],Gk178RngResult *out);
#endif
