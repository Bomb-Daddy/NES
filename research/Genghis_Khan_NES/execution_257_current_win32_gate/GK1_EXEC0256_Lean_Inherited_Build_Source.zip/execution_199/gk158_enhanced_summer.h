#ifndef GK158_ENHANCED_SUMMER_H
#define GK158_ENHANCED_SUMMER_H
#include "gk116_enhanced_assign.h"
/* EXEC0158: approved ENHANCED research continuation only. This module DOES
 * NOT model original stock NES season effects (food, tax, wages, storms,
 * merchant RNG, AI, aging) or claim independent first-Spring setup. No
 * Classic mode enters this module; original stock evidence stays immutable. */
#define GK158_MAX_ACTIONS 3u
#define GK158_RECEIPT_BYTES 128u
typedef enum {
 GK158_OK=0,GK158_INPUT=1,GK158_SOURCE=2,GK158_NO_ORDERS=3,
 GK158_NO_WORKER=4,GK158_IO=5,GK158_EXISTS=6,GK158_CORRUPT=7
} Gk158Result;
typedef struct {
 Gk1LoadedScenario mutable_world;
 Gk71Budget budget;
 uint8_t active,action_count,pass_ended;
 Gk116LaborAction actions[GK158_MAX_ACTIONS];
} Gk158EnhancedSummer;
int gk158_attestation_intact(const Gk158EnhancedSummer *summer,
 const Gk116EnhancedAssign *spring,const Gk79Checkpoint *original);
Gk158Result gk158_open(const Gk116EnhancedAssign *spring,
 const Gk79Checkpoint *original,Gk158EnhancedSummer *out);
Gk158Result gk158_transfer(Gk158EnhancedSummer *summer,
 const Gk116EnhancedAssign *spring,const Gk79Checkpoint *original,
 uint8_t from,uint8_t to,uint16_t quantity);
Gk158Result gk158_pass(Gk158EnhancedSummer *summer,
 const Gk116EnhancedAssign *spring,const Gk79Checkpoint *original);
Gk158Result gk158_save_new(const char *path,const Gk79Checkpoint *original,
 const Gk116EnhancedAssign *spring,const Gk158EnhancedSummer *summer);
Gk158Result gk158_cold_load(const char *path,const Gk79Checkpoint *original,
 uint8_t enhanced,Gk116EnhancedAssign *spring_out,Gk158EnhancedSummer *summer_out);
#endif
