#ifndef GK202_IRQ_RNG_DISPATCH_H
#define GK202_IRQ_RNG_DISPATCH_H
#include <stddef.h>
#include <stdint.h>
/* Authenticated original NES PRG: IRQ/BRK vector dispatch into the fixed-bank
 * three-byte jump table. This is STATIC SOURCE EVIDENCE ONLY: it does not
 * establish that the game selected a particular slot during a live setup,
 * nor initialize the game's first Spring, character stats, or offers. */
#define GK202_STOCK_ROM_BYTES 262160u
#define GK202_TABLE_CAP 33u
typedef enum {
 GK202_OK=0, GK202_ARGUMENT=1, GK202_SOURCE_REFUSED=2,
 GK202_DISPATCH_MISMATCH=3
} Gk202Status;
typedef struct {
 uint16_t irq_brk_vector;
 uint16_t stack_status_read;
 uint8_t stack_brk_bit_mask;
 uint16_t command_selector_ram;
 uint16_t multiply_subroutine;
 uint16_t indirect_jmp_pointer;
 uint16_t table_first_pc;
 uint8_t table_entries;
 uint8_t rng_slot;
 uint16_t rng_entry_pc;
 uint16_t rng_target_pc;
 uint8_t direct_jsr_rng_raw_sequences;
 uint8_t direct_jmp_rng_raw_sequences;
 uint8_t verified_stock_sha;
 uint8_t source_only_not_runtime;
 uint16_t entry_targets[GK202_TABLE_CAP];
} Gk202Proof;
/* Both APIs leave *out byte-identical on any failure. For original-stock
 * evidence, caller must never include the private ROM in public receipts. */
Gk202Status gk202_analyze_authenticated_bytes(const uint8_t *rom,size_t bytes,
                                               Gk202Proof *out);
Gk202Status gk202_analyze_authenticated_file(const char *private_rom_path,
                                              Gk202Proof *out);
#endif
