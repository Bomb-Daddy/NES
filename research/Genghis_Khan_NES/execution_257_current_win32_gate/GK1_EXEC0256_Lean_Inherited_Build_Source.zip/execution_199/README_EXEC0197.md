# EXEC0197 — Native Classic Tax Rate Research Slice

Inherited complete EXEC0196 C11 executable and all previous mechanics. Manual rule GK1-MAN-033 records rate in 1..100, Leadership/Charm costs of five; this increment introduces controller-selectable rate adjustment only, with one Classic season order, source attestation, replay, rollback, and GC19 private cold-save/cold-load. The exact original NES Leadership/Charm deductions, morale, tax collections, startup RNG and initial first Spring remain unknown and are NOT emulated. It is labeled MANUAL_DERIVED, not an original stock NES behavioral match.

Controller sequence after loading private authenticated source: MENU, select TAX first command, A, UP/DOWN rate by 1 or LEFT/RIGHT by 10, A to commit one of three orders, B to exit. Original raw 83-byte source records never mutate. Three authenticated source profiles have explicit QA and a native Linux controller-injection 120-frame graphical smoke: `--smoke-classic-tax-original /private/path/source 120`. This test is NOT a physical Xbox or an original NES run. TESTED_PORT_LINUX only; Win32, NSIS, full campaigns NOT RUN.

Start from exact preserved full EXEC0196 archive; do not use EXEC0076 or reconstructed mini-project. No original copyrighted ROM, raw stock capture or licensed art/audio is distributed with this source. The source itself is copyright-clean.
