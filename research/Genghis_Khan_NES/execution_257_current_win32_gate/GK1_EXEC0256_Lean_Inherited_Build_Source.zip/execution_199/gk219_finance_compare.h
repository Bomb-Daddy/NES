#ifndef GK219_FINANCE_COMPARE_H
#define GK219_FINANCE_COMPARE_H
#include "gk217_finance_preview.h"
/* EXEC0219: Compare a source-loaded PRE_SETUP template against only the
 * controller's workforce-planning changes. This is NOT original NES Spring
 * setup, RNG, player orders, or a forecast of ruler-dependent events.
 * Neither world nor the output is modified on rejection. */
typedef enum { GK219_OK=0, GK219_INVALID=1, GK219_SOURCE_DRIFT=2,
 GK219_FINANCE_REFUSED=3 } Gk219Status;
typedef struct {
 Gk217Preview source;
 Gk217Preview drafted;
 int32_t projected_gold_delta;
 int32_t projected_food_delta;
 int32_t projected_troops_delta;
 int64_t all_countries_gold_delta;
 int64_t all_countries_food_delta;
 uint8_t workforce_changed;
 uint8_t original_spring_generated;
} Gk219Comparison;
Gk219Status gk219_compare_finance(const Gk1LoadedScenario *source,
 const Gk1LoadedScenario *drafted,unsigned country_index,Gk219Comparison *out);
#endif
