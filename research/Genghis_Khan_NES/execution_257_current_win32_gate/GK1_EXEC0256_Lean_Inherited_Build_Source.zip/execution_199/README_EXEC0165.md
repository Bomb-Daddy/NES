# EXEC0165 candidate — Original-stock fresh Mesen JSON source checkpoint (not independent setup)

Continues exact tested EXEC0163 integrated native C11 application. Separate
EXEC0164 archival-MSS direct-entry handoff was discovered but its source ZIP
was NOT available at the time this patch was compiled: this is a separately
reproducible **EXEC0163-based candidate**, not a verified successor to EXEC0164.

New source C11 `gk165_fresh_json.c/h` checks the 2026-11-07 owner-private
fresh original-stock Mesen `fresh_14_after_wait.json` sample: real nesWorkRam
bank (not SaveRAM), 14x83 country records, frame-stage identity and
observed-specific rate/year/gold/food/troops/3 orders, with canonical exact
original-stock SHA256 `04eb853683a3dada2a6a127baf61b6be2332114213cedc9e295c183647c6c73e`.
It rejects corruption without output mutation. These checks authorize ONLY
this specific archived first-Spring receipt, **not** universal startup values.

Linux native `gk1_native_shell --play-original-fresh-json <owner-private.json>`
opens the same source-authenticated Classic VIEW/PASS controller checkpoint via
existing `gk162_enter_original_checkpoint`, using a transient mode-0600 temp
source file that is unlinked after attachment. `--smoke-original-fresh-json
<owner-private.json> 120` runs actual compiled 1280x720 X11 frames. Portable
`--extract-original-fresh-json <owner-private.json> <new-private.raw83>`
exports the 1162 bytes with exclusive file creation; no overwrite. Direct
Win32 JSON-to-GUI entry is not yet implemented or tested; the extractor
is portable but not Win32-tested. The exact raw source is never bundled.

### Reproduction
`cmake -S execution_163 -B build -DCMAKE_BUILD_TYPE=Release`
`cmake --build build -j8`
`ctest --test-dir build -j8 --output-on-failure`
`build/test_gk165_fresh_json <OWNER_PRIVATE_fresh_14_after_wait.json>`
`xvfb-run -a build/gk1_native_shell --smoke-original-fresh-json <OWNER_PRIVATE_fresh_14_after_wait.json> 120`

This is source-attested *checkpoint continuation*, not independent first
Spring generator or original actions. Merchant RNG, autonomous AI, diplomacy,
dynasty, battle aftermath, full campaigns, Win32, physical Xbox NOT RUN.
All original stock and modified ROM/Mesen/screenshots/input raw bytes are private.
