# EXEC0115 implementer & hostile-QA handoff — 2026-11-08

Inherited entire currently complete, tested 1.14.0-dev1 native C11 game source, not an older isolated component. EXEC0113 code remained unpublished; the inherited archive is EXEC0114, which already documented that limitation. The original ROM and game data are never included in public artifacts.

## Source bug fixed

`gk1_app_trade` previously permitted `gk61_commit` to mutate the active 14/27-country game if caller code simply set `world.phase=2` and `market.playable=1`. The exact executable EXEC0062 test promoted such a synthetic phase for numerical adapter checking; that test is NOT original NES player initialization. This allowed a **fabricated merchant to charge Gold, Judgment and an order** inside the actual app. New `gk115_stock_market_gate.c/.h` requires the original scenario and phase, original-stock source integrity, country+season and Rate consistency, and refuses any original-merchant transaction while no SHA-authenticated original merchant presence/offer event is available. Even the authentic recovered country Spring record is not proof of merchant offers. No screenshot Gold/Rate is hardcoded. `gk61_commit` is unchanged and independently tested positively for source numeric rules. The game-level test is revised to demand rollback under fake phase and fake offers. A new dedicated test covers absent or forged original checkpoint and invalid country/region.

## Verification labels

- **VERIFIED_STATIC:** original `gk61_commit` source arithmetic preserved; strict missing-merchant-evidence gate linked to the actual `Gk1App` transaction API. Original stock 41-country CSV still exact source SHA checked by existing tests. No ROM copied.
- **OBSERVED_RUNTIME_STOCK:** original earlier Mesen fresh (Gold430 Rate121) and archived (Gold439 Rate101) Spring captures stand unchanged; **no new Mesen run** occurred here. No merchant event capture exists and the original 14/27-country spring generator remains unresolved.
- **TESTED_PORT_LINUX:** native GNU C11 Release/Debug 73/73, ASan+UBSan 73/73, actual native X11 1280x720 120 frames, and Debian extracted X11 120 frames and launcher with temporary override. The wrapper override is only used to simulate installation path; no system-wide package installation claimed.
- **NOT RUN:** native Win32 or NSIS installer, physical Xbox controller, full campaigns, authentic Mesen merchant-state recording, actual player Trade, authentic native first-Spring/three orders.

## Acceptance caveats

The new market gate is deliberately **fail-closed**. It is not new player Trade functionality, and it is not source-authentic Spring initialization. Those remain the highest implementation priorities. The 12 unimplemented strategic commands, AI, dynasty, diplomacy, battle aftermath and sound/art remain open. Continue from the exact full `execution_115` source and implement original stock merchant offer scheduler from future authentic source events, not fabricated flags. The complete historical ZIP contains all 9,849 previous archive entries byte-identically, plus a versioned 115 source directory. Preserve private owner ROM, SRAM, screenshots and checkpoint records in private research Drive only. Publication of this handoff alone is NOT executable agent acknowledgement.
