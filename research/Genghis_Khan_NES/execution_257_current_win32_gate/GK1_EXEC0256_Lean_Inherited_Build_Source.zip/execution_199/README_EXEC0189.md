# GK1 EXEC0189 — Original-source-attested Classic ASSIGN cold-resume (research build)

This is a **direct extension of the COMPLETE EXEC0188** C11 native 1280×720 game, not an emulator ROM or a separate prototype. All established Classic/Enhanced profiles and complete predecessor source remain intact.

## What works in this execution

* On a Classic state previously initialized from an authenticated, exact original-stock Mesen first-Spring checkpoint, the production controller X key saves the source snapshot plus up to three manual-derived ASSIGN operations and Pass into an **owner-private exclusive** `.gc19` file. No original licensed RAM is written to GitHub, this source tree, or the installer; the file is a private user save.
* Production controller Y at the TITLE loads that same snapshot, independent of any original ROM/Mesen file, and replays Classic actions into a freshly initialized native application after process restart. The original 83-byte country records are immutable. A pristine original-v1.07 CSV baseline must be present. Existing `.gc18` receipts and `.gk17` source saves remain on legacy paths when `.gc19` is absent.
* `.gc19` data is exactly source-pinned to the distinct authenticated original fresh Mongol Spring1175 WorkRAM, archived-restored Mongol Spring1175 SaveRAM, or archived-restored World Spring1206 SaveRAM observations. These three profiles have distinct RNG histories, and Gold/Rate examples must never become universal starting constants.
* Refuse unsafe destination, already-existing files, unreadable/symlink/hardlink/world-accessible files, incorrect file length/digest, invalid actions or source, or non-canonical CSV, without changing active game state. Linux writes exclusive mode 0600 and flushes/fsyncs. Win32 `_sopen_s`/`_commit` source branch is present but has **not** been compiled or tested.

## Reproduction

```sh
cmake -S execution_189 -B build189 -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build189 -j8
ctest --test-dir build189 --output-on-failure
xvfb-run -a ./build189/gk1_native_shell --smoke-frames 120
(cd build189 && cpack -G DEB)
```

Positive, original-stock private fixtures require three 83-byte-by-country RAM extracts from the protected EXEC0076 evidence archive and are **not** bundled or distributed in public source:

```sh
./build189/test_gk189_classic_cold_save ./build189/GK1_ALL_41_COUNTRY_ECONOMIC_DATA_v1.07.csv PRIVATE/fresh14.bin PRIVATE/archived_mongol14.bin PRIVATE/archived_world27.bin
# Two independent processes, with no fixture reattachment by RESUME:
./build189/test_gk189_process_restart CREATE ./build189/GK1_ALL_41_COUNTRY_ECONOMIC_DATA_v1.07.csv PRIVATE/fresh14.bin fresh PRIVATE/slot.gc19
./build189/test_gk189_process_restart RESUME ./build189/GK1_ALL_41_COUNTRY_ECONOMIC_DATA_v1.07.csv /no/ROM/re-attach fresh PRIVATE/slot.gc19
```

## Fidelity and release gates

**VERIFIED_STATIC**: exact source continuation, source SHA pinning, deterministic replay and preserved source history. **OBSERVED_RUNTIME_STOCK_INHERITED**: original fresh and distinct archived Mesen Spring records; no new NES emulation this run. **TESTED_PORT_LINUX**: Debug/Release CTest, focused source+sanitizer assertions, independent process restart, native and Debian-extracted X11 120-frame graphical boot. **NOT RUN**: native Win32, NSIS, physical Xbox controller, complete campaigns.

**NOT IMPLEMENTED**: independent stock 6502 reset/setup/ability/difficulty/RNG first Spring for all 14/27 countries; three authentically NES-matched Classic strategic actions, autonomous AI, merchant scheduling, diplomacy, dynasty, battle aftermath, complete graphical/audio parity, and whole-campaign save. A source-attested *checkpoint continuation* is not a self-generated first Spring and not a complete campaign. The original ROM and RAM snapshots remain PRIVATE and must not be published.
