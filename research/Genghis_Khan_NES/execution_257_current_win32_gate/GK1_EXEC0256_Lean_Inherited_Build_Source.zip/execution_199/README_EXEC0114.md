# EXEC0114 — ORIGINAL STOCK six-stage chronology

Preserves inherited complete EXEC0112 C11 game. Exact EXEC0113 original source archive was not remotely published/retrievable; its v2.92 handoff was read and the current code independently extends the verified EXEC0112 code without pretending to be byte-identical to an unrecovered EXEC0113.

New executable `gk114_stock_spring_timeline.c` authenticates a **PRIVATE 96-byte derived original Mesen six-checkpoint proof** using SHA256 09d7e00034b152d0cd49e6862e9364dda76dcc7a999922211b2c725c72d2553c. The private fixture and ROM are NEVER included in source, GitHub, Linux installer or QA ZIP. Stages 08,09,10,11,12,14 distinguish source observed food doubling, year/Rate update, actual feeding/Gold/troop change and later granting of three **NES-only** orders. Food 258 -> 208 numerically agrees with source-derived half template population 100; no intermediate actual living population measurement exists. The model does not explain original setup/ruler/difficulty/RNG. Strict all-country source identity and SHA match, no mutable port world changes, no game order grant, negative tamper controls.

This increment is NOT a new original Mesen run and not independent original playable Spring. Native Win32, NSIS, physical Xbox and real full campaigns NOT RUN.

`cmake -S execution_114 -B build114 -DCMAKE_BUILD_TYPE=Release && cmake --build build114 -j8 && ctest --test-dir build114 --output-on-failure`

Private-only positive: `build114/test_gk114_stock_spring_timeline build114/GK1_ALL_41_COUNTRY_ECONOMIC_DATA_v1.07.csv /PRIVATE/GK114_PRIVATE_AUTHENTIC_STOCK_FRESH_6STAGE_96B.bin`
