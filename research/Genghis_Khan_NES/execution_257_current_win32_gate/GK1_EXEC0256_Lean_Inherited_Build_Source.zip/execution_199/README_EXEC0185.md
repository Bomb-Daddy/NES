# EXEC0185 — Stock controller X/Y snapshot preflight (1.85.0-dev1)

Direct complete predecessor: EXEC0184. A source-verified original Spring is still **import-only**, not independently initialized; Classic remains VIEW/PASS.

A concrete native controller I/O defect existed: in a STOCK screen with Enhanced profile selected but no Enhanced stage active, the X/Y dispatch could fall through to the old GK80 **Classic-only** snapshot branch. A forged/unverified source could reach this fallback as well. The resulting file would not encode Enhanced status.

New `gk185_stock_hotkey_route` runs in the production `replay_key` function before any save/load path selection, requires original source attestation and intact 83-byte/projection identity, and routes only Classic to the private source-attested cold-save or live Enhanced to existing exclusive stage handlers. Ineligible stock X/Y commands do not open any file. The old GK80 controller fallback is explicitly disabled, though its historical source-only serialization implementation remains linked and independently testable. TITLE's explicit private cold-load is unchanged.

Reproduce: `cmake -S execution_185 -B build185 -G Ninja -DCMAKE_BUILD_TYPE=Release && cmake --build build185 -j8 && ctest --test-dir build185 --output-on-failure`. `test_gk185_stock_hotkey` is synthetic-negative only; it does not claim original NES runtime. Original 14/27-country first Spring RNG/setup, merchant schedule, 3 executable Classic commands, Win32/NSIS and physical Xbox remain OPEN.
