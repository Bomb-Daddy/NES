# Genghis Khan I native port — EXEC0192

## Executed change

This builds on the *complete* EXEC0191 C11 native game and its historical source. The inherited controller Y Classic ASSIGN undo feature refused the third unpassed action because `gk71_commit_completed` automatically sets `budget.ended=1` when the last of three orders is spent. `budget.ended` is not proof that the human selected PASS. As a result, the last worker allocation could be undone after actions one or two but not after action three, contradicting the feature's own "last unpassed assignment" contract.

`gk187_undo_last` now distinguishes **explicit PASS** (`passed=1`) from automatic budget exhaustion (`ended=1` with three actions). It reopens the exact source-authenticated checkpoint, transactionally replays actions one and two, verifies its replay invariant, restores one playable order, and leaves the original 83-byte stock records unchanged. A genuine PASS stays irreversible; forged source, changed world or poisoned provenance are still rejected before modification. No private owner ROM or RAM bytes are compiled, packaged or public.

`test_gk192_final_order_undo.c` is linked to the real `Gk1App` controller. Public CTest exercises no-source negatives; owner-private optional CLI validates fresh Mongol WorkRAM, archived Mongol SaveRAM, archived World SaveRAM, all with identical controller/rollback/cold-load assertions. Version 1.92.0-dev1 is shown in shell/installer.

## Scope and verification boundaries

VERIFIED_STATIC: original-stock source identity and action replay invariants, no assumptions about first Spring RNG values. OBSERVED_RUNTIME_STOCK: **inherited original fresh and archived observations**; no new Mesen run in EXEC0192. TESTED_PORT_LINUX: see independent release/debug/sanitizer and actual Xvfb logs. NOT RUN: native Win32/NSIS, physical Xbox, whole campaigns. This is a port-only usability correction, NOT proof that Koei's NES game supports Undo, and it does not solve the independent original first-Spring setup/character RNG/three authentic strategic commands.

## Next source-authentic implementation gate

Use the exact original stock reset provenance, 14/27 source country records and distinct RNG histories to reconstruct first Spring setup and all-country 6502-derived writes without loading one sample as universal constants. Preserve Classic versus Enhanced behavior and all historical source. Continue live original trade/AI/dynasty/diplomacy/war aftermath only with authenticated source or explicit manual-derived labels.
