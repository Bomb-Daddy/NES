# EXEC0161 — Enhanced year-2 Spring rollover (2026-11-10)

Inherited complete `execution_160/` C11 application is preserved. The new linked
`gk161_enhanced_year2.c/.h` advances the director-approved **Enhanced**
research-only labor loop from an authenticated original-stock Spring checkpoint
through four complete Enhanced seasons into a second Enhanced Spring. It
implements a real controller-navigable fifth season and three mutable workforce
labor orders, quantity selection 1/5/10/25/50/100, cancel and Pass confirmation.
It does NOT recreate the NES original Spring, calculate original food or Gold,
change age, population, merchants, dynasty, hazards, or automatically run AI.
The untouched original 14/27 stock-country evidence is never mutated.

The new `GY21` 192-byte exclusive-create save receipt stores five annual-season
labor action traces and binds them to the 32-byte authenticated stock source
SHA. Loading reconstructs all five seasons from the attached original evidence
and compares canonical bytes including SHA-256. Invalid, truncated, modified,
wrong-version, wrong-source, wrong-mode, or duplicate receipts fail closed and
cannot partially modify the caller state. Historic GA16/GS18/GF19/GW20 saves
remain separate and unmodified.

Native Linux command: `gk1_native_shell --smoke-enhanced-year2 120` with the
private `GK1_STOCK_SPRING_RECORDS` and `GK1_STOCK_SPRING_PROFILE=fresh` (or
`mongol` / `world`) correctly attached; NEVER distribute raw private input.
Standalone test `test_gk161_enhanced_year2 <original-csv> <fresh-raw83> <mongol-raw83> <world-raw83>` exercises all authenticated source profiles.
Without owner-private inputs, public CTest runs negative controls only.

VERIFIED_STATIC: source integrity and exact guarded input/transition logic.
OBSERVED_RUNTIME_STOCK: previous original fresh WorkRAM and archived restored
SaveRAM observations, not fresh emulator execution. TESTED_PORT_LINUX:
Release/Debug CTest, authenticated optional negative/positive, X11, Debian.
NOT RUN: new original Mesen, native Win32, NSIS, physical Xbox, campaigns.
PRIORITY STILL OPEN: source-authentic Classic first Spring, 14/27 native
fully initialized countries, true original 3 commands, RNG/character setup.
