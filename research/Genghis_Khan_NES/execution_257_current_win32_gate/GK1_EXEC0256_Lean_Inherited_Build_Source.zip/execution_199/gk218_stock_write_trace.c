#include "gk218_stock_write_trace.h"
#include "gk82_stock_cartridge.h"
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <inttypes.h>
#include <errno.h>
#include <stdlib.h>
#include <ctype.h>
/* Exact original SHA fingerprint is an identity guard, not a source-event
 * signature. Anyone can forge CSV; this is an input consistency validator. */
#define GK218_HEADER "GK1_TRACE_V1,ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3,FRESH_ORIGINAL_WORKRAM"
/* A strict bounded decimal parser: scanf overflow must not be relied upon
 * when ingesting untrusted owner-supplied emulator logs. */
static int parse_event(const char *line,char kind,uint64_t *value,unsigned count){
 if(!line||line[0]!=kind||line[1]!=','||!value||count>9u)return 0;
 const char *p=line+2;
 for(unsigned i=0;i<count;i++){
  if(!isdigit((unsigned char)*p))return 0;
  errno=0;
  char *end=NULL;
  unsigned long long number=strtoull(p,&end,10);
  if(errno==ERANGE||end==p)return 0;
  if(i+1u<count){if(*end!=',')return 0;p=end+1;}
  else {if(*end!='\n'||end[1]!='\0')return 0;}
  if(i+1u<count && (uint64_t)number>UINT32_MAX)return 0;
  value[i]=(uint64_t)number;
 }
 return 1;
}
Gk218Status gk218_parse_trace_untrusted(const char *filename,Gk218Report *out){
 if(!filename||!*filename||!out)return GK218_BAD_ARGS;
 FILE *fp=fopen(filename,"rb");
 if(!fp)return GK218_IO;
 char line[512];
 if(!fgets(line,sizeof line,fp)){
  fclose(fp);return GK218_BAD_TRACE;
 }
 size_t n=strlen(line);
 if(n && line[n-1]=='\n')line[--n]='\0';
 if(n && line[n-1]=='\r')line[--n]='\0';
 if(strcmp(line,GK218_HEADER)){
  fclose(fp);return GK218_BAD_TRACE;
 }
 Gk218Report result={0};
 uint32_t last_frame=0;
 uint32_t saw_stage=0;
 uint64_t last_cycle=0;
 int bad=0;
 while(fgets(line,sizeof line,fp)){
  size_t line_len=strlen(line);
  if(line_len==0u||line[line_len-1u]!='\n'){bad=1;break;}
  if(line[0]=='W'&&line[1]==','){
   uint64_t v[9];
   if(!parse_event(line,'W',v,9u)){bad=1;break;}
   const uint64_t pc=v[0],physical=v[1],addr=v[2],before=v[3],
                  intended=v[4],after=v[5],commit=v[6],frame=v[7],cycle=v[8];
   if(pc<0x8000u||pc>0xffffu||physical>=262144u||
      before>255u||intended>255u||after>255u||commit>1u||
      frame>UINT32_MAX||frame<last_frame||cycle<last_cycle||
      result.writes>=1000000u||
      !((addr>=0x84u&&addr<=0x89u)||(addr>=0x6000u&&addr<0x8000u))||
      (commit && intended!=after)){
    bad=1;break;
   }
   last_frame=(uint32_t)frame;last_cycle=cycle;
   ++result.writes;
   if(commit)++result.confirmed_writes;
   else ++result.unconfirmed_writes;
   if(addr>=0x84u&&addr<=0x89u&&commit){
    result.distinct_rng_mask|=1u<<(addr-0x84u);
    ++result.rng_writes;
   }
  }else if(line[0]=='S'&&line[1]==','){
   uint64_t v[7];
   if(!parse_event(line,'S',v,7u)){bad=1;break;}
   const uint64_t stage=v[0],frame=v[1],year=v[2],rate=v[3],
                  orders=v[4],countries=v[5],bank=v[6];
   if(stage!=saw_stage+1u||stage>14u||frame>UINT32_MAX||
      frame<last_frame||year>65535u||rate>65535u||orders>255u||
      countries>27u||bank>1u){bad=1;break;}
   last_frame=(uint32_t)frame;
   ++saw_stage;
   result.stages=saw_stage;
   result.final_year=(uint16_t)year;result.final_rate=(uint16_t)rate;
   result.final_orders=(uint8_t)orders;
   result.final_countries=(uint8_t)countries;
   result.bank_observed_workram=(uint8_t)bank;
   /* A still-uninitialized stage may be undefined, but initialized
    * fresh-source countries must come from the correct WorkRAM bank. */
   if(stage>=2u && (bank!=1u||countries!=14u)){bad=1;break;}
  }else {bad=1;break;}
 }
 if(ferror(fp)||fclose(fp))bad=1;
 if(bad)return GK218_BAD_TRACE;
 if(result.stages!=14u || result.final_year!=1175u ||
    result.final_orders!=3u||result.final_countries!=14u||
    !result.bank_observed_workram||result.writes==0u||
    result.distinct_rng_mask!=63u)return GK218_INCOMPLETE;
 result.last_cycle=last_cycle;
 *out=result;
 return GK218_OK;
}

Gk218Status gk218_audit_fresh_trace(const char *rom,const char *csv,
                                   Gk218Report *out){
 if(!rom||!*rom||!csv||!*csv||!out)return GK218_BAD_ARGS;
 Gk82RomBootstrap boot;
 if(gk82_probe_stock_rom(rom,&boot)!=GK82_ROM_OK)return GK218_BAD_ROM;
 return gk218_parse_trace_untrusted(csv,out);
}
