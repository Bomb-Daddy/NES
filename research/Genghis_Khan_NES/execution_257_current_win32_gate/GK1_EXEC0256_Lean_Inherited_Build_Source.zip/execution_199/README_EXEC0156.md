# GK1 EXEC0156 — Exhaustive original-source sign-exit matrix (C11)

This adds a tightly isolated **counterfactual** 128-way check of every possible PPUSTATUS lower-seven-bit value when the authenticated original ROM polling loop exits with VBlank=1. No individual candidate is accepted as original truth. Every candidate must agree on executed source state at the next stop for any state-independent conclusion.

The existing executable app, PRE_SETUP lock, controller, Enhanced mode, saves and all historical sources remain intact. The stage is still NOT playable first Spring, real Mesen execution, Windows, or physical Xbox validation.

Reproduce: `cmake -S execution_156 -B build156 -DCMAKE_BUILD_TYPE=Release && cmake --build build156 --target test_gk156_sign_exit_matrix gk1_native_shell -j4 && GK1_ORIGINAL_STOCK_ROM=/private/stock.nes ctest --test-dir build156 -R GK1_156 -V`. Original ROM and private stock sessions must never be published to public GitHub.

**Authenticated private original test result:** The existing bounded PPU model reaches the render-phase hardware gate *before* a sign=1 exit can safely be modeled. Across all 128 lower-7-bit values, zero sign=1 candidates were consumed. Therefore `all_identical=false`: an apparent 128/128 match is **vacuous** and cannot be promoted to a source equivalence proof. The next blocker is the modeled render/interrupt boundary, not a lack of arbitrary open-bus candidate selection.

Integrated CLI: `gk1_native_shell --source-sign-exit-matrix PRIVATE_STOCK_ROM 0 1`. The same `Gk1App` PRE_SETUP guard rejects non-authenticated sources and preserves every campaign byte.
