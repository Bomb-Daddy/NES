#include "gk172_rng_source_xref.h"
#include "gk1_source_identity.h"
#include "gk82_stock_cartridge.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* SHA-256 is an identity fingerprint, never proprietary ROM source bytes. */
static const uint8_t source_digest[32]={
 0xad,0xa7,0x06,0x6d,0x9e,0x71,0xa8,0x13,
 0x10,0xff,0xf7,0x8b,0xc7,0x03,0x71,0x26,
 0x79,0x80,0x18,0xa6,0x9d,0xc2,0xb9,0x23,
 0x82,0xc3,0xcb,0xdc,0xd9,0xb2,0x43,0xb3
};
static int header_ok(const uint8_t *p,size_t n){
 return n==GK172_ROM_BYTES && p[0]=='N' && p[1]=='E' &&
  p[2]=='S'&&p[3]==0x1a&&p[4]==16u&&p[5]==0u&&
  p[6]==0x12u&&p[7]==0u;
}
Gk172Status gk172_scan_image(const uint8_t *image,size_t n,Gk172RngXref *out){
 if(!image||!out)return GK172_ARGUMENT;
 if(!header_ok(image,n))return GK172_LAYOUT;
 Gk172RngXref next={0};
 for(unsigned bank=0;bank<GK172_BANKS;bank++){
  const uint8_t *p=image+16u+(size_t)bank*GK172_BANK_BYTES;
  for(size_t i=0;i+2u<GK172_BANK_BYTES;i++){
   if(p[i]==0x20u&&p[i+1u]==0x85u&&p[i+2u]==0xefu)
    next.ef85_jsr_candidates++;
   if(p[i+1u]!=0x89u||p[i+2u]!=0xc2u)continue;
   if(p[i]==0x20u){
    if(next.jsr_by_bank[bank]==UINT16_MAX||
       next.direct_jsr_candidates==UINT32_MAX)return GK172_OVERFLOW;
    next.jsr_by_bank[bank]++;next.direct_jsr_candidates++;
   }else if(p[i]==0x4cu){
    if(next.jmp_by_bank[bank]==UINT16_MAX||
       next.direct_jmp_candidates==UINT32_MAX)return GK172_OVERFLOW;
    next.jmp_by_bank[bank]++;next.direct_jmp_candidates++;
   }
  }
 }
 /* A known fixed-bank trampoline has a static 6502 JMP to the 48-bit
  * RNG entry. Byte matching proves the instruction EXISTS at its address,
  * not that a particular Spring reset executed that branch. */
 const size_t off=16u+15u*GK172_BANK_BYTES+ (GK172_RNG_TRAMPOLINE-0xc000u);
 next.fixed_trampoline_matches=(uint8_t)(image[off]==0x4cu&&
   image[off+1u]==(GK172_RNG_ENTRY&0xffu)&&
   image[off+2u]==(GK172_RNG_ENTRY>>8u));
 next.zero_direct_jsr=(uint8_t)(next.direct_jsr_candidates==0u);
 *out=next;return GK172_OK;
}
Gk172Status gk172_scan_authenticated(const char *path,Gk172RngXref *out){
 if(!path||!*path||!out)return GK172_ARGUMENT;
 Gk82RomBootstrap boot;
 if(gk82_probe_stock_rom(path,&boot)!=GK82_ROM_OK)return GK172_SOURCE;
 FILE *f=fopen(path,"rb");if(!f)return GK172_SOURCE;
 uint8_t *b=(uint8_t*)malloc(GK172_ROM_BYTES+1u);
 if(!b){fclose(f);return GK172_SOURCE;}
 size_t n=fread(b,1u,GK172_ROM_BYTES+1u,f);
 int bad=ferror(f),closed=fclose(f);
 Gk172Status result=GK172_SOURCE;
 if(!bad&&!closed&&n==GK172_ROM_BYTES){
  uint8_t actual[32];gk1_sha256_bytes(b,n,actual);
  if(memcmp(actual,source_digest,32u)==0){
   Gk172RngXref temp;
   result=gk172_scan_image(b,n,&temp);
   if(result==GK172_OK){temp.authenticated=1u;*out=temp;}
  }
 }
 memset(b,0,GK172_ROM_BYTES+1u);free(b);
 return result;
}
