#include "gk161_enhanced_year2.h"
#include "gk1_source_identity.h"
#include <string.h>
#include <stdio.h>
#include <errno.h>

static Gk161Result map_labor(Gk116Result r){
 if(r==GK116_OK)return GK161_OK;
 if(r==GK116_NO_WORKER)return GK161_NO_WORKER;
 if(r==GK116_NO_ORDERS)return GK161_NO_ORDERS;
 return GK161_INPUT;
}
Gk161Result gk161_open(const Gk116EnhancedAssign *sp,
 const Gk158EnhancedSummer *su,const Gk159EnhancedFall *fa,
 const Gk160EnhancedWinter *wi,const Gk79Checkpoint *original,
 Gk161EnhancedYear2 *out){
 if(!out)return GK161_INPUT;
 if(!sp||sp->year==UINT16_MAX||!wi||
    !gk160_attestation_intact(wi,sp,su,fa,original)||
    !wi->budget.ended||wi->budget.remaining)return GK161_SOURCE;
 Gk161EnhancedYear2 next={0};
 next.mutable_world=wi->mutable_world;
 next.budget=wi->budget;
 if(gk71_next_season(&next.mutable_world,&next.budget,GK71_SPRING)!=GK71_OK)
  return GK161_SOURCE;
 next.year=(uint16_t)(sp->year+1u);
 next.active=1u;
 *out=next;
 return GK161_OK;
}
int gk161_attestation_intact(const Gk161EnhancedYear2 *y,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk79Checkpoint *original){
 if(!y||!sp||y->active!=1u||sp->year==UINT16_MAX||
    y->year!=(uint16_t)(sp->year+1u)||
    !gk160_attestation_intact(wi,sp,su,fa,original)||
    !wi->budget.ended||wi->budget.remaining||
    y->action_count>GK161_MAX_ACTIONS||y->pass_ended>1u||
    y->budget.season!=GK71_SPRING||y->budget.governor!=GK71_BASE||
    y->budget.allowance!=3u||y->budget.playable!=1u||
    y->budget.completed!=y->action_count||
    (!y->pass_ended&&y->budget.remaining+y->action_count!=3u)||
    (y->pass_ended&&(y->budget.remaining!=0u||!y->budget.ended||
        y->action_count>=3u))||
    y->budget.ended!=(y->budget.remaining==0u))return 0;
 Gk161EnhancedYear2 replay={0};
 if(gk161_open(sp,su,fa,wi,original,&replay)!=GK161_OK)return 0;
 for(unsigned i=0;i<y->action_count;i++){
  const Gk116LaborAction *a=&y->actions[i];
  if(gk116_worker_math(&replay.mutable_world,&replay.budget,
       sp->player_index,a->from,a->to,a->quantity)!=GK116_OK)return 0;
  replay.actions[replay.action_count++]=*a;
 }
 if(y->pass_ended){
  if(gk71_pass(&replay.budget)!=GK71_OK)return 0;
  replay.pass_ended=1u;
 }
 return memcmp(&replay,y,sizeof replay)==0;
}
Gk161Result gk161_transfer(Gk161EnhancedYear2 *y,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk79Checkpoint *original,uint8_t from,uint8_t to,uint16_t quantity){
 if(!y||!sp||!su||!fa||!wi||!original)return GK161_INPUT;
 if(!gk161_attestation_intact(y,sp,su,fa,wi,original))return GK161_SOURCE;
 if(y->budget.ended||y->pass_ended||y->action_count>=GK161_MAX_ACTIONS)
  return GK161_NO_ORDERS;
 Gk161EnhancedYear2 next=*y;
 Gk161Result r=map_labor(gk116_worker_math(&next.mutable_world,&next.budget,
    sp->player_index,from,to,quantity));
 if(r!=GK161_OK)return r;
 next.actions[next.action_count++]=(Gk116LaborAction){from,to,quantity};
 if(!gk161_attestation_intact(&next,sp,su,fa,wi,original))return GK161_SOURCE;
 *y=next;return GK161_OK;
}
Gk161Result gk161_pass(Gk161EnhancedYear2 *y,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk79Checkpoint *original){
 if(!y||!sp||!su||!fa||!wi||!original)return GK161_INPUT;
 if(!gk161_attestation_intact(y,sp,su,fa,wi,original))return GK161_SOURCE;
 if(y->budget.ended||y->pass_ended)return GK161_NO_ORDERS;
 Gk161EnhancedYear2 next=*y;
 if(gk71_pass(&next.budget)!=GK71_OK)return GK161_INPUT;
 next.pass_ended=1u;
 if(!gk161_attestation_intact(&next,sp,su,fa,wi,original))return GK161_SOURCE;
 *y=next;return GK161_OK;
}
static void actions(uint8_t *dst,const Gk116LaborAction *a,unsigned n){
 for(unsigned i=0;i<n;i++){
  dst[4*i]=a[i].from;dst[4*i+1]=a[i].to;
  dst[4*i+2]=(uint8_t)a[i].quantity;
  dst[4*i+3]=(uint8_t)(a[i].quantity>>8);
 }
}
static uint16_t amount(const uint8_t *p){
 return (uint16_t)((unsigned)p[2]|((unsigned)p[3]<<8));
}
/* 192-byte GY21: 0..23 identity/counts, 24..55 original stock SHA,
 * 56..115 five ordered seasons of actions, 116..159 zero reserved,
 * 160..191 SHA256 hash of first 160 bytes. Always new exclusive path. */
static void encode(uint8_t raw[GK161_RECEIPT_BYTES],
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk161EnhancedYear2 *y){
 memset(raw,0,GK161_RECEIPT_BYTES);
 memcpy(raw,"GY21",4);raw[4]=1;raw[5]=sp->profile;
 raw[6]=(uint8_t)sp->mutable_world.scenario_id;raw[7]=sp->player_index;
 raw[8]=(uint8_t)sp->year;raw[9]=(uint8_t)(sp->year>>8);
 raw[10]=(uint8_t)sp->rate;raw[11]=(uint8_t)(sp->rate>>8);
 raw[12]=sp->action_count;raw[13]=sp->pass_ended;
 raw[14]=su->action_count;raw[15]=su->pass_ended;
 raw[16]=fa->action_count;raw[17]=fa->pass_ended;
 raw[18]=wi->action_count;raw[19]=wi->pass_ended;
 raw[20]=y->action_count;raw[21]=y->pass_ended;
 raw[22]=(uint8_t)y->year;raw[23]=(uint8_t)(y->year>>8);
 memcpy(raw+24,sp->source_sha,32);
 actions(raw+56,sp->actions,sp->action_count);
 actions(raw+68,su->actions,su->action_count);
 actions(raw+80,fa->actions,fa->action_count);
 actions(raw+92,wi->actions,wi->action_count);
 actions(raw+104,y->actions,y->action_count);
 gk1_sha256_bytes(raw,160u,raw+160u);
}
Gk161Result gk161_save_new(const char *path,const Gk79Checkpoint *original,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk161EnhancedYear2 *y){
 if(!path||!*path)return GK161_INPUT;
 if(!gk161_attestation_intact(y,sp,su,fa,wi,original))return GK161_SOURCE;
 uint8_t raw[GK161_RECEIPT_BYTES];encode(raw,sp,su,fa,wi,y);
 errno=0;FILE *fp=fopen(path,"wbx");
 if(!fp)return errno==EEXIST?GK161_EXISTS:GK161_IO;
 size_t n=fwrite(raw,1,sizeof raw,fp);int err=ferror(fp),ce=fclose(fp);
 if(n!=sizeof raw||err||ce){(void)remove(path);return GK161_IO;}
 return GK161_OK;
}
Gk161Result gk161_cold_load(const char *path,const Gk79Checkpoint *o,
 uint8_t enhanced,Gk116EnhancedAssign *spout,Gk158EnhancedSummer *suout,
 Gk159EnhancedFall *faout,Gk160EnhancedWinter *wiout,
 Gk161EnhancedYear2 *yout){
 if(!path||!*path||!o||!spout||!suout||!faout||!wiout||!yout)return GK161_INPUT;
 if(enhanced!=1u)return GK161_SOURCE;
 Gk116EnhancedAssign sp={0};Gk158EnhancedSummer su={0};
 Gk159EnhancedFall fa={0};Gk160EnhancedWinter wi={0};
 Gk161EnhancedYear2 y={0};
 if(gk116_open(o,1u,&sp)!=GK116_OK)return GK161_SOURCE;
 FILE *fp=fopen(path,"rb");if(!fp)return GK161_IO;
 uint8_t raw[GK161_RECEIPT_BYTES+1u];
 size_t n=fread(raw,1,sizeof raw,fp);int err=ferror(fp),ce=fclose(fp);
 if(err||ce)return GK161_IO;
 if(n!=GK161_RECEIPT_BYTES||memcmp(raw,"GY21",4u)||raw[4]!=1u||
    raw[12]>GK116_MAX_ACTIONS||raw[14]>GK158_MAX_ACTIONS||
    raw[16]>GK159_MAX_ACTIONS||raw[18]>GK160_MAX_ACTIONS||
    raw[20]>GK161_MAX_ACTIONS||raw[13]>1||raw[15]>1||raw[17]>1||
    raw[19]>1||raw[21]>1)return GK161_CORRUPT;
 for(unsigned i=0;i<raw[12];i++){
  const uint8_t *a=raw+56+4*i;
  if(gk116_transfer(&sp,o,a[0],a[1],amount(a))!=GK116_OK)return GK161_CORRUPT;
 }
 if(raw[13]&&gk116_pass_remaining(&sp,o)!=GK116_OK)return GK161_CORRUPT;
 if(gk158_open(&sp,o,&su)!=GK158_OK)return GK161_CORRUPT;
 for(unsigned i=0;i<raw[14];i++){
  const uint8_t *a=raw+68+4*i;
  if(gk158_transfer(&su,&sp,o,a[0],a[1],amount(a))!=GK158_OK)return GK161_CORRUPT;
 }
 if(raw[15]&&gk158_pass(&su,&sp,o)!=GK158_OK)return GK161_CORRUPT;
 if(gk159_open(&sp,&su,o,&fa)!=GK159_OK)return GK161_CORRUPT;
 for(unsigned i=0;i<raw[16];i++){
  const uint8_t *a=raw+80+4*i;
  if(gk159_transfer(&fa,&sp,&su,o,a[0],a[1],amount(a))!=GK159_OK)return GK161_CORRUPT;
 }
 if(raw[17]&&gk159_pass(&fa,&sp,&su,o)!=GK159_OK)return GK161_CORRUPT;
 if(gk160_open(&sp,&su,&fa,o,&wi)!=GK160_OK)return GK161_CORRUPT;
 for(unsigned i=0;i<raw[18];i++){
  const uint8_t *a=raw+92+4*i;
  if(gk160_transfer(&wi,&sp,&su,&fa,o,a[0],a[1],amount(a))!=GK160_OK)
   return GK161_CORRUPT;
 }
 if(raw[19]&&gk160_pass(&wi,&sp,&su,&fa,o)!=GK160_OK)return GK161_CORRUPT;
 if(gk161_open(&sp,&su,&fa,&wi,o,&y)!=GK161_OK)return GK161_CORRUPT;
 for(unsigned i=0;i<raw[20];i++){
  const uint8_t *a=raw+104+4*i;
  if(gk161_transfer(&y,&sp,&su,&fa,&wi,o,a[0],a[1],amount(a))!=GK161_OK)
   return GK161_CORRUPT;
 }
 if(raw[21]&&gk161_pass(&y,&sp,&su,&fa,&wi,o)!=GK161_OK)return GK161_CORRUPT;
 uint8_t exact[GK161_RECEIPT_BYTES];encode(exact,&sp,&su,&fa,&wi,&y);
 if(memcmp(raw,exact,sizeof exact))return GK161_CORRUPT;
 *spout=sp;*suout=su;*faout=fa;*wiout=wi;*yout=y;
 return GK161_OK;
}
