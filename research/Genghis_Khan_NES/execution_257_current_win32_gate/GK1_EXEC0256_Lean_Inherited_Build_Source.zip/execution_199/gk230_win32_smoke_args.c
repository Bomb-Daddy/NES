#include "gk230_win32_smoke_args.h"
#include <stddef.h>
#include <string.h>

int gk230_win32_smoke_frames(const char *command_line, unsigned *frames){
 static const char prefix[]="--smoke-frames=";
 const char *p=command_line;
 unsigned value=0u;
 unsigned digits=0u;
 if(!p||!frames)return -1;
 while(*p==' '||*p=='\t')p++;
 /* Preserve legacy non-smoke arguments; do not change normal game path. */
 if(strncmp(p,"--smoke-frames",14)!=0)return 0;
 if(strncmp(p,prefix,sizeof prefix-1u)!=0)return -1;
 p+=sizeof prefix-1u;
 if(*p=='0')return -1;
 while(*p>='0'&&*p<='9'){
   value=value*10u+(unsigned)(*p-'0');
   if(value>120u)return -1;
   p++;digits++;
 }
 if(!digits||value==0u)return -1;
 while(*p==' '||*p=='\t')p++;
 if(*p!='\0')return -1;
 *frames=value;
 return 1;
}
