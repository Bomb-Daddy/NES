# Genghis Khan I — EXEC0126 — 2026-11-09

**Source-integrated CPU/PPU hardware-boundary correction.** The prior native
C11 1280×720 game and both scenario templates, controller screens, save
formats, gameplay prototypes, and complete historical source remain intact.
This is not a standalone research-only replacement, a playable first Spring,
or an original NES remake release.

The PPU-clock-scheduled original NES 2A03 interpreter formerly silently
ignored CPU writes that trigger OAM DMA at `$4014` (513 or 514 stall cycles) and cartridge
expansion `$4020–$5FFF`, which invalidated the assumption that subsequent
CPU/PPU timing was source-executed. New linked `gk126_io_barrier.c/h` refuses
those unsupported writes in the PPU-timed mode, and PPU `$2001` rendering-enable writes, including
8-byte mirrors. `gk83_reset_trace.c` now refuses at the **actual instruction**
without counting a phantom completed CPU instruction. Source PC/address/value
and reason are reported in its independent trace, not inferred from screen
images or inserted into game statistics.

**VERIFIED_STATIC:** Independent classifier tests cover every CPU address,
all 256 PPU-mask values across all `$2000–$3FFF` mirrors, negative controls,
atomic rejection, and deterministic source replay. An optional test uses the
private exact original stock USA ROM, verified by existing SHA-256 gate.
With **explicit counterfactual** PPU origin 10,240 dots and sprite flags=0,
the source interpreter now stops *before completing* the original `$C5E9`
`STA $2001` with source value `$1E`, after 15,354 completed instructions.
This is NOT an OBSERVED_RUNTIME_STOCK result or an actual Mesen CPU trace; the
origin/flags are hypotheses. Historical synthetic NMI/hand-scripted controller traces remain separate and
unchanged; since they intentionally have no physical PPU clock, their cycle
counts are not an asserted stock emulator timeline. The no-assumption reset still stops after 70
instructions at unknown RAM `$00F5`. The MesenCE-specific all-zero RAM mode
stops at `$2002` after 142 instructions. Do not project either into original
ruler/abilities/first Spring RNG.

**NOT RUN:** Native Windows executable, NSIS, physical Xbox and real full
original Spring and campaigns. Original spring setup, merchants, AI, dynasty,
diplomacy, battle ending, controller-only release and graphic/audio fidelity
remain open. No original ROM, SRAM, Mesen images or licensed audio should be
committed publicly.

Build: `cmake -S execution_126 -B build126 -DCMAKE_BUILD_TYPE=Release &&
cmake --build build126 -j8 && ctest --test-dir build126 --output-on-failure -j8`.
Optional source test: set `GK1_ORIGINAL_STOCK_ROM` to the verified PRIVATE
ROM path and run `test_gk126_io_barrier`. Never ship that input.
