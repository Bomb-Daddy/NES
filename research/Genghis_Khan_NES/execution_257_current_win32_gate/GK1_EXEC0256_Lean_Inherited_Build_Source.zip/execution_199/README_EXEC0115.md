# EXEC0115 — source-authentic original merchant presence gate

This is the **same complete inherited native C11 Genghis Khan I app** as EXEC0114, version 1.15.0-dev1. It preserves Classic and Enhanced profiles, both 14/27-country templates, original stock checkpoint controller navigation/Pass, source-derived numerical Trade arithmetic, all prior research tests, and 1280x720 Linux/Win32 source and packaging. It DOES NOT invent a first playable Spring, market offers, or an NES RNG result.

## Implemented

An earlier game-level `gk1_app_trade()` allowed a synthetic fixture to set country `phase=2` and a caller-supplied `market.playable=1`, then actually deducted country Gold and lord Judgment and spent an order. That was an **inadequate production gate**: a future-phase integer and a boolean do not establish a source-authentic market. The source arithmetic remains in `gk61_commit()` and is tested separately.

New `gk115_market_gate.c/h` is invoked in the existing C11 `Gk1App` transaction function. It enforces game-world scenario/phase and original-stock capture proof integrity, binds scenario, season, ruler country and Rate, and **always refuses the final transaction** until a future original NES merchant event loader has recovered and authenticated merchant presence and offer masks. No original merchant event has been captured and no artificial one is accepted. This is an executable correctness/hardening change, not a playable Trade feature.

The regression suite changes `test_gk62_game_market_guard` to reject the previously-accepted fabricated future-phase transaction while positively checking `gk61_commit()` numeric arithmetic on an **isolated** data fixture. New `test_gk115_market_gate.c` exercises pre-setup, synthetic phase, fake original-stock flag, wrong country/region, full app and actor rollback. No original ROM or raw gameplay data is required for these tests. Existing original Mesen stock evidence remains historical, never rerun here.

## Reproducibility

```sh
cmake -S execution_115 -B build115 -DCMAKE_BUILD_TYPE=Release
cmake --build build115 -j8
ctest --test-dir build115 --output-on-failure -j8
# Linux Debian package
cpack --config build115/CPackConfig.cmake -G DEB
```

Both Classic stock and Enhanced original-with-Shared-BP profiles stay distinct. The game is still incomplete and intentionally does not unlock native first Spring, authenticated original merchant transactions, 12 locked commands, autonomous AI, diplomacy/dynasty, campaign completion, or Windows/physical Xbox testing. Never copy ROM/SRAM/original screenshots/audio to public GitHub/archives. Do not promote local code publication or QA into Mesen gameplay parity.
