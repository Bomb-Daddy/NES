#include "gk202_irq_rng_dispatch.h"
#include "gk1_source_identity.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PRG_START 16u
#define FIXED_BANK 15u
#define BANK_BYTES 16384u
#define FIXED_OFFSET (PRG_START+FIXED_BANK*BANK_BYTES)
static const uint8_t stock_sha[32]={
 0xad,0xa7,0x06,0x6d,0x9e,0x71,0xa8,0x13,
 0x10,0xff,0xf7,0x8b,0xc7,0x03,0x71,0x26,
 0x79,0x80,0x18,0xa6,0x9d,0xc2,0xb9,0x23,
 0x82,0xc3,0xcb,0xdc,0xd9,0xb2,0x43,0xb3
};
/* The supplied source is a 16-PRG MMC1 NES image with fixed last 16-KiB
 * bank at $C000-$FFFF. No mapper's live state is guessed here. */
static uint8_t at(const uint8_t *image,uint16_t addr){
 return image[FIXED_OFFSET+(size_t)(addr-0xc000u)];
}
/* Hash the private-stock source instruction windows instead of embedding
 * licensed source bytes in this copyright-clean implementation. */
static int window_sha_at(const uint8_t *image,uint16_t address,
                         size_t n,const uint8_t expected[32]){
 if(address<0xc000u||(unsigned)address+n>65536u)return 0;
 uint8_t got[32];
 gk1_sha256_bytes(image+FIXED_OFFSET+(size_t)(address-0xc000u),n,got);
 int match=memcmp(got,expected,32)==0;
 memset(got,0,sizeof got);
 return match;
}
Gk202Status gk202_analyze_authenticated_bytes(const uint8_t *image,size_t len,
                                               Gk202Proof *out){
 if(!image||!out)return GK202_ARGUMENT;
 if(len!=GK202_STOCK_ROM_BYTES||memcmp(image,"NES\032",4)!=0||
    image[4]!=16u||image[5]!=0u||image[6]!=0x12u||image[7]!=0u)
  return GK202_SOURCE_REFUSED;
 uint8_t digest[32];gk1_sha256_bytes(image,len,digest);
 int good=memcmp(digest,stock_sha,sizeof digest)==0;
 memset(digest,0,sizeof digest);
 if(!good)return GK202_SOURCE_REFUSED;
 /* IRQ/BRK vector $FFFE points to $C14B. The handler's PHP-stack
  * status check must see pushed B=1 to enter the dispatch path. */
 if(at(image,0xfffeu)!=0x4bu||at(image,0xffffu)!=0xc1u)
  return GK202_DISPATCH_MISMATCH;
 /* Source-code signature SHA-256; no original opcode material is
  * reproduced in the distributed source or unit-test fixtures. */
 static const uint8_t irq_hash[32]={
  0xb5,0x18,0xfa,0x2d,0xdb,0xf4,0xe9,0xf9,
  0x5f,0xe5,0xf1,0x76,0x0b,0x75,0xc5,0xfa,
  0xb3,0x76,0x5a,0x1a,0x69,0xdb,0x8f,0x41,
  0x0b,0x50,0x15,0x03,0xdc,0x70,0xf5,0xa5
 };
 static const uint8_t dispatch_hash[32]={
  0x47,0x56,0xc9,0x1a,0x1a,0x26,0x93,0x9d,
  0xf0,0x38,0x7c,0xf1,0x5d,0xb8,0x9d,0x06,
  0x78,0x7e,0x63,0xb8,0x71,0x98,0xe7,0xf7,
  0x39,0xc3,0x46,0x83,0x5f,0xc9,0xeb,0x05
 };
 static const uint8_t product_hash[32]={
  0xee,0x13,0x8c,0x34,0xc3,0x4c,0x27,0xc2,
  0x77,0xb6,0x8b,0x76,0xbb,0x6e,0x8b,0xba,
  0xe6,0xe3,0xce,0xd0,0x1e,0xfc,0x74,0xa8,
  0x8f,0xd0,0x49,0x34,0xf2,0x90,0x3a,0xdc
 };
 if(!window_sha_at(image,0xc14bu,13u,irq_hash)||
    !window_sha_at(image,0xc166u,24u,dispatch_hash)||
    !window_sha_at(image,0xc726u,17u,product_hash)||
    at(image,0xc183u)!=0x68u||at(image,0xc184u)!=0x40u)
  return GK202_DISPATCH_MISMATCH;
 Gk202Proof proof={0};
 proof.irq_brk_vector=0xc14bu;
 proof.stack_status_read=0x0104u;
 proof.stack_brk_bit_mask=0x10u;
 proof.command_selector_ram=0x0050u;
 proof.multiply_subroutine=0xc726u;
 proof.indirect_jmp_pointer=0x0068u;
 proof.table_first_pc=0xc185u;
 proof.table_entries=GK202_TABLE_CAP;
 proof.rng_slot=0xffu;
 for(unsigned slot=0;slot<GK202_TABLE_CAP;slot++){
  uint16_t entry=(uint16_t)(0xc185u+3u*slot);
  if(at(image,entry)!=0x4cu)return GK202_DISPATCH_MISMATCH;
  uint16_t target=(uint16_t)at(image,(uint16_t)(entry+1u))|
    (uint16_t)((uint16_t)at(image,(uint16_t)(entry+2u))<<8u);
  proof.entry_targets[slot]=target;
  if(target==0xc289u){
   if(proof.rng_slot!=0xffu)return GK202_DISPATCH_MISMATCH;
   proof.rng_slot=(uint8_t)slot;
   proof.rng_entry_pc=entry;
   proof.rng_target_pc=target;
  }
 }
 if(proof.rng_slot==0xffu)return GK202_DISPATCH_MISMATCH;
 /* An exhaustive raw 3-byte pattern count, not a disassembled executed
  * call count. This explains why earlier direct-JSR-only static scans saw
  * zero RNG calls while the dispatch-table path still exists in source. */
 for(size_t i=PRG_START;i+2u<len;i++){
  if(image[i+1u]==0x89u&&image[i+2u]==0xc2u){
   if(image[i]==0x20u){if(proof.direct_jsr_rng_raw_sequences<255u)
       proof.direct_jsr_rng_raw_sequences++;}
   if(image[i]==0x4cu){if(proof.direct_jmp_rng_raw_sequences<255u)
       proof.direct_jmp_rng_raw_sequences++;}
  }
 }
 proof.verified_stock_sha=1u;
 proof.source_only_not_runtime=1u;
 *out=proof;
 return GK202_OK;
}
Gk202Status gk202_analyze_authenticated_file(const char *filename,
                                              Gk202Proof *out){
 if(!filename||!*filename||!out)return GK202_ARGUMENT;
 FILE *f=fopen(filename,"rb");if(!f)return GK202_SOURCE_REFUSED;
 uint8_t *data=(uint8_t*)malloc(GK202_STOCK_ROM_BYTES+1u);
 if(!data){fclose(f);return GK202_SOURCE_REFUSED;}
 size_t n=fread(data,1,GK202_STOCK_ROM_BYTES+1u,f);
 int bad=ferror(f)||fclose(f)!=0;
 Gk202Status result=(!bad&&n==GK202_STOCK_ROM_BYTES)?
  gk202_analyze_authenticated_bytes(data,n,out):GK202_SOURCE_REFUSED;
 memset(data,0,GK202_STOCK_ROM_BYTES+1u);free(data);
 return result;
}
