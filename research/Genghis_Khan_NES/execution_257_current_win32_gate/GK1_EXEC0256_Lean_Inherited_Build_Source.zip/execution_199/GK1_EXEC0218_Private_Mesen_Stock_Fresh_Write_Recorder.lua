-- EXEC0218 ORIGINAL STOCK NES SOURCE-WRITE PROBE (NO LICENSED CONTENT).
-- Run only using the OWNER'S SHA256-verified stock ROM and matched MesenCE.
-- This is not a game initializer and no public ROM data is included.
-- Output is raw private source gameplay. Keep OUT of public artifacts.
-- Required: Mesen Lua IO/OS access enabled and GK218_TRACE_PRIVATE_PATH set.
-- WARNING: Mesen memory callback happens BEFORE the write. `confirmed=1`
-- only if a later EXEC callback sees the requested byte in nesDebug RAM.
-- Source PC returned inside a callback is a CANDIDATE; it must be independently
-- correlated with the original 6502 instruction and physical mapper bank.
local filename = os.getenv('GK218_TRACE_PRIVATE_PATH')
if not filename or filename == '' then
  error('GK218_TRACE_PRIVATE_PATH required (private output destination)')
end
local out, err = io.open(filename, 'wb')
if not out then error('GK218 private trace open refused: ' .. tostring(err)) end
out:write('GK1_TRACE_V1,ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3,FRESH_ORIGINAL_WORKRAM\n')
local frame = 0
local pending = {}
local count = 0
local MAX_EVENTS = 1000000
local function remember(address, value)
  if count >= MAX_EVENTS then error('EXEC0218 bounded capture overflow') end
  local cpu = emu.getCpuState()
  local pc = cpu.pc or -1
  local mapped = emu.convertAddress(pc, emu.memType.nesMemory)
  local offset = -1
  if mapped and mapped.memType == emu.memType.nesPrgRom then
    offset = mapped.address
  end
  pending[#pending + 1] = {
    pc = pc, physical = offset, address = address, value = value,
    before = emu.read(address, emu.memType.nesDebug),
    cycle = cpu.cycleCount or 0, frame = frame
  }
  count = count + 1
end
local function flush_writes()
  if #pending == 0 then return end
  for _, r in ipairs(pending) do
    local observed = emu.read(r.address, emu.memType.nesDebug)
    -- Multiple writes to the same address in a single instruction can
    -- overwrite an earlier request; earlier requests remain unconfirmed.
    local confirmed = observed == r.value and 1 or 0
    out:write(string.format('W,%d,%d,%d,%d,%d,%d,%d,%d,%d\n',
      r.pc, r.physical, r.address, r.before, r.value, observed, confirmed,
      r.frame, r.cycle))
  end
  pending = {}
  if count % 256 == 0 then out:flush() end
end
emu.addMemoryCallback(remember, emu.callbackType.write, 0x0084, 0x0089)
emu.addMemoryCallback(remember, emu.callbackType.write, 0x6000, 0x7fff)
-- This hook is deliberately costly; it exists only for bounded source
-- investigation, not for normal player gameplay or a shipped application.
emu.addMemoryCallback(function()
  if #pending > 0 then flush_writes() end
end, emu.callbackType.exec, 0x8000, 0xffff)
local function word(address)
  local low = emu.read(address, emu.memType.nesDebug)
  return low + 256 * emu.read(address + 1, emu.memType.nesDebug)
end
local steps = {
  'start','a','a','a','a','b','a','a','a',
  'wait','wait','wait','a','wait'
}
local starts = {}
local ends = {}
local at = 240
for i, action in ipairs(steps) do
  starts[i] = at
  at = at + (action == 'wait' and 300 or 125)
  ends[i] = at
end
local DONE_AT = at
local finished = false
local function source_stage(i)
  flush_writes()
  local mapped = emu.convertAddress(0x6dcd, emu.memType.nesMemory)
  local is_work = mapped and mapped.memType == emu.memType.nesWorkRam and 1 or 0
  out:write(string.format('S,%d,%d,%d,%d,%d,%d,%d\n',
    i, frame, word(0x65bb), word(0x7a8a), word(0x7b36),
    word(0x65b9), is_work))
  out:flush()
end
emu.addEventCallback(function()
  if finished then return end
  local start_on, a_on, b_on = false, false, false
  for i, action in ipairs(steps) do
    if frame >= starts[i] and frame < starts[i] + 5 then
      if action == 'start' then start_on = true end
      if action == 'a' then a_on = true end
      if action == 'b' then b_on = true end
      break
    end
  end
  emu.setInput({start=start_on, a=a_on, b=b_on}, 0)
end, emu.eventType.inputPolled)
emu.addEventCallback(function()
  if finished then return end
  frame = frame + 1
  for i=1,#steps do
    if frame == ends[i] then source_stage(i) end
  end
  if frame >= DONE_AT then
    finished = true
    flush_writes()
    out:flush()
    out:close()
    -- A test runner exit 0 means only that the bounded capture completed;
    -- independent ROM/trace/first-Spring gates still apply.
    emu.stop(0)
  end
end, emu.eventType.endFrame)
