# EXEC0129 — CPU-RAM-source OAM DMA, explicitly attested-phase research gate

Full inherited 1280x720 native C11 game with all pre-setup campaign templates,
Classic/Enhanced mechanics, controllers, and source-backed stores retained.

Source changes: `gk129_dma_source.c/h` and actual `gk83_reset_trace.c` original
ROM-source interpreter integration. The destination OAM address must have been
set by original source, each of 256 bytes must be independently known, and
source page must be 0x00-0x1F (NES 2KB RAM mirrors). Reject all unknown pages,
unknown bytes/phase/address without state mutation. On allowed source DMA only,
model exact 513/514 CPU stalls with explicit caller-supplied APU alignment hypothesis. Existing
original stock default trace NEVER guesses APU phase or RAM and still refuses
$4014; an explicit alternative trace is labeled HYPOTHESIS, not Mesen parity.

The native game is still an incomplete research build: original first playable
Spring, player RNG, authentic merchant presence and completed campaigns remain
OPEN. Windows native/NSIS/physical Xbox NOT RUN. No private ROM licensed bytes
or actual original source gameplay captures are in the public source tree.
