# Genghis Khan I research EXEC0123 — 2A03 Load/Store source-gated interpreter

**Development build, not a completed game.** Builds upon the complete local EXEC0121 historical native C11 application, with source-equivalent reconstruction of the GitHub-published EXEC0122 logic opcode handling. Source-equivalence is not a claim that the complete GitHub EXEC0122 tree was byte-identically recovered: no EXEC0122 complete archive was available in Collaboration Drive.

The new `gk123_cpu_loadstore.c/.h` implements all 31 official LDA/LDX/LDY/STA/STX/STY opcode/addressing combinations. The CPU interpreter `gk83_reset_trace.c` now routes all supported loads/stores through the same known/unknown RAM bus gate. It implements zero-page wrapping, indexed indirect and indirect indexed pointers, address and index overflow, page-cross read timing, store timing without read penalties, preserved status on stores, and N/Z only on loads. It also retains and tests the 24 official EXEC0122 ORA/AND/EOR cases.

**Reproducible Linux build**: `cmake -S execution_123 -B build123 -DCMAKE_BUILD_TYPE=Release && cmake --build build123 -j8 && ctest --test-dir build123 -j8 --output-on-failure`; then `cd build123 && cpack -G DEB`; real X11 test: `xvfb-run -a build123/gk1_native_shell --smoke-frames 120`.

**VERIFIED_STATIC:** reference-matched addressing, exact official opcode white list and negative exclusions, flag preservation and CPU cycle tables. **TESTED_PORT_LINUX:** see QA logs; a Linux frame smoke test does not certify actual gameplay or physical Xbox controller. **OBSERVED_RUNTIME_STOCK:** previously recorded original fresh Spring1175 and archived Spring1175/World1206 data only; no new Mesen run. **NOT RUN:** Win32 executable/NSIS installer/physical Xbox and full campaigns.

This development increment does NOT establish source-authentic character setup, difficulty/RNG, the actual first Spring and three playable orders, merchant presence, AI, diplomacy, dynasty, battle endings or complete campaigns. No stock ROM, patch, Mesen RAM or copyright-protected asset is in this source package.
