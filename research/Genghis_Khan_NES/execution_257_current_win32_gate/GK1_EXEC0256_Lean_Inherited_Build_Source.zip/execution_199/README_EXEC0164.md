# GK1 EXEC0164 — direct private original Mesen checkpoint controller entry

The new direct archive command-line launch is implemented and runtime-tested on Linux/X11 only; the shared in-memory bridge is portable C11 but native Windows/XInput and command-line integration remain NOT RUN.

This is the **same inherited native 1280×720 C11 game**, not a standalone remake. The owner may open an original, archived **stock USA** Mesen1 `.mss` directly into its gamepad-controlled original-stock checkpoint screen. No intermediate raw 14×83 or 27×83 file is created or saved. This **does not** run original NES startup, generate first Spring, or make unimplemented Classic commands functional: the source-bounded `VIEW` and `PASS` controls remain the only original actions.

```sh
./gk1_native_shell --play-original-mss /private/original_archived.mss mongol
./gk1_native_shell --play-original-mss /private/original_world.mss world
xvfb-run -a ./gk1_native_shell --smoke-original-mss /private/original_archived.mss mongol 120
```

`GK1_SCENARIO_CSV` may point to the original authenticated 41-country dataset; the compiled/deployed verified sibling CSV works by default. The source importer first checks the owner-private original archived `.mss` container, RAM bank, exact 14×83/27×83 SHA and the canonical pre-setup country dataset. On any mismatch, the existing game is not mutated and a clear refusal code is returned. The `fresh` WorkRAM profile is explicitly rejected for `.mss`, never mislabeled as archived SaveRAM. Original Mesen source bytes, ROM, original screenshots and licensed assets are never committed to GitHub or packaged.

**Proof labels:** VERIFIED_STATIC exact C11 source checks; TESTED_PORT_LINUX CLI/build/regression; OBSERVED_RUNTIME_STOCK archived/fresh from inherited original observations only, **no new Mesen**; NOT RUN Win32 native, NSIS installation, physical Xbox, independent original first Spring and whole campaigns. Priority remains **source-derived independent first Spring, 14/27 countries, three genuine original legal orders and setup/difficulty/character RNG**.
