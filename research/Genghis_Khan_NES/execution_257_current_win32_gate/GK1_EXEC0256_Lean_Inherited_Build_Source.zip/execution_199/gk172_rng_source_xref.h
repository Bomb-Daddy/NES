#ifndef GK172_RNG_SOURCE_XREF_H
#define GK172_RNG_SOURCE_XREF_H
#include <stddef.h>
#include <stdint.h>
/* An authenticated STATIC source cross-reference, NOT an original NES run.
 * A three-byte occurrence may be data, an operand, or unreachable code;
 * source-bank context and true control flow must be proven separately. */
#define GK172_ROM_BYTES 262160u
#define GK172_BANKS 16u
#define GK172_BANK_BYTES 16384u
#define GK172_RNG_ENTRY 0xc289u
#define GK172_RNG_TRAMPOLINE 0xc1b8u
typedef enum { GK172_OK=0, GK172_ARGUMENT=1, GK172_LAYOUT=2,
  GK172_SOURCE=3, GK172_OVERFLOW=4 } Gk172Status;
typedef struct {
 uint32_t direct_jsr_candidates;
 uint32_t direct_jmp_candidates;
 uint32_t ef85_jsr_candidates;
 uint16_t jsr_by_bank[GK172_BANKS];
 uint16_t jmp_by_bank[GK172_BANKS];
 uint8_t fixed_trampoline_matches;
 uint8_t authenticated;
 uint8_t zero_direct_jsr; /* This is NOT proof that no RNG calls execute. */
 uint8_t reserved;
} Gk172RngXref;
/* Image scan is a byte candidate inventory. No source-authentication claim. */
Gk172Status gk172_scan_image(const uint8_t *image,size_t bytes,Gk172RngXref *out);
/* Requires exact original USA ROM identity; read-only; never exposes bytes.
 * Returns with *out unchanged on every failure. */
Gk172Status gk172_scan_authenticated(const char *private_rom,Gk172RngXref *out);
#endif
