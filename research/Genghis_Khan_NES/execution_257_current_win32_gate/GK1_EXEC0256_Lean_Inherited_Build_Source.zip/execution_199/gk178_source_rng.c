#include "gk178_source_rng.h"
#include "gk82_stock_cartridge.h"
#include <stdio.h>
#include <string.h>
/* Source-traced ORIGINAL USA NES fixed bank instruction sequence
 * $C289-$C2EB (ROM identity checked separately). Model 6502 ROL/ASL,
 * ADC carry, 6-byte two's complement and the two result memory writes.
 * No stock seed, setup timing, merchant offers or Spring value inferred. */
Gk178Status gk178_step(const uint8_t state[6],
 const uint8_t coefficients[6],Gk178RngResult *out){
 if(!state||!coefficients||!out)return GK178_ARGUMENT;
 Gk178RngResult next={0};
 memcpy(next.before,state,6);
 uint8_t seed[6];memcpy(seed,state,6);
 seed[5]|=1u; /* $C289: ORA #$01; STA $0089 */
 uint8_t sums[6]={0}; /* $008B..$0090, initialized via Y=5..0 */
 for(int y=5;y>=0;y--){
  uint8_t polynomial=coefficients[y]; /* LDA $C2EC,Y */
  for(unsigned bit=0;bit<8;bit++){
   unsigned carry=0u; /* LDX #5; CLC */
   for(int x=5;x>=0;x--){
    unsigned next_carry=(unsigned)(sums[x]>>7);
    sums[x]=(uint8_t)((sums[x]<<1u)|carry);
    carry=next_carry;
   }
   unsigned add=(unsigned)(polynomial>>7);
   polynomial=(uint8_t)(polynomial<<1u);
   if(add){
    next.conditional_adds++;
    carry=0u;
    for(int x=5;x>=0;x--){
     unsigned sum=(unsigned)seed[x]+(unsigned)sums[x]+carry;
     sums[x]=(uint8_t)sum;
     carry=sum>>8;
    }
   }
  }
 }
 unsigned carry=1u; /* SEC; EOR #FF; ADC #0, X=5..0 */
 for(int x=5;x>=0;x--){
  unsigned negated=(unsigned)(uint8_t)~sums[x]+carry;
  next.after[x]=(uint8_t)negated;
  carry=negated>>8;
 }
 next.result_67=(uint8_t)(next.after[0]&0x7fu);
 next.result_66=next.after[1];
 *out=next;return GK178_OK;
}
Gk178Status gk178_step_from_authenticated_stock(const char *path,
 const uint8_t state[6],Gk178RngResult *out){
 if(!path||!*path||!state||!out)return GK178_ARGUMENT;
 Gk82RomBootstrap boot={0};
 if(gk82_probe_stock_rom(path,&boot)!=GK82_ROM_OK)return GK178_SOURCE;
 FILE *fp=fopen(path,"rb");if(!fp)return GK178_SOURCE;
 /* Original iNES 16x16 KiB PRG: CPU $C289 and constant table $C2EC
  * are in FIXED physical bank 15 (not switchable PRG bank 0..14). */
 const long off=16L+15L*16384L+0x2ecL;
 uint8_t coeff[6]={0};
 int ok=fseek(fp,off,SEEK_SET)==0&&fread(coeff,1,6,fp)==6;
 int bad=ferror(fp)||fclose(fp)!=0;
 if(!ok||bad){memset(coeff,0,sizeof coeff);return GK178_SOURCE;}
 Gk178Status status=gk178_step(state,coeff,out);
 memset(coeff,0,sizeof coeff);
 return status;
}
