#ifndef GK139_MESEN_STATE_H
#define GK139_MESEN_STATE_H
#include <stdint.h>
#include <stddef.h>
/* Only accepts the *DECOMPRESSED* named field block of a MesenCE state.
 * No ROM, RAM dump, palette or licensed asset is copied into the result.
 * This is an archived-state observation, NOT an NES startup seed oracle.
 * A clean original run is not inferred from an archived restored state. */
typedef enum { GK139_STATE_OK=0, GK139_STATE_MALFORMED=1, GK139_STATE_AMBIGUOUS=2 } Gk139Status;
typedef enum { GK139_BANK_UNKNOWN=0, GK139_BANK_WORK=1, GK139_BANK_SAVE=2 } Gk139CountryBank;
typedef struct {
 uint8_t nes_seed[6]; /* exact CPU *internal* RAM $84..$89 at saved instant */
 uint64_t seed48;
 uint64_t cpu_cycles;
 uint16_t program_counter;
 uint32_t field_count;
 Gk139CountryBank country_bank; /* determined by record presence at physical 0x0DCD */
} Gk139MesenProof;
/* Independent archive authentication, ROM SHA and timing still required.
 * Rejects ambiguous duplicate fields, malformed lengths, missing 2KB CPU
 * internal RAM, absent/dual country banks. Every refusal leaves out unchanged.
 */
Gk139Status gk139_parse_uncompressed_state(const uint8_t *bytes,size_t size,
                                            Gk139MesenProof *out);
#endif
