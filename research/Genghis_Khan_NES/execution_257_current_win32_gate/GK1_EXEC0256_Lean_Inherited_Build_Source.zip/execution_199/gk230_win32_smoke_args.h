#ifndef GK230_WIN32_SMOKE_ARGS_H
#define GK230_WIN32_SMOKE_ARGS_H
/* Exact bounded WinMain GUI smoke mode. Only positive 1..120 frame counts.
 *  1 = run finite GUI loop; 0 = unmodified normal launch; -1 = reject.
 * WinMain supplies the command tail without executable path.
 */
int gk230_win32_smoke_frames(const char *command_line, unsigned *frames);
#endif
