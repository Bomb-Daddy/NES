#include "gk219_finance_compare.h"
#include <string.h>
#include <limits.h>
/* A labor transfer conserves the sum of the five drafted pools in its own
 * country. Allow no alternative mutation to pass as a valid source baseline. */
static uint32_t pool_total(const Gk1CountryTemplate *c){
 return (uint32_t)c->troops+c->town+c->masons+c->artisans+c->food_workers;
}
static int only_labor_changed(const Gk1LoadedScenario *source,
 const Gk1LoadedScenario *drafted){
 if(source->scenario_id!=drafted->scenario_id ||
    source->country_count!=drafted->country_count ||
    source->phase!=GK1_PRE_SETUP_TEMPLATE ||
    drafted->phase!=GK1_PRE_SETUP_TEMPLATE)return 0;
 Gk1LoadedScenario normalized=*drafted;
 for(unsigned i=0;i<source->country_count;i++){
  const Gk1CountryTemplate *a=&source->countries[i];
  Gk1CountryTemplate *b=&normalized.countries[i];
  if(pool_total(a)!=pool_total(b))return 0;
  b->troops=a->troops;b->town=a->town;
  b->masons=a->masons;b->artisans=a->artisans;
  b->food_workers=a->food_workers;
 }
 return memcmp(&normalized,source,sizeof normalized)==0;
}
Gk219Status gk219_compare_finance(const Gk1LoadedScenario *source,
 const Gk1LoadedScenario *drafted,unsigned country_index,Gk219Comparison *out){
 if(!source||!drafted||!out || source->country_count==0 ||
    country_index>=source->country_count ||
    (source->scenario_id!=GK1_MONGOL_CONQUEST &&
     source->scenario_id!=GK1_WORLD_CONQUEST) ||
    source->country_count!=(source->scenario_id==GK1_MONGOL_CONQUEST?
      GK1_COUNTRIES_MONGOL:GK1_COUNTRIES_WORLD))return GK219_INVALID;
 if(!only_labor_changed(source,drafted))return GK219_SOURCE_DRIFT;
 Gk214Batch baseline={0},candidate={0};
 if(gk214_project_spring_batch(source,&baseline)!=GK214_OK||
    gk214_project_spring_batch(drafted,&candidate)!=GK214_OK||
    baseline.generated_setup || candidate.generated_setup ||
    baseline.generated_rng || candidate.generated_rng ||
    baseline.orders_granted || candidate.orders_granted ||
    baseline.after.phase!=GK1_PRE_SETUP_TEMPLATE ||
    candidate.after.phase!=GK1_PRE_SETUP_TEMPLATE)return GK219_FINANCE_REFUSED;
 Gk219Comparison next={0};
 if(gk217_preview_country(source,country_index,&next.source)!=GK217_OK||
    gk217_preview_country(drafted,country_index,&next.drafted)!=GK217_OK)
   return GK219_FINANCE_REFUSED;
 next.projected_gold_delta=(int32_t)next.drafted.after_gold-(int32_t)next.source.after_gold;
 next.projected_food_delta=(int32_t)next.drafted.after_food-(int32_t)next.source.after_food;
 next.projected_troops_delta=(int32_t)next.drafted.after_troops-(int32_t)next.source.after_troops;
 for(unsigned i=0;i<source->country_count;i++){
  next.all_countries_gold_delta+=(int64_t)candidate.after.countries[i].gold-
                                    (int64_t)baseline.after.countries[i].gold;
  next.all_countries_food_delta+=(int64_t)candidate.after.countries[i].goods[10]-
                                    (int64_t)baseline.after.countries[i].goods[10];
  const Gk1CountryTemplate *a=&source->countries[i],*b=&drafted->countries[i];
  if(a->troops!=b->troops||a->town!=b->town||a->masons!=b->masons||
     a->artisans!=b->artisans||a->food_workers!=b->food_workers)next.workforce_changed=1u;
 }
 next.original_spring_generated=0u;
 *out=next;
 return GK219_OK;
}
