# GK1 EXEC0129 — Source-authenticated CPU-RAM OAM DMA path — 2026-11-09

## Authority and inheritance

Based on the complete EXEC0128 C11 native game, not a standalone emulator prototype. Same original 14/27-country pre-setup templates, 1280x720 controller shell, Classic/Enhanced separation, research checkpoints and saved-state components retained. The source archive carries all previous EXEC0128 historical entries unchanged at the file-content level. Private original US ROM identity: SHA-256 ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3; licensed bytes excluded from publication.

## Executable source change

Integrated gk129_dma_source.c/h in the existing gk1_app_state CMake target and actual gk83_reset_trace.c source-execution write path. A CPU $4014 write may generate an atomic OAM transfer only when (a) the CPU source page is $00-$1F, mapped correctly via 2KB physical CPU RAM mirrors; (b) all 256 CPU RAM source bytes are known; (c) OAMADDR was established; and (d) an *explicit user-supplied hypothetical* APU get/put phase is specified. The helper refuses unknown register, phase, page, or any byte without changing OAM or cycle count. Accepted transfer adds 513 or 514 CPU stall cycles and updates the same original-source trace diagnostics. Source reads from $20-$FF are unmodeled and refused. The normal authentic stock-ROM entry point still refuses $4014 absent a verified phase and still halts on $00F5 at PC $8060.

The new research-only `gk129_trace_original_ppu_with_dma_alignment` is deliberately marked HYPOTHESIS. It is **not** Mesen parity and cannot certify real first Spring, renderer, APU DMC or mapper IO. No manual contradiction or observed rate is hardcoded.

## QA classifications

VERIFIED_STATIC: executable C11 source, source-based phase refusal, tests and ZIP source hashes. TESTED_PORT_LINUX: Release/Debug/ASan + UBSan CTest 87/87, compiled and Debian-extracted native 1280x720 120-frame graphical test, independently built extracted full historical source. OBSERVED_RUNTIME_STOCK: earlier fresh Mongol Spring1175 Gold430 Food208 Troops61 Rate121 orders3, archived Mongol1175 Gold439 Food208 Troops61 Rate101 orders3, archived World1206 Gold193 Food332 Troops116 Rate114 orders3. These remain separate observations and were not newly replayed. NOT RUN: new Mesen gameplay, original daughter marriage ages6/7/8, native Win32, NSIS installer, physical Xbox controller, complete campaigns.

## Reproduce

`cmake -S execution_129 -B build129 -DCMAKE_BUILD_TYPE=Release`

`cmake --build build129 -j8`

`GK1_ORIGINAL_STOCK_ROM=/private/verified_original_stock_rom.nes ctest --test-dir build129 --output-on-failure -j8`

`(cd build129 && cpack -G DEB)`

`xvfb-run -a build129/gk1_native_shell --smoke-frames 120`

For sanitizer: build with `-fsanitize=address,undefined -fno-omit-frame-pointer -O1` and test with `ASAN_OPTIONS=detect_leaks=0`. Privately verify original ROM 262160B SHA first; do NOT publish licensed ROM or captures.

## Still open

Original setup/ability/difficulty RNG, independently playable first Spring (both campaigns) with actual three orders, original merchant presence RNG/Trade, remaining strategic commands, autonomous AI, diplomacy, dynasty, battle terminal and aftermath, audiovisual fidelity, real Win32/NSIS/Xbox QA. Do not mark authentic game playable. Keep inherited hourly development task running until explicit stop or completed accepted release. Publication is not implementer read acknowledgment.
