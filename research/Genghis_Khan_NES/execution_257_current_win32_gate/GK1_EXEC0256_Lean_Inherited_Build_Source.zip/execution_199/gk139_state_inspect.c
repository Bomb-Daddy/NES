/* Research-only executable: accepts a privately extracted/decompressed
 * MesenCE named-state buffer. It never dumps RAM or assumes original Spring.
 * ROM SHA and saved-state chain authentication must occur separately. */
#include "gk139_mesen_state.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int main(int argc,char **argv){
 if(argc!=2){fprintf(stderr,"Usage: gk139_state_inspect PRIVATE_UNCOMPRESSED_MESEN_STATE\n");return 2;}
 FILE *f=fopen(argv[1],"rb");if(!f){perror("read private state");return 2;}
 if(fseek(f,0,SEEK_END)!=0){fclose(f);return 2;}
 long n=ftell(f);
 if(n<32||n>16*1024*1024||fseek(f,0,SEEK_SET)!=0){fclose(f);return 2;}
 uint8_t *bytes=(uint8_t*)malloc((size_t)n);if(!bytes){fclose(f);return 2;}
 size_t got=fread(bytes,1,(size_t)n,f);fclose(f);
 if(got!=(size_t)n){free(bytes);return 2;}
 Gk139MesenProof p={0};Gk139Status code=gk139_parse_uncompressed_state(bytes,(size_t)n,&p);
 free(bytes);
 if(code!=GK139_STATE_OK){fprintf(stderr,"REFUSED malformed or ambiguous Mesen named-state block (%d)\n",code);return 3;}
 printf("OBSERVED_RUNTIME_STOCK_ARCHIVED_RESTORED private-state seed="
   "%02x%02x%02x%02x%02x%02x cpu_pc=$%04X cpu_cycles=%llu"
   " record_bank=%s fields=%u; NOT original first-Spring RNG chronology\n",
   p.nes_seed[0],p.nes_seed[1],p.nes_seed[2],p.nes_seed[3],p.nes_seed[4],p.nes_seed[5],
   (unsigned)p.program_counter,(unsigned long long)p.cpu_cycles,
   p.country_bank==GK139_BANK_SAVE?"nesSaveRam":"nesWorkRam",p.field_count);
 return 0;
}
