#include "gk152_spring_writer_map.h"
#include "gk82_stock_cartridge.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int absolute_write(uint8_t op){
 switch(op){
 case 0x8c: case 0x8d: case 0x8e: /* STY/STA/STX abs */
 case 0x99: case 0x9d: /* STA abs,Y / abs,X */
 case 0x0e: case 0x1e: case 0x2e: case 0x3e:
 case 0x4e: case 0x5e: case 0x6e: case 0x7e:
 case 0xce: case 0xde: case 0xee: case 0xfe: /* RMW abs/indexed */
  return 1;
 default: return 0;
 }
}
static int sane_header(const uint8_t *s,size_t n){
 if(n!=16u+GK152_BANKS*GK152_PRG_SIZE||
    s[0]!='N'||s[1]!='E'||s[2]!='S'||s[3]!=0x1a||
    s[4]!=16u||s[5]!=0u||
    (s[6]&0x04u)||((s[6]>>4)|(s[7]&0xf0u))!=1u) return 0;
 return 1;
}
Gk152Status gk152_inventory_candidate_bytes(const uint8_t *ines,
 size_t bytes,Gk152WriterMap *out){
 if(!ines||!out)return GK152_BAD_ARG;
 if(!sane_header(ines,bytes))return GK152_BAD_LAYOUT;
 Gk152WriterMap result={0};
 for(unsigned bank=0;bank<GK152_BANKS;bank++){
  const uint8_t *p=ines+16u+(size_t)bank*GK152_PRG_SIZE;
  for(size_t i=0;i<GK152_PRG_SIZE;i++){
   /* Single-byte patterns are NOT proof that the byte is executable. */
   if(p[i]==0x81u||p[i]==0x91u){
    result.raw_indirect_store_byte_candidates++;
    result.raw_indirect_store_by_bank[bank]++;
   }
   if(i+2u>=GK152_PRG_SIZE)continue;
   /* Raw low/high pointer word $6DCD is only a clue to possible table refs. */
   if(p[i]==(GK152_COUNTRY_BASE&255u)&&
      p[i+1u]==(GK152_COUNTRY_BASE>>8u))result.raw_pointer_base_candidates++;
   if(!absolute_write(p[i]))continue;
   unsigned operand=(unsigned)p[i+1u]|((unsigned)p[i+2u]<<8);
   if(operand<0x6000u||operand>0x7fffu)continue;
   result.raw_absolute_write_candidates++;
   result.raw_absolute_write_by_bank[bank]++;
   if(operand>=GK152_COUNTRY_BASE&&
      operand<GK152_COUNTRY_BASE+GK152_COUNTRY_STRIDE*GK152_COUNTRY_WORLD){
    result.raw_country_world_candidates++;
    result.raw_country_world_by_bank[bank]++;
    if(result.raw_country_world_candidates==1u){
     result.first_world_bank=(uint8_t)bank;
     result.first_world_cpu_address=(uint16_t)(bank==15u?0xc000u+i:0x8000u+i);
    }
    if(operand<GK152_COUNTRY_BASE+GK152_COUNTRY_STRIDE*GK152_COUNTRY_MONGOL)
     result.raw_country_mongol_candidates++;
   }
  }
 }
 /* A static byte inventory has NO authorization to enter player gameplay. */
 result.produced_playable_spring=0u;
 *out=result;
 return GK152_OK;
}
Gk152Status gk152_inventory_original_rom(const char *path,Gk152WriterMap *out){
 if(!path||!*path||!out)return GK152_BAD_ARG;
 Gk82RomBootstrap boot;
 if(gk82_probe_stock_rom(path,&boot)!=GK82_ROM_OK)return GK152_NOT_AUTHENTIC;
 uint8_t *s=(uint8_t*)malloc(16u+GK152_BANKS*GK152_PRG_SIZE);
 if(!s)return GK152_NOT_AUTHENTIC;
 FILE *f=fopen(path,"rb");
 if(!f){free(s);return GK152_NOT_AUTHENTIC;}
 size_t n=fread(s,1u,16u+GK152_BANKS*GK152_PRG_SIZE,f);
 int eof=(fgetc(f)==EOF);
 int failed=ferror(f);
 fclose(f);
 if(n!=16u+GK152_BANKS*GK152_PRG_SIZE||!eof||failed){
  free(s);return GK152_NOT_AUTHENTIC;
 }
 Gk152WriterMap candidate={0};
 Gk152Status status=gk152_inventory_candidate_bytes(s,n,&candidate);
 memset(s,0,n);
 free(s);
 if(status!=GK152_OK)return status;
 candidate.authenticated=1u;
 *out=candidate;
 return GK152_OK;
}
