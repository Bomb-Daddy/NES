#ifndef GK167_PRIVATE_COLD_SAVE_H
#define GK167_PRIVATE_COLD_SAVE_H
#include "gk1_app_state.h"
/* GK167: owner-private, source-attested original-stock 14/27 country checkpoint
 * save, self-contained for subsequent application cold-starts. The saved
 * bytes INCLUDE copyright-licensed original NES RAM supplied by the owner:
 * NEVER publish .gk17 saves, attach them to public QA, or bundle them into
 * installers. This is a checkpoint continuation, not a full campaign save.
 * No independent first-Spring setup, Trade, AI or next season is generated.
 */
typedef enum {
 GK167_OK=0, GK167_INVALID=1, GK167_EXISTS=2,
 GK167_IO=3, GK167_CORRUPT=4, GK167_SOURCE=5
} Gk167Result;
Gk167Result gk167_save_private_new(const char *path,const Gk1App *app);
/* This is atomic: on EVERY failure, *app remains byte-for-byte unchanged.
 * Canonical original v1.07 CSV must have been installed in app beforehand.
 * The exact 14/27x83 evidence digest is pinned in compiled research source.
 */
Gk167Result gk167_cold_load_private(const char *path,const char *csv,Gk1App *app);
#endif
