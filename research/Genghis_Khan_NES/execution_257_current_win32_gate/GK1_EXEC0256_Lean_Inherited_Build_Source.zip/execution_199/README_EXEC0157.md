# EXEC0157 — additive symbolic PPUSTATUS-low7 trace (research-only)

Authority: exact complete EXEC0156 C11 source (including its separate exhaustive
128-candidate status matrix). Preserves every original Classic and approved
Enhanced mechanic and every original fail-closed source guard.

When the authenticated fixed-bank $C5BE/BPL polling loop safely reaches a
bit7=1 VBlank read, this new explicit *counterfactual* opt-in tracer tracks
accumulator bits0–6 as symbolically unknown; it rejects any opcode that
would consume them before a known LDA replacement. It does NOT supply fake
sprite flags, PPU bus values, real reset phase or RNG sequence. The prior
GK156 exhaustive 128-way candidate audit is untouched and remains available.

Reproduction from complete source with sibling historical directories:
`cmake -S execution_157 -B build157 -DCMAKE_BUILD_TYPE=Release &&
 cmake --build build157 -j6 && ctest --test-dir build157 --output-on-failure`

With PRIVATE authenticated original stock NES ROM only:
`GK1_ORIGINAL_STOCK_ROM=/private/stock.nes ctest --test-dir build157 -R GK1_157 -V`
`./build157/gk1_native_shell --source-symbolic-vblank-exit /private/stock.nes 0 1`

Do not distribute original ROM/SRAM/savestates/screenshots/music. No Mesen
parity established here; the original first Spring, exact RNG call chronology,
AI, full campaigns, Win32/NSIS and physical Xbox remain incomplete.
