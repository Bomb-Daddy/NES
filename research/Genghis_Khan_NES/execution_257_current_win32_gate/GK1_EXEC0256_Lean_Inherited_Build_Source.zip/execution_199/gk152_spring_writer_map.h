#ifndef GK152_SPRING_WRITER_MAP_H
#define GK152_SPRING_WRITER_MAP_H
#include <stddef.h>
#include <stdint.h>
/* Copyright-clean ORIGINAL NES static PRG byte-pattern candidate inventory.
 * A pattern is NOT a decoded instruction, proven writer, bank switch, or
 * executed first-Spring routine. No original PRG bytes are distributed.
 * RAM layout: authenticated original country array $6DCD, 83 bytes each,
 * up to 27 World records. The narrower 14-country Mongol window is tracked
 * independently and is not presumed to be the current scenario.
 */
#define GK152_BANKS 16u
#define GK152_PRG_SIZE 16384u
#define GK152_COUNTRY_BASE 0x6dcdu
#define GK152_COUNTRY_STRIDE 83u
#define GK152_COUNTRY_MONGOL 14u
#define GK152_COUNTRY_WORLD 27u
typedef enum {
 GK152_OK=0, GK152_BAD_ARG=1, GK152_BAD_LAYOUT=2, GK152_NOT_AUTHENTIC=3
} Gk152Status;
typedef struct {
 uint32_t raw_absolute_write_candidates;
 uint32_t raw_country_world_candidates;
 uint32_t raw_country_mongol_candidates;
 uint32_t raw_indirect_store_byte_candidates;
 uint32_t raw_pointer_base_candidates;
 uint32_t raw_absolute_write_by_bank[GK152_BANKS];
 uint32_t raw_country_world_by_bank[GK152_BANKS];
 uint32_t raw_indirect_store_by_bank[GK152_BANKS];
 uint16_t first_world_cpu_address; /* zero means no raw candidate */
 uint8_t first_world_bank;
 uint8_t authenticated; /* only set by exact user-provided source probe */
 uint8_t produced_playable_spring; /* never true for this static inventory */
} Gk152WriterMap;
/* Synthetic unit input accepted only in this non-authentic branch.
 * Strict iNES header, 16*16k PRG; all bytes treated as candidate offsets,
 * including data and unaligned bytes. Failure leaves output untouched. */
Gk152Status gk152_inventory_candidate_bytes(const uint8_t *ines,
 size_t bytes,Gk152WriterMap *out);
/* Owner-supplied private 262160-byte original ROM, exact SHA256 gate.
 * This function never writes, copies, or publishes private PRG content. */
Gk152Status gk152_inventory_original_rom(const char *path,Gk152WriterMap *out);
#endif
