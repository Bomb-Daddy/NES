# GK1 EXEC0125 — implementer and hostile QA handoff (2026-11-09)

## Verified inheritance
Recover latest complete EXEC0124; source ZIP `GK1_EXEC0124_Complete_Historical_C11_Source_v1.00.zip`, exact sha256 `3a682ecda4159a61d596c711e39ec35d6e61f3efe7bcc140ed9b428bc7c7f997`. The same complete 337-file native game is copied to execution_125 with changes below; don't rebuild from old 062 or replace settled systems. Keep genuine stock, approved modified ROM, Enhanced rules, manual-derived rules and native Linux behavior distinct.

## Actual diff / test objective
`gk125_cpu_arith.h/c`: 16 original 6502 ADC/SBC mode decoder and arithmetic. `gk83_reset_trace.c`: source-backed bus fetch routing; `gk100_cpu_cycles.c`: correct clocks/page crossings. `test_gk125_cpu_arith.c`: 16-mode decoder/clock coverage, 67,108,864 independently calculated flag/ALU checks across all byte inputs and flags, invalid pointer/mode rollback and optional exact private-stock original ROM first unknown work RAM gate replay. `CMakeLists.txt`, desktop version, source-side package contract and shell version changed to 1.25.0-dev1. No assumptions about startup RNG, no unauthorized Spring mutation.

## Reproducible commands
`cmake -S execution_125 -B build125 -DCMAKE_BUILD_TYPE=Release; cmake --build build125 -j6; ctest --test-dir build125 -j6 --output-on-failure; (cd build125 && cpack -G DEB); xvfb-run -a build125/gk1_native_shell --smoke-frames 120; dpkg-deb -x build125/gk1-native-research_1.25.0~dev1_amd64.deb extracted; xvfb-run -a extracted/opt/gk1-native-research/gk1_native_shell --smoke-frames 120`. Debug and sanitizer builds use separate build dirs; sanitizer `ASAN_OPTIONS=detect_leaks=0`. Optional *private only* test: `build125/test_gk125_cpu_arith /private/path/to/exact-stock-rom.nes`; verify file SHA-256 beforehand.

## Stop/next gate
Unseeded original CPU trace remains 70 executed instructions then unknown $00F5. A source-correct opcode subset is necessary but insufficient for original first Spring. Recover original boot RAM/peripheral state from controlled authentic Mesen startup (provenance, cycles and correct RAM bank) or rigorously resolve ROM source transformations before enabling phase, merchant presence and 3 real orders. The **actual first playable Spring** is the top next game-level priority. Don't count archived screenshot or research 3-order viewer as a genuine initialized campaign. Win32, NSIS, physical Xbox and full campaign acceptance NOT RUN. Preserve all history and the hourly task unless Director explicit stop/full verified release.
