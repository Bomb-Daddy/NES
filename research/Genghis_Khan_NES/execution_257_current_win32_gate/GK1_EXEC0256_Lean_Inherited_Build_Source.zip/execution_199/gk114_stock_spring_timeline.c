#include "gk114_stock_spring_timeline.h"
#include "gk1_source_identity.h"
#include "gk75_spring_economy.h"
#include <stdio.h>
#include <string.h>
/* 6 source-derived, 16-byte little-endian observations for checkpoint
 * 08,09,10,11,12,14. SHA only is public, observations and source ROM PRIVATE. */
static const uint8_t source_sha256[32]={
 0x09,0xd7,0xe0,0x00,0x34,0xb1,0x52,0xd0,
 0xcd,0x49,0xe6,0x86,0x2e,0x93,0x64,0xdd,
 0xa7,0x6d,0xcc,0x7a,0x99,0x99,0x22,0x21,
 0x1b,0x2c,0x72,0x5c,0x72,0xd2,0x55,0x3c};
typedef struct {
 uint8_t checkpoint,bank,orders,countries;
 uint16_t year,gold,food,troops,rate,unused;
} Snapshot;
static uint16_t le16(const uint8_t *p){return (uint16_t)((uint16_t)p[0]|((uint16_t)p[1]<<8));}
static Snapshot read_row(const uint8_t *p){
 Snapshot x={0};x.checkpoint=p[0];x.bank=p[1];
 x.year=le16(p+2);x.gold=le16(p+4);x.food=le16(p+6);
 x.troops=le16(p+8);x.rate=le16(p+10);x.orders=p[12];
 x.countries=p[13];x.unused=le16(p+14);return x;
}
static int equal_except(const Snapshot *a,const Snapshot *b,unsigned mask){
 /* 1 year; 2 gold; 4 food; 8 troops; 16 rate; 32 orders. */
 return ((mask&1)||a->year==b->year)&&((mask&2)||a->gold==b->gold)&&
  ((mask&4)||a->food==b->food)&&((mask&8)||a->troops==b->troops)&&
  ((mask&16)||a->rate==b->rate)&&((mask&32)||a->orders==b->orders);
}
Gk114Status gk114_verify_private_fresh_history(const char *source_csv,
 const Gk1LoadedScenario *pristine_mongol,const char *private_96bytes,
 Gk114Timeline *out){
 if(!source_csv||!pristine_mongol||!private_96bytes||!out)return GK114_ARGUMENT;
 if(!gk1_verified_original_csv(source_csv))return GK114_SOURCE_REFUSED;
 Gk1TemplateDataset dataset={0};Gk1LoadedScenario canonical={0};
 if(gk1_template_load(source_csv,&dataset)!=GK1_LOAD_OK||
    gk1_open_loaded_scenario(&dataset,GK1_MONGOL_CONQUEST,&canonical)!=GK1_LOAD_OK)
  return GK114_SOURCE_REFUSED;
 if(pristine_mongol->scenario_id!=GK1_MONGOL_CONQUEST||
    pristine_mongol->country_count!=GK1_COUNTRIES_MONGOL||
    pristine_mongol->phase!=GK1_PRE_SETUP_TEMPLATE||
    memcmp(pristine_mongol,&canonical,sizeof canonical)!=0)
  return GK114_TEMPLATE_DRIFT;
 FILE *f=fopen(private_96bytes,"rb");if(!f)return GK114_PRIVATE_EVIDENCE_REFUSED;
 uint8_t raw[96]={0};size_t n=fread(raw,1,sizeof raw,f);
 int extra=fgetc(f),failed=ferror(f),closed=fclose(f);
 if(n!=sizeof raw||extra!=EOF||failed||closed)return GK114_PRIVATE_EVIDENCE_REFUSED;
 uint8_t digest[32];gk1_sha256_bytes(raw,sizeof raw,digest);
 if(memcmp(digest,source_sha256,sizeof digest)!=0)return GK114_PRIVATE_EVIDENCE_REFUSED;
 Snapshot x[6];static const uint8_t ids[6]={8,9,10,11,12,14};
 for(unsigned i=0;i<6;i++){
  x[i]=read_row(raw+16*i);
  if(x[i].checkpoint!=ids[i]||x[i].bank!=1||x[i].countries!=14||
     x[i].unused||x[i].food>999||x[i].gold>999||x[i].troops>999||x[i].rate>999||x[i].orders>3)
   return GK114_CHRONOLOGY_REFUSED;
 }
 const Gk1CountryTemplate *c=&canonical.countries[0];
 unsigned pop=(unsigned)c->troops+c->town+c->masons+c->artisans+c->food_workers;
 if(pop>999||x[0].year!=1174||x[0].food!=c->goods[10]||
    x[0].gold!=c->gold||x[0].troops!=c->troops||x[0].orders!=0||
    !equal_except(&x[0],&x[1],4)||x[1].food!=(unsigned)x[0].food*2u||
    !equal_except(&x[1],&x[2],1|16)||x[2].year!=x[1].year+1||
    x[2].rate==0||!equal_except(&x[2],&x[3],0)||
    !equal_except(&x[3],&x[4],2|4|8)||
    x[4].food>=x[3].food||x[4].year!=1175||
    !equal_except(&x[4],&x[5],32)||x[5].orders!=3||x[4].orders!=0)
  return GK114_CHRONOLOGY_REFUSED;
 /* An independently bounded GK75 source calculator predicts food consumption
  * with the pre-setup population, but NOT the intermediate population that
  * was physically in original RAM. A numerical match is not universal proof. */
 Gk75SpringFields fields={c->troops,c->town,c->masons,c->artisans,
  c->food_workers,x[3].food,x[3].gold,c->economy,c->morale,c->tax};
 Gk75SpringResult projection={0};
 if(gk75_spring_food_tax_pay(&fields,&projection)!=GK75_OK)
  return GK114_MODEL_REFUSED;
 Gk114Timeline next={0};next.first_year=x[0].year;
 next.playable_year=x[5].year;
 next.initial_food=x[0].food;next.setup_food=x[1].food;
 next.post_feed_food=x[4].food;next.draft_population=(uint16_t)pop;
 next.observed_food_consumed=(uint16_t)(x[3].food-x[4].food);
 next.source_feed_food_matches=(uint8_t)(projection.after.food==x[4].food);
 next.observed_orders=x[5].orders;
 next.modeled_vs_observed_gold=(int32_t)projection.after.gold-x[4].gold;
 next.modeled_vs_observed_troops=(int32_t)projection.after.troops-x[4].troops;
 /* The actual NATIVE C11 game has not advanced into Spring; never unlock. */
 next.setup_resolved=0;next.first_spring_ready=0;next.port_orders_granted=0;
 *out=next;return GK114_OK;
}
