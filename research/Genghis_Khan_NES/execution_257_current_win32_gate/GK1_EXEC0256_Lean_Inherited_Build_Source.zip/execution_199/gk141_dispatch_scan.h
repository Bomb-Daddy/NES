#ifndef GK141_DISPATCH_SCAN_H
#define GK141_DISPATCH_SCAN_H
#include <stddef.h>
#include <stdint.h>
#define GK141_IMAGE_SIZE 262160u
#define GK141_BANK_BYTES 16384u
#define GK141_BANK_COUNT 16u
typedef enum {GK141_OK=0,GK141_BAD_INPUT=1,GK141_SOURCE_UNVERIFIED=2} Gk141Result;
typedef struct {
 uint32_t candidate_total,by_bank[16],by_selector[256];
 uint16_t dispatch_target[256];
 uint32_t target_below_fixed,candidates_boundary_rejected;
 uint8_t first_bank,first_selector;
 uint16_t first_candidate_pc;
} Gk141DispatchMap;
Gk141Result gk141_scan_image(const uint8_t *,size_t,Gk141DispatchMap *);
Gk141Result gk141_scan_authenticated(const char *,Gk141DispatchMap *);
#endif
