# EXEC0123 completion ledger — 2026-11-09

IMPLEMENTED: Existing research game inherited from complete EXEC0121 plus re-integrated published EXEC0122 logic instructions and NEW 31 CPU LDA/LDX/LDY/STA/STX/STY addressing instructions in actual source interpreter. Source read-byte unknown gates preserved. Packaging 1.23.0-dev1.
VERIFIED_STATIC: all 31 official opcodes vs 225 rejected, 65,536 status/byte, 65,536 address wrap, source-gated memory and cycle logic. Inherited 122 24 logical opcode tests.
TESTED_PORT_LINUX: 81/81 Release, 81/81 Debug, 81/81 ASan/UBSan with leak checks disabled; real X11 graphical 120 frames and DEB installed-style execution 120 frames PASS.
OBSERVED_RUNTIME_STOCK: existing separate user-authentic fresh Mongol Spring1175, archived Mongol Spring1175 and archived World Spring1206; this run did not execute Mesen.
NOT RUN: native Win32, NSIS, physical Xbox and end-to-end campaign, first Spring authenticity.
OPEN: Original player/difficulty/character RNG and real first Spring 3 orders, Trade merchant presence/RNG, strategic commands, autonomous AI, diplomacy, dynasty ages6/7/8, battle terminal/aftermath, graphics/APU, cold-load full campaigns.
PUBLICATION: Copyright-clean code/QA may go to public GitHub; private original USA ROM, modified ROM, Mesen states/SRAM, screenshots/audio NEVER public. Full EXEC0122 ZIP missing; do not incorrectly claim original exact 122 source was inherited.
