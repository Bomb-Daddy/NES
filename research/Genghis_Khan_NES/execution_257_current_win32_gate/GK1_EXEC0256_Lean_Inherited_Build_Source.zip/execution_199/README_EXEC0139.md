# EXEC0139 — authentic archived MesenCE CPU RNG seed extraction

Use the *complete* inherited C11 game. `gk139_mesen_state.c` parses a strictly
bounded decompressed Mesen named-field buffer, including the real 2KB CPU
`memoryManager.internalRam` at `$84-$89`, current CPU PC/cycles, and correct
physical mapper country-bank source at `$0DCD`. `gk1_app_source_mesen_state_probe`
is a guarded, read-only method on the actual native game. No private bytes,
licensed ROMs, Mesen states, SRAM, graphic or sound assets appear here.

`gk139_archived_state_extract.py` is a Python-standard-library tool for
OWNER-AUTHORIZED PRIVATE inputs. It verifies the exact stock-USA NES SHA256,
discovers the named-state compressed stream without hardcoded offsets, and
refuses missing/ambiguous fields or bank presence. The tool emits only small
provenance/seed diagnostics, not a savestate, ROM or country record dump. Use
with `--private-original-rom /private/path/to/stock.nes` and a private `.mss`.

**Interpretation**: archived original stock MesenCE save states contain an
actual post-setup RNG seed in CPU internal RAM. This is better than inferring
seed from Gold/Rate screenshots. It does *not* establish the seed at fresh
power-on, frame-by-frame NMI modifications, number of PRNG draws, character
rolls, or a causally identified original Spring Rate draw. Candidate matches
of `gk138_scan_spring_rate` must not be promoted to constants or legal NES
orders. Fresh reset vs archived-restored must remain separate.

Test: `cmake -S execution_139 -B build -DCMAKE_BUILD_TYPE=Release &&
cmake --build build -j4 && ctest --test-dir build --output-on-failure`.
Authentic private savestate analysis remains private; Win32, NSIS and physical
Xbox are NOT RUN until actually tested. No public GitHub upload of private
Mesen or ROM material.
