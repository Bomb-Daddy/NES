#ifndef GK218_STOCK_WRITE_TRACE_H
#define GK218_STOCK_WRITE_TRACE_H
#include <stdint.h>
/* EXEC0218 private owner-side Mesen write-trace intake.  A CSV capture can be
 * checked against the private exact-stock ROM, but the capture itself is NOT
 * cryptographically attested by the ROM SHA/header: provenance still requires
 * independent Mesen runtime evidence.  Neither a successful parser nor a
 * synthetic test unlocks first Spring, orders, or original-market offers. */
typedef enum {
 GK218_OK=0,GK218_BAD_ARGS=1,GK218_BAD_ROM=2,
 GK218_IO=3,GK218_BAD_TRACE=4,GK218_INCOMPLETE=5
} Gk218Status;
typedef struct {
 uint32_t writes,confirmed_writes,unconfirmed_writes,rng_writes;
 uint32_t distinct_rng_mask,stages;
 uint64_t last_cycle;
 uint16_t final_year,final_rate;
 uint8_t final_orders,final_countries;
 uint8_t bank_observed_workram;
} Gk218Report;
/* Parse an UNTRUSTED trace schema without any runtime-source attestation.
 * A parser PASS is NEVER original NES observation or a gameplay permission. */
Gk218Status gk218_parse_trace_untrusted(const char *private_csv,Gk218Report *out);
/* Validate CSV capture with explicit COMPLETE/REPLAY gates. Failure is atomic
 * (out unchanged). Original ROM stays outside public source and installers. */
Gk218Status gk218_audit_fresh_trace(const char *stock_rom,
                                   const char *private_csv,Gk218Report *out);
#endif
