#ifndef GK161_ENHANCED_YEAR2_H
#define GK161_ENHANCED_YEAR2_H
#include "gk160_enhanced_winter.h"
/* Approved Enhanced labor-only year rollover, NOT stock NES spring economy,
 * first-Spring initialization, AI, dynasty, annual ages, taxes or rates. */
#define GK161_MAX_ACTIONS 3u
#define GK161_RECEIPT_BYTES 192u
typedef enum {GK161_OK=0,GK161_INPUT,GK161_SOURCE,GK161_NO_ORDERS,
 GK161_NO_WORKER,GK161_IO,GK161_EXISTS,GK161_CORRUPT} Gk161Result;
typedef struct {
 Gk1LoadedScenario mutable_world;
 Gk71Budget budget;
 uint16_t year;
 uint8_t active,action_count,pass_ended;
 Gk116LaborAction actions[GK161_MAX_ACTIONS];
} Gk161EnhancedYear2;
Gk161Result gk161_open(const Gk116EnhancedAssign *sp,
 const Gk158EnhancedSummer *su,const Gk159EnhancedFall *fa,
 const Gk160EnhancedWinter *wi,const Gk79Checkpoint *original,
 Gk161EnhancedYear2 *out);
int gk161_attestation_intact(const Gk161EnhancedYear2 *y,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk79Checkpoint *original);
Gk161Result gk161_transfer(Gk161EnhancedYear2 *y,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk79Checkpoint *original,uint8_t from,uint8_t to,uint16_t quantity);
Gk161Result gk161_pass(Gk161EnhancedYear2 *y,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk79Checkpoint *original);
Gk161Result gk161_save_new(const char *path,const Gk79Checkpoint *original,
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su,
 const Gk159EnhancedFall *fa,const Gk160EnhancedWinter *wi,
 const Gk161EnhancedYear2 *y);
Gk161Result gk161_cold_load(const char *path,const Gk79Checkpoint *original,
 uint8_t enhanced,Gk116EnhancedAssign *sp_out,Gk158EnhancedSummer *su_out,
 Gk159EnhancedFall *fa_out,Gk160EnhancedWinter *wi_out,
 Gk161EnhancedYear2 *y_out);
#endif
