#include "gk158_enhanced_summer.h"
#include "gk1_source_identity.h"
#include <string.h>
#include <stdio.h>
#include <errno.h>

static Gk158Result from_worker(Gk116Result r){
 if(r==GK116_OK)return GK158_OK;
 if(r==GK116_NO_WORKER)return GK158_NO_WORKER;
 if(r==GK116_NO_ORDERS)return GK158_NO_ORDERS;
 return GK158_INPUT;
}
static int spring_done(const Gk116EnhancedAssign *s,const Gk79Checkpoint *o){
 return gk116_attestation_intact(s,o)&&s->budget.ended==1u&&s->budget.remaining==0u;
}
Gk158Result gk158_open(const Gk116EnhancedAssign *spring,
 const Gk79Checkpoint *original,Gk158EnhancedSummer *out){
 if(!out)return GK158_INPUT;
 if(!spring_done(spring,original))return GK158_SOURCE;
 Gk158EnhancedSummer next={0};
 next.mutable_world=spring->mutable_world;
 next.budget=spring->budget;
 if(gk71_next_season(&next.mutable_world,&next.budget,GK71_SUMMER)!=GK71_OK)
  return GK158_SOURCE;
 next.active=1u;
 *out=next;
 return GK158_OK;
}
int gk158_attestation_intact(const Gk158EnhancedSummer *s,
 const Gk116EnhancedAssign *spring,const Gk79Checkpoint *original){
 if(!s||s->active!=1u||!spring_done(spring,original)||
    s->action_count>GK158_MAX_ACTIONS||s->pass_ended>1u||
    s->budget.season!=GK71_SUMMER||s->budget.governor!=GK71_BASE||
    s->budget.allowance!=3u||s->budget.playable!=1u||
    s->budget.completed!=s->action_count||
    (!s->pass_ended && s->budget.remaining+s->action_count!=3u)||
    (s->pass_ended && (s->budget.remaining!=0u||
       !s->budget.ended||s->action_count>=3u))||
    s->budget.ended!=(s->budget.remaining==0u))return 0;
 Gk158EnhancedSummer replay={0};
 if(gk158_open(spring,original,&replay)!=GK158_OK)return 0;
 for(unsigned i=0;i<s->action_count;i++){
  const Gk116LaborAction *a=&s->actions[i];
  if(gk116_worker_math(&replay.mutable_world,&replay.budget,
      spring->player_index,a->from,a->to,a->quantity)!=GK116_OK)return 0;
  replay.actions[replay.action_count++]=*a;
 }
 if(s->pass_ended){
  if(gk71_pass(&replay.budget)!=GK71_OK)return 0;
  replay.pass_ended=1u;
 }
 return memcmp(&replay,s,sizeof replay)==0;
}
Gk158Result gk158_transfer(Gk158EnhancedSummer *summer,
 const Gk116EnhancedAssign *spring,const Gk79Checkpoint *original,
 uint8_t from,uint8_t to,uint16_t quantity){
 if(!summer||!spring||!original)return GK158_INPUT;
 if(!gk158_attestation_intact(summer,spring,original))return GK158_SOURCE;
 if(summer->pass_ended||summer->budget.ended||
    summer->action_count>=GK158_MAX_ACTIONS)return GK158_NO_ORDERS;
 Gk158EnhancedSummer next=*summer;
 Gk158Result r=from_worker(gk116_worker_math(&next.mutable_world,&next.budget,
     spring->player_index,from,to,quantity));
 if(r!=GK158_OK)return r;
 next.actions[next.action_count++]=(Gk116LaborAction){from,to,quantity};
 if(!gk158_attestation_intact(&next,spring,original))return GK158_SOURCE;
 *summer=next;return GK158_OK;
}
Gk158Result gk158_pass(Gk158EnhancedSummer *summer,
 const Gk116EnhancedAssign *spring,const Gk79Checkpoint *original){
 if(!summer||!spring||!original)return GK158_INPUT;
 if(!gk158_attestation_intact(summer,spring,original))return GK158_SOURCE;
 if(summer->pass_ended||summer->budget.ended)return GK158_NO_ORDERS;
 Gk158EnhancedSummer next=*summer;
 if(gk71_pass(&next.budget)!=GK71_OK)return GK158_INPUT;
 next.pass_ended=1u;
 if(!gk158_attestation_intact(&next,spring,original))return GK158_SOURCE;
 *summer=next;return GK158_OK;
}
static void write_actions(uint8_t *dst,const Gk116LaborAction *a,unsigned count){
 for(unsigned i=0;i<count;i++){
  dst[4*i]=a[i].from;dst[4*i+1]=a[i].to;
  dst[4*i+2]=(uint8_t)a[i].quantity;
  dst[4*i+3]=(uint8_t)(a[i].quantity>>8);
 }
}
static uint16_t quantity(const uint8_t *p){
 return (uint16_t)((unsigned)p[2]|((unsigned)p[3]<<8));
}
static void encode(uint8_t raw[GK158_RECEIPT_BYTES],
 const Gk116EnhancedAssign *sp,const Gk158EnhancedSummer *su){
 memset(raw,0,GK158_RECEIPT_BYTES);
 memcpy(raw,"GS18",4u);raw[4]=1u;raw[5]=sp->profile;
 raw[6]=(uint8_t)sp->mutable_world.scenario_id;raw[7]=sp->player_index;
 raw[8]=(uint8_t)sp->year;raw[9]=(uint8_t)(sp->year>>8);
 raw[10]=(uint8_t)sp->rate;raw[11]=(uint8_t)(sp->rate>>8);
 raw[12]=sp->action_count;raw[13]=sp->pass_ended;
 raw[14]=su->action_count;raw[15]=su->pass_ended;
 memcpy(raw+16u,sp->source_sha,32u);
 write_actions(raw+48u,sp->actions,sp->action_count);
 write_actions(raw+60u,su->actions,su->action_count);
 gk1_sha256_bytes(raw,96u,raw+96u);
}
Gk158Result gk158_save_new(const char *path,const Gk79Checkpoint *original,
 const Gk116EnhancedAssign *spring,const Gk158EnhancedSummer *summer){
 if(!path||!*path)return GK158_INPUT;
 if(!gk158_attestation_intact(summer,spring,original))return GK158_SOURCE;
 uint8_t raw[GK158_RECEIPT_BYTES];encode(raw,spring,summer);
 errno=0;FILE *f=fopen(path,"wbx");
 if(!f)return errno==EEXIST?GK158_EXISTS:GK158_IO;
 size_t n=fwrite(raw,1,sizeof raw,f);int failed=ferror(f),closed=fclose(f);
 if(n!=sizeof raw||failed||closed){(void)remove(path);return GK158_IO;}
 return GK158_OK;
}
Gk158Result gk158_cold_load(const char *path,const Gk79Checkpoint *original,
 uint8_t enhanced,Gk116EnhancedAssign *spring_out,Gk158EnhancedSummer *summer_out){
 if(!path||!*path||!spring_out||!summer_out)return GK158_INPUT;
 if(enhanced!=1u)return GK158_SOURCE;
 Gk116EnhancedAssign sp={0};Gk158EnhancedSummer su={0};
 if(gk116_open(original,enhanced,&sp)!=GK116_OK)return GK158_SOURCE;
 FILE *f=fopen(path,"rb");if(!f)return GK158_IO;
 uint8_t raw[GK158_RECEIPT_BYTES+1u];
 size_t n=fread(raw,1,sizeof raw,f);int failed=ferror(f),closed=fclose(f);
 if(failed||closed)return GK158_IO;
 if(n!=GK158_RECEIPT_BYTES||memcmp(raw,"GS18",4u)||raw[4]!=1u||
    raw[12]>GK116_MAX_ACTIONS||raw[14]>GK158_MAX_ACTIONS||
    raw[13]>1u||raw[15]>1u)return GK158_CORRUPT;
 for(unsigned i=0;i<raw[12];i++){
  const uint8_t *a=raw+48u+4u*i;
  if(gk116_transfer(&sp,original,a[0],a[1],quantity(a))!=GK116_OK)
   return GK158_CORRUPT;
 }
 if(raw[13]&&gk116_pass_remaining(&sp,original)!=GK116_OK)return GK158_CORRUPT;
 if(gk158_open(&sp,original,&su)!=GK158_OK)return GK158_CORRUPT;
 for(unsigned i=0;i<raw[14];i++){
  const uint8_t *a=raw+60u+4u*i;
  if(gk158_transfer(&su,&sp,original,a[0],a[1],quantity(a))!=GK158_OK)
   return GK158_CORRUPT;
 }
 if(raw[15]&&gk158_pass(&su,&sp,original)!=GK158_OK)return GK158_CORRUPT;
 uint8_t check[GK158_RECEIPT_BYTES];encode(check,&sp,&su);
 if(memcmp(raw,check,sizeof check))return GK158_CORRUPT;
 *spring_out=sp;*summer_out=su;
 return GK158_OK;
}
