# EXEC0155 — Genghis Khan I native C11 research, v1.55.0-dev1

**Status:** VERIFIED_STATIC and TESTED_PORT_LINUX where separately documented. **NOT** a playable authentic first Spring or a complete Windows game.

## Genuine implementation increment

The authenticated fixed PRG bank's 6502 opcode sequence at CPU $C5BE constitutes the repeated pattern `LDA $2002; BPL <same LDA>; RTS`. The only PPUSTATUS bit relevant while **BPL takes the loop** is bit 7, VBlank. Earlier GK154 source tracing failed closed on every read under a hypothetical rendering window because unmodeled sprite flags (PPUSTATUS bits 5–6) could affect reads in general. EXEC0155 adds a **new strictly opt-in mode** that consumes such a read only with sign = 0 and only with the live cartridge instruction sequence matching the exact `LDA; BPL -5; RTS` pattern. It never invents the low seven bits, never allows a source-ambiguous sign=1 exit to leak unknown A/flags, and refuses unknown interrupts or PPU edge races. Original unconditional interpreter/hardware gates are unchanged.

Implemented across `gk103_ntsc_ppu`, `gk83_reset_trace`, `gk1_app_state` and `gk1_native_shell` in the **same inherited C11 game**. Source-gated `gk1_app_source_sign_only_poll` is read-only at PRE_SETUP/AWAIT_SOURCE; invalid ROM, branch, origin, hardware edges and app states refuse without opening game commands. New positive and hostile tests in `test_gk155_sign_only_poll.c`.

**Critical limitation:** Both traces inherit EXEC0154's explicitly **counterfactual FIRST VBlank-edge choice** and a hypothetical PPU reset-origin/even-pre-render clock. They **do not** establish correct original-source RNG history, real player-ready Spring or runtime Mesen parity. As tested, first-branch scenario: old 25,731 instructions vs new 33,419 with 3,844 sign-zero source reads; second-branch scenario: old 17,221 vs new 24,911 with 3,845 sign-zero source reads. Both halt at next source hardware gate, with zero successful country-region writes before halt. A bounded failed trace cannot establish that the NES has no later stores.

## Reproduction

Use current full source in `execution_155/` with historical sibling `execution_034/035/039/040/045/047/049` present:

```sh
cmake -S execution_155 -B build155 -DCMAKE_BUILD_TYPE=Release
cmake --build build155 -j4
ctest --test-dir build155 --output-on-failure
# PRIVATE ORIGINAL NES CARTRIDGE ONLY; never include it in public distribution:
GK1_ORIGINAL_STOCK_ROM=/private/authorized/stock.nes ctest --test-dir build155 -R GK1_155 -V
./build155/gk1_native_shell --source-sign-only-poll /private/authorized/stock.nes 0 1
./build155/gk1_native_shell --source-sign-only-poll /private/authorized/stock.nes 0 2
(cd build155 && cpack -G DEB)
```

Retain all EXEC0154 predecessor source; no ROM, Mesen savestates, screenshots, samples, audio, country records or private trace data in public source or GitHub. The exact original 262,160-byte USA cartridge is private and is only an opt-in runtime test input.

**Priority unfulfilled:** original setup/ruler/difficulty/48-bit RNG / full fourteen and twenty-seven country transformations/three actual NES Classic controller orders in real first playable Spring; authentic merchant scheduling, AI, dynasty, diplomacy, battle aftermath, saves, two autonomous campaigns, native Win32 NSIS and physical Xbox. Continue recurring execution; never call this a playable release.
