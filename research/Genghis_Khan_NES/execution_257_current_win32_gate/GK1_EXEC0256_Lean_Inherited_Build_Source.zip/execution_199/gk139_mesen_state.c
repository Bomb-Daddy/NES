#include "gk139_mesen_state.h"
#include <string.h>
#include <limits.h>
#define GK139_COUNTRY_OFFSET 0x0DCDu
#define GK139_COUNTRY_BYTES 83u
static uint32_t le32(const uint8_t *p){
 return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static uint64_t le64(const uint8_t *p){
 uint64_t n=0;for(unsigned i=0;i<8;i++)n|=(uint64_t)p[i]<<(8u*i);return n;
}
static int country_present(const uint8_t *p,size_t n){
 if(n<GK139_COUNTRY_OFFSET+GK139_COUNTRY_BYTES)return 0;
 unsigned any=0;for(unsigned i=0;i<GK139_COUNTRY_BYTES;i++)any|=p[GK139_COUNTRY_OFFSET+i];
 return any!=0u;
}
Gk139Status gk139_parse_uncompressed_state(const uint8_t *bytes,size_t size,
                                            Gk139MesenProof *out){
 if(!bytes||!out||size<32u||size>16u*1024u*1024u)return GK139_STATE_MALFORMED;
 const uint8_t *cpu=NULL,*work=NULL,*save=NULL,*pc=NULL,*cycles=NULL;
 size_t pos=0,cpulen=0,worklen=0,savelen=0,pclen=0,cylen=0;
 Gk139MesenProof result={0};
 while(pos<size){
  size_t start=pos;
  while(pos<size && bytes[pos]!=0){
   /* A field key is printable ASCII. Never search within the opaque values. */
   if(bytes[pos]<33u||bytes[pos]>126u||pos-start>=127u)return GK139_STATE_MALFORMED;
   pos++;
  }
  if(pos==size||pos==start||size-pos<5u)return GK139_STATE_MALFORMED;
  size_t len=pos-start;
  pos++;uint32_t value_len=le32(bytes+pos);pos+=4;
  if((size_t)value_len>size-pos)return GK139_STATE_MALFORMED;
#define MATCH(field) (len==sizeof(field)-1u && memcmp(bytes+start,field,sizeof(field)-1u)==0)
  if(MATCH("memoryManager.internalRam")){
   if(cpu)return GK139_STATE_AMBIGUOUS;
   cpu=bytes+pos;cpulen=value_len;
  }else if(MATCH("mapper.workRam")){
   if(work)return GK139_STATE_AMBIGUOUS;
   work=bytes+pos;worklen=value_len;
  }else if(MATCH("mapper.saveRam")){
   if(save)return GK139_STATE_AMBIGUOUS;
   save=bytes+pos;savelen=value_len;
  }else if(MATCH("cpu.pc")){
   if(pc)return GK139_STATE_AMBIGUOUS;
   pc=bytes+pos;pclen=value_len;
  }else if(MATCH("cpu.cycleCount")){
   if(cycles)return GK139_STATE_AMBIGUOUS;
   cycles=bytes+pos;cylen=value_len;
  }
#undef MATCH
  pos+=(size_t)value_len;
  if(result.field_count==UINT32_MAX)return GK139_STATE_MALFORMED;
  result.field_count++;
 }
 if(!cpu||cpulen!=2048u||!work||worklen!=8192u||!save||savelen!=8192u||
    !pc||pclen!=2u||!cycles||cylen!=8u)return GK139_STATE_MALFORMED;
 int w=country_present(work,worklen),s=country_present(save,savelen);
 if(w==s)return GK139_STATE_AMBIGUOUS;
 result.country_bank=w?GK139_BANK_WORK:GK139_BANK_SAVE;
 memcpy(result.nes_seed,cpu+0x84u,6u);
 for(unsigned i=0;i<6u;i++)result.seed48=(result.seed48<<8)|result.nes_seed[i];
 result.program_counter=(uint16_t)((uint16_t)pc[0]|((uint16_t)pc[1]<<8));
 result.cpu_cycles=le64(cycles);
 *out=result;
 return GK139_STATE_OK;
}
