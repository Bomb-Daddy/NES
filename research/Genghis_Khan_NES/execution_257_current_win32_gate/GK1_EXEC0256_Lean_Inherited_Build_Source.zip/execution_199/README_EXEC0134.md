# EXEC0134 — Correct original stock controller command identity (2026-11-09)

This is a patch to the same integrated C11 game, inherited in full from EXEC0133; it is not a new game or research prototype.

## Source defect and correction

Previously the visible stock command labels were ordered `TAX` (index 0), `ASSIGN` (index 1), etc., but controller A at index **0** entered the Enhanced Assign screen. This let a player accidentally access an Enhanced-only worker transfer by choosing TAX, and did not route ASSIGN to its own UI. The fix makes one canonical mapping for all fourteen visible commands and routes Enhanced Assign only from command index 1. TAX remains source-locked, so no unsupported original tax formula or order is invented. Original Trade remains a read-only price reference, and original first Spring still cannot be independently generated.

## Source and verification labels

- `VERIFIED_STATIC`: `gk134_stock_command_route.c/.h`, actual `gk1_app_state.c` dispatch using route enum; all fourteen labels, exact action mapping, boundaries and null-invalid inputs.
- `TESTED_PORT_LINUX`: `test_gk134_stock_command_route.c` (all 14 identities + TAX/ASSIGN negative guards); Release/Debug and actual native Linux UI smoke. Positive real-stock controller tests require the user-private 14/27-country source records and are **NOT RUN** unless explicitly supplied.
- `OBSERVED_RUNTIME_STOCK`: only pre-existing 2026-11-07 Mesen fresh and restored cases; no new original Mesen execution here.
- `NOT RUN`: Win32 binary, NSIS, physical Xbox, original/World full campaigns.

### Reproduce

`cmake -S execution_134 -B build -G Ninja -DCMAKE_BUILD_TYPE=Release && cmake --build build -j8 && ctest --test-dir build --output-on-failure -j8`

Private-positive optional: `build/test_gk134_stock_command_route <verified_economy.csv> <private_fresh.records> <private_archived_mongol.records> <private_archived_world.records>`.

Do not publish original ROM, private NES RAM/SaveRAM, original audio, images or saves on public GitHub.
