# EXEC0152 — original-stock PRG country writer candidate inventory (1.52.0-dev1)

**Authority:** inherited complete EXEC0151 native C11 application and authenticated PRIVATE original English NES cartridge SHA256 `ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3`. Previous fresh/archived first Springs are separately sourced and not universal RNG seeds, initial gold or Rate. All earlier native features, templates, controller UI, save/cold-load and historical data remain intact.

## Executable implementation

`gk152_spring_writer_map.c/.h` performs an **SHA-gated**, bounded scan of all sixteen 16KiB original PRG banks for *raw byte sequences* compatible with 6502 stores or read-modify-writes to original CPU RAM `$6000–$7FFF` and, specifically, the authentic 83-byte country array beginning at `$6DCD` (14 Mongol / 27 World records). It also counts potential indirect-store opcodes separately and occurrences of raw `$6DCD` pointer words. `gk1_app_source_spring_writer_map` is linked to the existing `Gk1App`, permitted only at `GK53_SETUP_AWAIT_SOURCE`, and is immutable on success and failure. The same `gk1_native_shell` includes `--source-spring-writers <private NES ROM>`, which only prints **aggregate counts**, never copyrighted ROM data. Synthetic and authenticated-private regression tests verify bank range, 14-vs-27-country distinction, negative cases, output rollback and native setup gating.

These byte-level *candidates* **are not decoded executable instructions**: some are unaligned or data; abs,X/Y effective addresses may differ from the literal base operand; indirect store byte matches do not identify their ultimate RAM destination. Even a real country write is not automatically first-Spring initialization. Therefore this tool cannot and does not claim a completed original setup, three playable orders, or emulator-derived CPU history. It is narrowly useful for prioritizing authenticated control-flow / pointer watchpoints in a future live emulator investigation.

## Verified source-only result on this owner-provided original cartridge

`--source-spring-writers` prints raw literal patterns: **492** absolute indexed/unaligned memory-write candidates to `$6DCD..$768B` (World 27-country bounding range), **183** within the first 14-record Mongol bounding range, **1,229** indirect-store opcode-byte candidates across 16 banks, and **48** raw `$6DCD` pointer-word patterns. These are **potential matches ONLY**, not 492 proven original Spring writes. Synthetic test anchors include correct and deliberately invalid 83-byte country extents and fail-closed on unknown ROM identity.

## Reproduction

```bash
cmake -S execution_152 -B build152 -DCMAKE_BUILD_TYPE=Release
cmake --build build152 -j8
GK1_ORIGINAL_STOCK_ROM=/private/original.nes ctest --test-dir build152 -j8 --output-on-failure
build152/gk1_native_shell --source-spring-writers /private/original.nes
```

**Status:** `VERIFIED_STATIC` original-cartridge byte inventory, `TESTED_PORT_LINUX` for current build/tests/graphical tests. `OBSERVED_RUNTIME_STOCK_FRESH_RESET` and `OBSERVED_RUNTIME_STOCK_ARCHIVED_RESTORED` remain inherited historical evidence only. `NOT RUN`: fresh native Mesen source watchpoints, Windows Win32, NSIS, physical Xbox and two full campaigns.

**Critical game gap unchanged:** no independent original first playable Spring with exact ruler/difficulty/ability RNG transforms for all 14/27 original countries and three player actions; merchant presence, AI, diplomacy, dynasty, real battle aftermath and complete campaigns remain unfinished. The next investigation must establish actual 6502 bank-switched source execution and indirect pointer writes at authentic first-Spring events, **then** implement the actual Spring transitions in the same game. Do not use any of these raw byte-pattern counts as gameplay constants. No private original cartridge, SRAM, Mesen snapshots, audiovisual assets or raw RAM can appear in public outputs.
