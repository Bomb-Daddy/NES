#include "gk185_stock_hotkey.h"
#include "gk183_checkpoint_isolation.h"
Gk185HotkeyRoute gk185_stock_hotkey_route(const Gk1App *a){
 if(!a)return GK185_REFUSE;
 switch(a->screen){
 case GK1_SCREEN_STOCK_CONTINUE:
 case GK1_SCREEN_STOCK_COMMANDS:
 case GK1_SCREEN_STOCK_TRADE_REFERENCE:
 case GK1_SCREEN_STOCK_STORAGE:break;
 default:return GK185_NOT_STOCK_SCREEN;
 }
 const Gk79Checkpoint *cp=&a->stock_checkpoint;
 if(cp->valid!=1u||cp->source_verified!=1u||
    !gk85_raw_source_intact(cp)||!gk88_stock_projection_intact(cp))
  return GK185_REFUSE;
 if(gk183_classic_storage_isolated(a))return GK185_CLASSIC_PRIVATE;
 if(a->rules_profile!=1u)return GK185_REFUSE;
 if(a->enhanced_assign.active||a->enhanced_summer.active||
    a->enhanced_fall.active||a->enhanced_winter.active||
    a->enhanced_year2.active||a->enhanced_continuation.active)
  return GK185_ENHANCED_STAGE;
 /* Enhanced selected but no Enhanced session yet.  Never fall through
  * into a Classic-only source snapshot masquerading as a campaign save. */
 return GK185_REFUSE;
}
