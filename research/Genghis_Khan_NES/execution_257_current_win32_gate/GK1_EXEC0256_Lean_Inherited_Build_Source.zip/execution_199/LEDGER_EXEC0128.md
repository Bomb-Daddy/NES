# Genghis Khan I execution ledger — EXEC0128, 2026-11-09

Status: research build, NOT completed playable game.
Source ancestry: whole recovered EXEC0127 project; all predecessor archive entries kept intact.
Implemented in executable C11: explicit known/unknown OAM register writes on original source trace, explicit-APU-phase source-known OAM DMA transaction; no peripheral phasing guesses.
VERIFIED_STATIC: compile under Werror C11; optional exact original ROM source hash check, 256 OAM byte rollback negative controls.
TESTED_PORT_LINUX: Release+Debug CTest 86/86 each; focused ASan/UBSan PASS; native X11 120 frames, Debian installed-style 120. Full sanitizer suite not certified (terminated during compile).
OBSERVED_RUNTIME_STOCK: historical 3 distinct 1175/1206 captured profiles ONLY; no new emulator run.
NOT RUN: Win32 build, NSIS install, physical Xbox, original Mesen new gameplay.
Open blocking: original playable Spring setup/3 real orders, Original Merchant RNG Trade, AI, war settlement, diplomacy, dynasty, complete campaigns, real PPU rendering and sound.
Publication gate: exact source manifests, copyright-clean GitHub, correct verified Drive Collaboration parent and no raw ROM/screenshots public.
