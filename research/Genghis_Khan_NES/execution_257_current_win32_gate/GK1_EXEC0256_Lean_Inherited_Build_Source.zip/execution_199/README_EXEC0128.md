# GK1 EXEC0128 — integrated NES OAM source-register and DMA groundwork

Inheritance: the complete native C11 EXEC0127 source, same 14/27 template worlds,
controller screens, Classic vs Enhanced, 1280x720 X11/Win32-intended runtime,
saves and existing CPU/PPU source research. No previous source deleted.

Implemented: gk128_oam.c/h is linked into the SAME gk1_app_state library.
The existing source-gated reset interpreter now executes OAMADDR $2003 and
OAMDATA $2004 CPU writes into an explicit known/unknown 256-byte OAM state
when using its previously existing PPU-scheduled research mode. The public
DMA API can atomically copy known 256-byte CPU source pages through OAM,
wrapping the OAM address, and calculates 513/514 cycles only when the caller
has independent APU get/put alignment evidence. Unresolved alignment, initial
OAMADDR and source bytes all fail closed without altering any OAM bytes.

BOUNDARY: The actual stock reset interpreter still does NOT grant a DMA
success path without confirmed APU alignment, DMC arbitration and DMA source
memory. Its existing $4014 source barrier remains, because random power-on
APU half-cycle cannot be inferred from CPU parity. Source-only PPU hypotheses
remain hypotheses. Not original stock Spring, playable three orders, graphics
rendering, sprite evaluation or original Mesen runtime verification.

Verified: CTest Release, Debug, sanitizer and clean source; private original
ROM optional tests with exact SHA; Linux Xvfb and Debian installer. Win32,
NSIS installer and physical Xbox NOT RUN. Private ROM and screenshots NEVER
publish in GitHub or public research source ZIP.
