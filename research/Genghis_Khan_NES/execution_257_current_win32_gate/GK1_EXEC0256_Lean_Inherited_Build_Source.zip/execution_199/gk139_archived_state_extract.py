#!/usr/bin/env python3
"""Read-only MesenCE .mss post-setup RNG proof extractor. Standard library only.

No private data is embedded. Do not publish raw state, ROM, save RAM or output
with private capture evidence to public GitHub. This program does not execute
or recreate a playable Spring. An archived state is not a fresh reset.
"""
import argparse
import hashlib
import json
import struct
import sys
import zlib
from pathlib import Path

STOCK_SHA = 'ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3'
COUNTRY_START = 0x0DCD
FIELD_MAX = 16 * 1024 * 1024


def _decompress_limited(data, start, bound=FIELD_MAX):
    z = zlib.decompressobj()
    result = z.decompress(data[start:], bound + 1)
    if not z.eof or len(result) > bound:
        raise ValueError('incomplete or oversized state stream')
    return result


def decode_mesen_named_fields(mss):
    """Find the single zlib stream containing a structured named CPU state.

    MesenCE MSS uses separately compressed chunks. Do not assume fixed offsets
    across savestates; the two archived files have different chunk positions.
    """
    if not mss.startswith(b'MSS\x01') or len(mss) > 64 * 1024 * 1024:
        raise ValueError('invalid MesenCE state envelope')
    matches = []
    for pos in range(32, len(mss) - 6):
        if mss[pos] != 0x78 or ((mss[pos] << 8) + mss[pos + 1]) % 31:
            continue
        try:
            raw = _decompress_limited(mss, pos)
        except (ValueError, zlib.error):
            continue
        if raw.startswith(b'cpu.pc\x00'):
            matches.append((pos, raw))
    if len(matches) != 1:
        raise ValueError('missing or ambiguous CPU named-state stream')
    return matches[0]


def parse_fields(data):
    position = 0
    result = {}
    while position < len(data):
        end = data.find(b'\0', position, min(len(data), position + 128))
        if end <= position or end < 0 or len(data) - end < 5:
            raise ValueError('malformed field name')
        name = bytes(data[position:end])
        if any(c < 33 or c > 126 for c in name):
            raise ValueError('invalid field name')
        size = struct.unpack_from('<I', data, end + 1)[0]
        start = end + 5
        if size > len(data) - start:
            raise ValueError('field overrun')
        if name in result:
            raise ValueError('duplicate field name')
        result[name] = bytes(data[start:start + size])
        position = start + size
    return result


def extract_private_observation(data):
    fields = parse_fields(data)
    def field(name, length):
        value = fields.get(name.encode('ascii'))
        if value is None or len(value) != length:
            raise ValueError('absent or incorrectly-sized ' + name)
        return value
    ram = field('memoryManager.internalRam', 2048)
    work = field('mapper.workRam', 8192)
    saved = field('mapper.saveRam', 8192)
    pc = struct.unpack('<H', field('cpu.pc', 2))[0]
    cycles = struct.unpack('<Q', field('cpu.cycleCount', 8))[0]
    has_work = any(work[COUNTRY_START:COUNTRY_START + 83])
    has_save = any(saved[COUNTRY_START:COUNTRY_START + 83])
    if has_work == has_save:
        raise ValueError('missing or ambiguous original country bank')
    return dict(seed_hex=ram[0x84:0x8a].hex(),
                cpu_pc=f'${pc:04X}', cpu_cycles=cycles,
                record_bank='nesWorkRam' if has_work else 'nesSaveRam',
                field_count=len(fields))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mesen_state', type=Path)
    parser.add_argument('--private-original-rom', type=Path, required=True)
    args = parser.parse_args()
    rom = args.private_original_rom.read_bytes()
    if len(rom) != 262160 or hashlib.sha256(rom).hexdigest() != STOCK_SHA:
        raise SystemExit('REFUSED: original stock ROM identity mismatch')
    mss = args.mesen_state.read_bytes()
    offset, data = decode_mesen_named_fields(mss)
    evidence = extract_private_observation(data)
    evidence.update(rom_sha256=STOCK_SHA, mss_sha256=hashlib.sha256(mss).hexdigest(),
                    saved_state_name=args.mesen_state.name,
                    compressed_state_offset=offset,
                    evidence_type='OBSERVED_RUNTIME_STOCK_ARCHIVED_RESTORED_NOT_FRESH',
                    causal_original_rate_draw_identified=False,
                    native_first_spring_implemented=False)
    print(json.dumps(evidence, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
