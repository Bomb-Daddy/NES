# EXEC0136 IMPLEMENTER / QA HANDOFF — 2026-11-09

## Inheritance and scope

Full existing native C11 application inherited from EXEC0135; all preceding historical source archive entries preserved. Same 1280x720 X11/Win32 app, controller routing, both campaign templates, Classic/Enhanced profiles, prior source/battle/merchant/save code. `execution_136` is the current authoritative source tree; earlier entries are immutable history. Copyright-clean files only.

## Executed source modification

`gk103_ntsc_ppu.c/h` was repaired to count unrendered NTSC VBlank start/end events in O(1) rather than enumerating every frame. The original O(number of elapsed frames) implementation would be practically nonterminating for a large but otherwise valid source clock. Exact 89342-dot frame arithmetic, 82182-dot start, 89002-dot end, conditional NMI edges, read-to-clear VBlank behavior and atomic refusal on time/counter overflow are covered by `test_gk136_ppu_longspan.c`. This is code in the original-source interpreter linked to the complete game, not a new game prototype.

## Actual verification (not inferred)

- Release CMake build -Werror: PASS; CTest **94/94 PASS** with private, source-verified original USA NES ROM environment (262160B SHA256 ada7066d9e71a81310fff78bc7037126798018a69dc2b92382c3cbdcd9b243b3).
- Debug CTest **94/94 PASS** with private original source input.
- Focused ASan+UBSan `test_gk136_ppu_longspan` PASS **10390 checks**, and prior `test_gk135_ppu_atomic` PASS **451 checks** with source-bound trace at 16,323 instructions, PC C5BE. Full sanitizer build was attempted and timed out; do not claim complete sanitizer suite.
- Native X11 Xvfb compiled 1280x720 `--smoke-frames 120` and `--smoke-scenario 120` PASS. Extracted genuine Debian executable same 120-frame tests PASS. Native synthetic-controller save/cold-load PASS.
- No new headless Mesen stock gameplay. No native Win32 build/NSIS installer execution, physical Xbox controller, full campaign acceptance.

## Provenance classification

VERIFIED_STATIC: source code, PPU event math and comparison to independent slow reference oracle. TESTED_PORT_LINUX: actual native Release/Debug, focused sanitizer and Xvfb/DEB. OBSERVED_RUNTIME_STOCK: inherited only, fresh Mongol1175 Gold430 Food208 Troops61 Rate121 orders3; separately archived Mongol1175 Gold439 Food208 Troops61 Rate101 orders3; World1206 Gold193 Food332 Troops116 Rate114 orders3. NOT RUN: new Mesen, native Win32/NSIS/physical controller/campaigns.

## Outstanding first priority

Exact original setup/difficulty/character RNG and NES-emulated first playable Spring for all 14/27 countries with 3 real orders are **not implemented**. Default work-RAM unknown F5 at PC8060 remains; separately presumed AllZeros branch stops at PPUSTATUS/hardware at C5BE. Never hardcode one first-Spring screenshot as universal RNG; preserve private ROM/SRAM/assets. Continue authentic source tracing before unlocking native first Spring. Full original Trade, strategic commands, autonomous AI, diplomacy, dynasty/marriage6/7/8, battle aftermath and tested Windows/Xbox campaigns remain unfinished. Publication does not establish another agent's execution.
