#include "gk1_observed_turn.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int assertions=0;
#define CHECK(expr) do{assertions++;if(!(expr)){fprintf(stderr,"FAIL %s:%d: %s\n",__FILE__,__LINE__,#expr);exit(1);}}while(0)
static void test_friendly(void){
 Gk45Turn t;CHECK(gk45_open(GK45_FRIEND_40,&t)==GK45_ACCEPTED);
 CHECK(t.soldiers==40&&t.ally1_soldiers==40);
 CHECK(gk45_step_first(&t)==GK45_FINISHED);
 CHECK(t.soldiers==74&&t.ally1_soldiers==0&&t.x==8&&t.y==7);
 CHECK(t.completion_word==2&&t.mobility==10&&t.phase==GK45_DONE);
 CHECK(t.rng48==UINT64_C(0xa31e4ecd8fd1));
 Gk45Turn prev=t;
 CHECK(gk45_step_first(&t)==GK45_UNKNOWN&&memcmp(&t,&prev,sizeof t)==0);
 CHECK(gk45_press_b(&t)==GK45_UNKNOWN&&memcmp(&t,&prev,sizeof t)==0);
}
static void test_two_step(void){
 Gk45Turn t;CHECK(gk45_open(GK45_RAW2,&t)==GK45_ACCEPTED);
 CHECK(gk45_step_first(&t)==GK45_ACCEPTED);
 CHECK(t.soldiers==34&&t.x==8&&t.y==7&&t.mobility==6&&t.completion_word==0);
 CHECK(t.rng48==UINT64_C(0xa31e4ecd8fd1));
 CHECK(gk45_step_second(&t)==GK45_ACCEPTED);
 CHECK(t.soldiers==34&&t.x==9&&t.y==7&&t.mobility==3&&t.steps==2&&t.completion_word==0);
 CHECK(t.rng48==UINT64_C(0xa31e4ecd8fd1));
 CHECK(gk45_press_b(&t)==GK45_FINISHED);
 CHECK(t.soldiers==34&&t.x==9&&t.y==7&&t.mobility==10&&t.completion_word==1);
}
static void test_refusal(void){
 Gk45Turn t;CHECK(gk45_open(GK45_RAW7,&t)==GK45_ACCEPTED);
 CHECK(gk45_step_first(&t)==GK45_ACCEPTED);
 Gk45Turn prior=t;
 CHECK(gk45_step_second(&t)==GK45_REFUSED);
 CHECK(t.phase==GK45_REFUSAL_MESSAGE && t.soldiers==prior.soldiers &&t.x==prior.x && t.mobility==prior.mobility &&t.rng48==prior.rng48&&t.completion_word==0);
 CHECK(gk45_press_b(&t)==GK45_ACCEPTED);
 CHECK(t.phase==GK45_PENDING&&t.completion_word==0&&t.mobility==6);
 CHECK(gk45_press_b(&t)==GK45_FINISHED);
 CHECK(t.completion_word==1&&t.mobility==10&&t.x==8&&t.soldiers==34);
}
static void test_boundaries(void){
 Gk45Turn t,prior;CHECK(gk45_open((Gk45Case)0,&t)==GK45_UNKNOWN);
 CHECK(gk45_open(GK45_RAW2,NULL)==GK45_BAD);
 CHECK(gk45_step_second(NULL)==GK45_BAD);
 CHECK(gk45_press_b(NULL)==GK45_BAD);
 CHECK(gk45_open(GK45_RAW2,&t)==GK45_ACCEPTED);
 prior=t;CHECK(gk45_step_second(&t)==GK45_UNKNOWN && memcmp(&prior,&t,sizeof t)==0);
 t.mobility=9;prior=t;CHECK(gk45_step_first(&t)==GK45_UNKNOWN&&memcmp(&prior,&t,sizeof t)==0);
 CHECK(gk45_divide_entry(9)==GK45_UNKNOWN);
 for(unsigned m=10;m<=12;m++)CHECK(gk45_divide_entry((uint16_t)m)==GK45_REFUSED);
 for(unsigned m=13;m<=16;m++)CHECK(gk45_divide_entry((uint16_t)m)==GK45_PROMPT_QUANTITY);
 CHECK(gk45_divide_entry(20)==GK45_PROMPT_QUANTITY);
 for(unsigned m=17;m<=19;m++)CHECK(gk45_divide_entry((uint16_t)m)==GK45_UNKNOWN);
 CHECK(gk45_divide_entry(21)==GK45_UNKNOWN);
}
int main(void){test_friendly();test_two_step();test_refusal();test_boundaries();printf("PASS observed native movement contract: %d assertions\n",assertions);return 0;}
