# GK1 EXEC0045 — live modified-NES friendly join, multi-step path and Divide entry

**Date:** 2026-11-06. **Owner:** Zhuge Liang. **Consumer:** Genghis Khan I Windows BattleMovement/BattleInput, not ROTK II. **Status:** OBSERVED_RUNTIME_MOD for precise controlled original-game cases; Linux C11 source tests PASS; Windows/physical controller NOT RUN. This is NOT a complete tactical engine.

## Input authority

Actual combined approved shared-BP/Rest ROM SHA-256 `4764d46359581be1e7d12bcb85bd375c84cd4497d1084d9d306a6e884afbe7c5`. Matching Mesen executable SHA-256 `e777af28bc6cc49d2e61ca0c1a82fbccf13811355332a53ea00749fc37a92761`; core SHA-256 `0668f6c09bc89a1c8199df6cbf15aeebba243169b30f8116df97127dbfd3d7af`. Source checkpoint `e1b6266c963a48d736627812d024910b6d600c2ad8571813eb3b0999e0f2938b`. Restored RAM unit0 40 soldiers at (7,7), type0, Mobility10, RNG `c7c3f28f2363`. Each emulator process used the original controller A/D-pad/B bridge, with only the interventions stated below.

## New executed NES facts

- **Friendly join** (controlled unit1 moved by RAM intervention to (8,7), kept 40 troops, type0): controller Move→Entire, unit0, right, A. Actual CPU word stores into unit0 count pass through 40→39→34→0→74; unit1 40→0 but retains its coordinates and the other record fields at the sampled completion; scratch completion word 0→1→2 via native CPU `$F1CA/$F1CF`; RNG becomes `a31e4ecd8fd1`. A separate B after join does not reverse it. Native source writes captured via Mesen callbacks. This adds actual source-level completion and write ordering to earlier archived synthetic-position results; no universal merge rule or zero-soldier terminal inference.
- **Two-step movement** (disclosed target tile `$61D5` changed from raw7 to raw2 after checkpoint restore): unit0 (40,7,7,Mobility10) → forest (34,8,7,Mobility6) → raw2 (34,9,7,Mobility3), unchanged RNG after second step; B finishes, restores Mobility10 and increments completion 0→1. The original raw7 destination refused the second move without changing troops, RNG, position or Mobility. After refusal first B only dismisses error; second B finishes the already-committed first step. Real game displayed refusal and Move Where? states; captured screenshots confirm.
- **Divide entry menu**: In the identical source unit and game state, Mobility 10,11,12 caused `Not enough mobility`; controlled Mobility 13,14,15,16,20 reached `Move how many troops? (1-40)` prompt. Exact boundary observed 12/13 for this state, **not** a proven global rule. No split actually committed. For untested Mobility 17–19, the authored fail-closed source reports UNKNOWN rather than extrapolating.

The `gk1_observed_turn.*` C11 module is a strict **capture acceptance adapter** supporting only these three named exact fixtures, first/second steps, refusal message and final B. `gk45_divide_entry` is a narrow tested menu gate. Unknown other states/terrain/campaign/profiles are rejected, not synthesized. The code does not embed ROM/SRAM/checkpoint/art/sound. Do **not** interpret this C11 module or the current native Linux research shell as a completed Windows battle.

## QA reproduction

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build -j2
ctest --test-dir build --output-on-failure
# Same tests with Release and optional ASan/UBSan build options.
python audit_live.py --root /private/GK1_EXEC0045_recovered_live_captures
```

C11 tests: 45 assertions; Debug/Release/ASan+UBSan one CTest each PASS in the Linux cloud. Raw native-capture audit checks 27 exact evidence invariants plus a deliberately tampered friendly 74→75 negative, which was rejected. The stage screenshot/classification and Divide console transcription are distinguished from raw source write callbacks. The source ZIP does not contain the private original ROM, emulator binary, licensed screenshots, captured SRAM/checkpoint or full private logs; those are in the separately stored private evidence ZIP.

## Remaining non-claims / next implementation

Still requires actual Divide quantity/split destination semantics; general friend merge logic, other unit types, occupancy/path legality, battle endings/zero-unit cleanup, tactical AI, full-world save, Windows compile/controller and full player acceptance. Integrate this acceptance module with the existing C11 desktop program as an additive source piece; do not replace the source-proven movement/casualty formula or other settled mechanics. A real first-party Windows gameplay engine must eventually use actual decoded source algorithms instead of exact fixture-only outcomes.
