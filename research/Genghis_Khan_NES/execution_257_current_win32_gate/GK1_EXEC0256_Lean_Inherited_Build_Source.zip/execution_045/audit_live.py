#!/usr/bin/env python3
"""EXEC0045 original emulator observation audit. Numeric logs only; no ROM bytes."""
import argparse, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SEED0='c7c3f28f2363'
SEED1='a31e4ecd8fd1'
def stage(root, path):
    return json.loads((root/path).read_text())
def assure(x, why):
    if not x: raise AssertionError(why)
def verify(root):
    passes=[]
    def check(cond, what): assure(cond,what); passes.append(what)
    f=stage(root,'third_a.json');b=stage(root,'first_b.json')
    check(f['unit0'][:6]==[74,0,8,7,0,10],'friendly mover 40→34+40→74, position, Mobility')
    check(f['unit1'][:6]==[0,0,8,7,0,10],'friendly partner 40→0, slot retained')
    check(f['scratch']==[2,0] and f['rng']==SEED1,'friendly scratch word2 and original RNG')
    check(b['unit0']==f['unit0'] and b['unit1']==f['unit1'] and b['scratch']==f['scratch'],'post-completion B no change')
    e=json.loads((root/'join_watches.json').read_text())['events']
    writes=lambda addr:[x['value'] for x in e if x['address']==addr]
    check(writes(0x6060)==[39,34,0,74],'original 6502 live mover low-byte write order')
    check(writes(0x606b)==[0] and writes(0x613e)==[1,2] and writes(0x613f)==[0,0],'original 6502 partner and scratch-word writes')
    p1=stage(root,'path_a3move1.json');p2=stage(root,'path_a4move2.json');pf=stage(root,'path_bfinish.json')
    check(p1['unit0'][:6]==[34,0,8,7,0,6] and p1['rng']==SEED1,'first forest step')
    check(p2['unit0'][:6]==[34,0,9,7,0,3] and p2['rng']==SEED1 and p2['scratch']==[0,0],'second raw2 step cost3, no additional casualty or RNG')
    check(pf['unit0'][:6]==[34,0,9,7,0,10] and pf['scratch']==[1,0],'B completes two-step path once')
    r=stage(root,'refuse_a4move2.json');r1=stage(root,'refuse_bfinish.json');r2=stage(root,'refuse_b2finish.json')
    check(r['unit0'][:6]==[34,0,8,7,0,6] and r['rng']==SEED1 and r['scratch']==[0,0],'raw7 movement refused, no casualty/RNG/complete')
    check(r1['unit0']==r['unit0'] and r1['scratch']==[0,0],'first B dismisses denial, does not complete')
    check(r2['unit0'][:6]==[34,0,8,7,0,10] and r2['scratch']==[1,0],'second B completes original path')
    divide=stage(root,'divide_console_observations.json')['cases']
    check([d['mobility'] for d in divide]==[10,11,12,13,14,15,16,20], 'Divide threshold cases all recorded')
    for d in divide:
        m=d['mobility'];expected=[198,230] if m==10 else ([196,230] if m<=12 else ([91,203] if m==20 else [94,203]))
        check(d['vm06']==expected, f'Divide Mobility{m} VM context from captured stdout')
        check((root/d['screenshot']).read_bytes().startswith(b"\x89PNG\r\n\x1a\n"), f'Mesen original Divide Mobility{m} screenshot exists')
    for n in ('third_a','path_a4move2','refuse_b2finish'):
        check((root/f'{n}.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n'),f'Mesen screenshot {n} valid PNG')
    return passes
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,default=ROOT);ns=a.parse_args()
    found=verify(ns.root);print(f'PASS: {len(found)} checks')
    for x in found:print(' +',x)
    d=stage(ns.root,'third_a.json');d['unit0'][0]=75
    # Deliberate adversarial counterexample: an altered output must violate the exact vector.
    try:assure(d['unit0'][:6]==[74,0,8,7,0,10],'mutated unit not accepted')
    except AssertionError:print('PASS: mutant altered joined soldier count rejected')
    else:raise SystemExit('FAILED negative control')
